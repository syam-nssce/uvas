import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") { return new Response("ok", { headers: corsHeaders }); }
  try {
    const { action, member_id_or_mobile, date_of_birth, member_id, renewal_utr } = await req.json();
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    if (action === "verify") {
      if (!member_id_or_mobile || !date_of_birth) {
        return new Response(JSON.stringify({ error: "Member ID/Mobile and date of birth are required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const isNumeric = /^\d+$/.test(member_id_or_mobile);
      let query = supabase.from("members").select("id, full_name, mobile, email, employee_id, college_name, designation, membership_category, status, renewal_date, joined_date").eq("date_of_birth", date_of_birth);
      if (isNumeric && member_id_or_mobile.length === 10) { query = query.eq("mobile", member_id_or_mobile); } else { query = query.eq("employee_id", member_id_or_mobile); }
      const { data, error: fetchError } = await query.maybeSingle();
      if (fetchError || !data) { return new Response(JSON.stringify({ error: "No member found with the provided details." }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      return new Response(JSON.stringify({ success: true, member: data }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "renew") {
      if (!member_id) { return new Response(JSON.stringify({ error: "Member ID is required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      
      // Fetch current member to check renewal eligibility
      const { data: member, error: fetchErr } = await supabase.from("members").select("renewal_date, joined_date").eq("id", member_id).maybeSingle();
      if (fetchErr || !member) {
        return new Response(JSON.stringify({ error: "Member not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // Bulk-imported members have no joined_date — they may renew at any time.
      // For regular members, enforce the 1-year rule based on last renewal_date or joined_date.
      if (member.joined_date) {
        const refDateStr = member.renewal_date || member.joined_date;
        const refDate = new Date(refDateStr);
        const now = new Date();
        const oneYearAfter = new Date(refDate);
        oneYearAfter.setFullYear(oneYearAfter.getFullYear() + 1);
        if (now < oneYearAfter) {
          return new Response(JSON.stringify({ error: "Renewal is not yet due. Your current membership is still active." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
      }
      
      const newRenewalDate = new Date();
      newRenewalDate.setFullYear(newRenewalDate.getFullYear() + 1);
      const { error: updateError } = await supabase.from("members").update({ renewal_date: newRenewalDate.toISOString(), payment_status: renewal_utr ? "submitted" : "pending", status: "active", utr_reference: renewal_utr || null }).eq("id", member_id);
      if (updateError) { return new Response(JSON.stringify({ error: updateError.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      return new Response(JSON.stringify({ success: true }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (_err) {
    return new Response(JSON.stringify({ error: "An error occurred" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
