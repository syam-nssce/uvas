import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") { return new Response("ok", { headers: corsHeaders }); }
  try {
    const { username, currentPassword, newPassword } = await req.json();
    if (!username || !currentPassword || !newPassword) {
      return new Response(JSON.stringify({ error: "All fields are required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (newPassword.length < 8) {
      return new Response(JSON.stringify({ error: "New password must be at least 8 characters" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: adminUser } = await supabase.from("admin_users").select("id, password_hash").eq("username", username).eq("is_active", true).maybeSingle();
    if (!adminUser) { return new Response(JSON.stringify({ error: "Invalid credentials" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
    const { data: match } = await supabase.rpc("verify_admin_password", { input_password: currentPassword, stored_hash: adminUser.password_hash });
    if (!match) { return new Response(JSON.stringify({ error: "Current password is incorrect" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
    const { error: updateError } = await supabase.rpc("update_admin_password", { admin_id: adminUser.id, new_password: newPassword });
    if (updateError) { return new Response(JSON.stringify({ error: "Failed to update password" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
    return new Response(JSON.stringify({ success: true }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (_err) {
    return new Response(JSON.stringify({ error: "An error occurred" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
