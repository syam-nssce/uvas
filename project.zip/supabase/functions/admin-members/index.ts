import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { action, username, password, member_id, member_name, status_filter, update_data, members_list, default_password } = await req.json();
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    if (!username || !password) {
      return new Response(JSON.stringify({ error: "Admin credentials required" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { data: adminUser } = await supabase.from("admin_users").select("id, password_hash").eq("username", username).eq("is_active", true).maybeSingle();
    if (!adminUser) { return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }

    const { data: match } = await supabase.rpc("verify_admin_password", { input_password: password, stored_hash: adminUser.password_hash });
    if (!match) { return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }

    if (action === "list") {
      let query = supabase.from("members").select("id, full_name, email, mobile, phone, address, institution, designation, membership_type, status, joined_date, renewal_date, last_renewal_date, retirement_date, payment_status, payment_id, created_at, updated_at, date_of_birth, employee_id, college_name, college_type, college_address, district, university, house_address, religion, area_of_specialization, experience_years, membership_category, utr_reference").order("created_at", { ascending: false });
      if (status_filter && status_filter !== "all") { query = query.eq("status", status_filter); }
      const { data, error: queryError } = await query;
      if (queryError) { return new Response(JSON.stringify({ error: queryError.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      return new Response(JSON.stringify({ success: true, members: data }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "approve") {
      if (!member_id) { return new Response(JSON.stringify({ error: "Member ID required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      // Detect renewal: a renewal sets renewal_date (next due) and submits a UTR. Initial signup approval has neither.
      const { data: existing } = await supabase.from("members").select("renewal_date, utr_reference, payment_status, last_renewal_date").eq("id", member_id).maybeSingle();
      const isRenewalApproval = !!(existing && existing.renewal_date && existing.payment_status === "submitted");
      const updatePayload: Record<string, any> = { status: "active", payment_status: "paid" };
      if (isRenewalApproval) {
        updatePayload.last_renewal_date = new Date().toISOString().slice(0, 10);
      }
      const { data, error: updateError } = await supabase.from("members").update(updatePayload).eq("id", member_id).select();
      if (updateError) { return new Response(JSON.stringify({ error: updateError.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      return new Response(JSON.stringify({ success: true, data }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "delete") {
      if (!member_id) { return new Response(JSON.stringify({ error: "Member ID required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      const { error: deleteError } = await supabase.from("members").delete().eq("id", member_id);
      if (deleteError) { return new Response(JSON.stringify({ error: deleteError.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      return new Response(JSON.stringify({ success: true }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "update") {
      if (!member_id || !update_data) { return new Response(JSON.stringify({ error: "Member ID and update data required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      delete update_data.password;
      delete update_data.password_hash;
      const { data, error: updateError } = await supabase.from("members").update(update_data).eq("id", member_id).select();
      if (updateError) { return new Response(JSON.stringify({ error: updateError.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      return new Response(JSON.stringify({ success: true, data }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "bulk_import") {
      if (!Array.isArray(members_list) || members_list.length === 0) {
        return new Response(JSON.stringify({ error: "members_list required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      if (!default_password || typeof default_password !== "string" || default_password.length < 8) {
        return new Response(JSON.stringify({ error: "Default password (min 8 chars) required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const { data: hashedPassword, error: hashError } = await supabase.rpc("hash_password", { plain_password: default_password });
      if (hashError || !hashedPassword) {
        return new Response(JSON.stringify({ error: "Failed to hash default password" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const created: Array<{ full_name: string; mobile: string; password: string }> = [];
      const skipped: Array<{ full_name?: string; mobile?: string; reason: string }> = [];

      for (const row of members_list) {
        const full_name = (row.full_name || "").toString().trim();
        const mobile = (row.mobile || "").toString().trim();
        const dob = row.date_of_birth ? row.date_of_birth.toString().trim() : null;
        const email = (row.email || "").toString().trim().toLowerCase();

        if (!full_name || !mobile || !email) {
          skipped.push({ full_name, mobile, reason: "Missing full_name, mobile, or email" });
          continue;
        }

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          skipped.push({ full_name, mobile, reason: "Invalid email format" });
          continue;
        }

        const { data: existingMobile } = await supabase.from("members").select("id").eq("mobile", mobile).maybeSingle();
        if (existingMobile) {
          skipped.push({ full_name, mobile, reason: "Mobile already exists" });
          continue;
        }

        const { data: existingEmail } = await supabase.from("members").select("id").eq("email", email).maybeSingle();
        if (existingEmail) {
          skipped.push({ full_name, mobile, reason: "Email already exists" });
          continue;
        }

        const memberData = {
          full_name,
          mobile,
          email,
          date_of_birth: dob,
          password: hashedPassword,
          status: "active",
          payment_status: "paid",
          membership_type: "regular",
          joined_date: null,
        };

        const { error: insertError } = await supabase.from("members").insert(memberData);
        if (insertError) {
          skipped.push({ full_name, mobile, reason: insertError.message });
          continue;
        }

        created.push({ full_name, mobile, password: default_password });
      }

      return new Response(JSON.stringify({ success: true, created, skipped, created_count: created.length, skipped_count: skipped.length }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (_err) {
    return new Response(JSON.stringify({ error: "An error occurred" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
