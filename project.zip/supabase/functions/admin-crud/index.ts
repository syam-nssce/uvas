import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const ALLOWED_TABLES = [
  "news_events",
  "orders_circulars",
  "gallery",
  "committee_members",
  "prajnabharati_journals",
  "news_ticker",
  "site_settings",
  "helpdesk_posts",
  "helpdesk_replies",
  "members",
];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const {
      username,
      password,
      table,
      action,
      data,
      filters,
      id,
      select_columns,
      order_by,
      upsert_conflict,
    } = body;

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    // --- Verify admin credentials ---
    if (!username || !password) {
      return json({ error: "Admin credentials required" }, 401);
    }

    const { data: adminUser } = await supabase
      .from("admin_users")
      .select("id, password_hash")
      .eq("username", username)
      .eq("is_active", true)
      .maybeSingle();

    if (!adminUser) return json({ error: "Unauthorized" }, 401);

    const { data: match } = await supabase.rpc("verify_admin_password", {
      input_password: password,
      stored_hash: adminUser.password_hash,
    });

    if (!match) return json({ error: "Unauthorized" }, 401);

    // --- Stats action ---
    if (action === "stats") {
      const results: Record<string, number> = {};
      if (Array.isArray(data?.tables)) {
        for (const t of data.tables) {
          if (!ALLOWED_TABLES.includes(t.table)) continue;
          let q = supabase.from(t.table).select("id", { count: "exact", head: true });
          if (t.filter) {
            for (const [k, v] of Object.entries(t.filter)) {
              q = q.eq(k, v as string);
            }
          }
          const { count } = await q;
          results[t.key || t.table] = count || 0;
        }
      }
      return json({ success: true, stats: results });
    }

    // --- Validate table ---
    if (!table || !ALLOWED_TABLES.includes(table)) {
      return json({ error: "Invalid table" }, 400);
    }

    // --- List ---
    if (action === "list") {
      let query = supabase.from(table).select(select_columns || "*");
      if (filters) {
        for (const [k, v] of Object.entries(filters)) {
          if (v !== null && v !== undefined && v !== "all" && v !== "") {
            if (k.endsWith("_neq")) {
              query = query.neq(k.replace("_neq", ""), v as string);
            } else {
              query = query.eq(k, v as string);
            }
          }
        }
      }
      if (order_by) {
        query = query.order(order_by.column || "created_at", {
          ascending: order_by.ascending ?? false,
        });
      } else {
        query = query.order("created_at", { ascending: false });
      }
      const { data: rows, error: listError } = await query;
      if (listError) return json({ error: listError.message }, 500);
      return json({ success: true, data: rows });
    }

    // --- Insert ---
    if (action === "insert") {
      if (!data) return json({ error: "Data required" }, 400);
      const { data: inserted, error: err } = await supabase
        .from(table)
        .insert(Array.isArray(data) ? data : [data])
        .select();
      if (err) return json({ error: err.message }, 500);
      return json({ success: true, data: inserted });
    }

    // --- Update ---
    if (action === "update") {
      if (!id || !data) return json({ error: "ID and data required" }, 400);
      const { data: updated, error: err } = await supabase
        .from(table)
        .update(data)
        .eq("id", id)
        .select();
      if (err) return json({ error: err.message }, 500);
      return json({ success: true, data: updated });
    }

    // --- Delete ---
    if (action === "delete") {
      if (!id) return json({ error: "ID required" }, 400);
      const { error: err } = await supabase.from(table).delete().eq("id", id);
      if (err) return json({ error: err.message }, 500);
      return json({ success: true });
    }

    // --- Upsert ---
    if (action === "upsert") {
      if (!data) return json({ error: "Data required" }, 400);
      const { error: err } = await supabase
        .from(table)
        .upsert(data, { onConflict: upsert_conflict || "id" });
      if (err) return json({ error: err.message }, 500);
      return json({ success: true });
    }

    return json({ error: "Invalid action" }, 400);
  } catch (_err) {
    return json({ error: "An error occurred" }, 500);
  }
});

function json(body: Record<string, unknown>, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
