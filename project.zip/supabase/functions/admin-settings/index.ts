import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") { return new Response("ok", { headers: corsHeaders }); }
  try {
    const { username, password, settings } = await req.json();
    if (!username || !password || !settings || !Array.isArray(settings)) {
      return new Response(JSON.stringify({ error: "Username, password, and settings array are required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: adminUser } = await supabase.from("admin_users").select("id, password_hash").eq("username", username).eq("is_active", true).maybeSingle();
    if (!adminUser) { return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
    const { data: match } = await supabase.rpc("verify_admin_password", { input_password: password, stored_hash: adminUser.password_hash });
    if (!match) { return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
    for (const { key, value } of settings) {
      if (typeof key !== "string" || typeof value !== "string") continue;
      await supabase.from("site_settings").upsert({ setting_key: key, setting_value: value }, { onConflict: "setting_key" });
    }
    return new Response(JSON.stringify({ success: true }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (_err) {
    return new Response(JSON.stringify({ error: "An error occurred" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
