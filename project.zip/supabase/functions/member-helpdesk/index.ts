import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { action } = body;

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    // --- List approved posts (public) ---
    if (action === "list_posts") {
      const { data, error } = await supabase
        .from("helpdesk_posts")
        .select("*, members(full_name, college_name)")
        .neq("status", "pending")
        .order("created_at", { ascending: false });
      if (error) return json({ error: error.message }, 500);
      return json({ success: true, posts: data });
    }

    // --- Get replies for a post (public) ---
    if (action === "get_replies") {
      const { post_id } = body;
      if (!post_id) return json({ error: "post_id required" }, 400);
      const { data, error } = await supabase
        .from("helpdesk_replies")
        .select("*, members(full_name, college_name)")
        .eq("post_id", post_id)
        .order("created_at", { ascending: true });
      if (error) return json({ error: error.message }, 500);
      return json({ success: true, replies: data });
    }

    // --- Increment views (public) ---
    if (action === "increment_views") {
      const { post_id, current_views } = body;
      if (!post_id) return json({ error: "post_id required" }, 400);
      await supabase
        .from("helpdesk_posts")
        .update({ views: (current_views || 0) + 1 })
        .eq("id", post_id);
      return json({ success: true });
    }

    // --- Actions below require member token ---
    const { token } = body;
    if (!token) return json({ error: "Authentication required" }, 401);

    const payload = await verifyToken(token, serviceRoleKey);
    if (!payload) return json({ error: "Invalid or expired session" }, 401);

    const memberId = payload.sub;

    // Helper: ensure profile is complete before posting/replying
    const ensureProfileComplete = async (): Promise<string | null> => {
      const { data } = await supabase
        .from("members")
        .select("joined_date, college_type, college_name, designation, district, service_joining_date")
        .eq("id", memberId)
        .maybeSingle();
      if (!data) return "Member profile not found.";
      const required: { key: string; label: string }[] = [
        { key: "joined_date", label: "Date of Joining UVAS" },
        { key: "college_type", label: "College Type" },
        { key: "college_name", label: "College Name" },
        { key: "designation", label: "Designation" },
        { key: "district", label: "District" },
        { key: "service_joining_date", label: "Date of Joining Service" },
      ];
      const missing = required.filter((f) => !(data as Record<string, unknown>)[f.key]).map((f) => f.label);
      if (missing.length > 0) {
        return `Please complete your member profile first. Missing: ${missing.join(", ")}.`;
      }
      return null;
    };

    // --- Upload document for helpdesk ---
    if (action === "upload_document") {
      const profileErr = await ensureProfileComplete();
      if (profileErr) return json({ error: profileErr }, 403);
      const { file_name, file_base64, content_type } = body;
      if (!file_name || !file_base64) {
        return json({ error: "File data required" }, 400);
      }

      const safeName = sanitizeFileName(file_name);
      const filePath = `helpdesk/${memberId}/${safeName}`;
      const fileBytes = decodeBase64(file_base64);

      const { error: uploadError } = await supabase.storage
        .from("documents")
        .upload(filePath, fileBytes, {
          upsert: false,
          contentType: content_type || "application/octet-stream",
        });

      if (uploadError) {
        return json({ error: uploadError.message }, 500);
      }

      const { data: publicUrlData } = supabase.storage
        .from("documents")
        .getPublicUrl(filePath);

      return json({ success: true, publicUrl: publicUrlData.publicUrl });
    }

    // --- Create post ---
    if (action === "create_post") {
      const profileErr = await ensureProfileComplete();
      if (profileErr) return json({ error: profileErr }, 403);
      const { topic, title, content, document_url } = body;
      if (!topic || !title || !content) {
        return json({ error: "topic, title, and content are required" }, 400);
      }
      if (title.length > 500 || content.length > 10000 || topic.length > 200) {
        return json({ error: "Input too long" }, 400);
      }
      const insertData: Record<string, unknown> = {
        topic,
        title,
        content,
        member_id: memberId,
        status: "pending",
      };
      if (document_url) {
        insertData.document_url = document_url;
      }
      const { error } = await supabase.from("helpdesk_posts").insert([insertData]);
      if (error) return json({ error: error.message }, 500);
      return json({ success: true });
    }

    // --- Create reply ---
    if (action === "create_reply") {
      const profileErr = await ensureProfileComplete();
      if (profileErr) return json({ error: profileErr }, 403);
      const { post_id, content } = body;
      if (!post_id || !content) {
        return json({ error: "post_id and content are required" }, 400);
      }
      if (content.length > 10000) {
        return json({ error: "Reply too long" }, 400);
      }
      const { error } = await supabase.from("helpdesk_replies").insert([
        {
          post_id,
          member_id: memberId,
          content,
          is_admin: false,
          approved: true,
        },
      ]);
      if (error) return json({ error: error.message }, 500);
      return json({ success: true });
    }

    return json({ error: "Invalid action" }, 400);
  } catch (_err) {
    return json({ error: "An error occurred" }, 500);
  }
});

function json(body: Record<string, unknown>, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function sanitizeFileName(fileName: string) {
  const lastDotIndex = fileName.lastIndexOf(".");
  const baseName = lastDotIndex >= 0 ? fileName.slice(0, lastDotIndex) : fileName;
  const extension = lastDotIndex >= 0 ? fileName.slice(lastDotIndex).toLowerCase() : "";
  const safeBaseName =
    baseName
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9_-]+/g, "-")
      .replace(/^-+|-+$/g, "") || "file";
  return `${Date.now()}-${safeBaseName}${extension}`;
}

function decodeBase64(base64: string) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

async function verifyToken(
  token: string,
  secret: string
): Promise<Record<string, any> | null> {
  try {
    const [p, s] = token.split(".");
    const data = atob(p);
    const parsed = JSON.parse(data);
    if (parsed.exp && parsed.exp < Date.now()) return null;
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw",
      enc.encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"]
    );
    const sig = Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
    return (await crypto.subtle.verify("HMAC", key, sig, enc.encode(data)))
      ? parsed
      : null;
  } catch {
    return null;
  }
}
