import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    const requiredFields = ["full_name", "email", "mobile", "password"];
    for (const field of requiredFields) {
      if (!body[field] || typeof body[field] !== "string" || !body[field].trim()) {
        return new Response(JSON.stringify({ error: `${field} is required` }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
    }

    if (body.password.length < 8) {
      return new Response(JSON.stringify({ error: "Password must be at least 8 characters" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { data: hashedPassword, error: hashError } = await supabase.rpc("hash_password", { plain_password: body.password });
    if (hashError || !hashedPassword) {
      return new Response(JSON.stringify({ error: "Failed to process registration" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Compute experience_years from service_joining_date if provided
    let experienceYears: number | null = null;
    if (body.service_joining_date) {
      const start = new Date(body.service_joining_date);
      if (!isNaN(start.getTime())) {
        const now = new Date();
        let years = now.getFullYear() - start.getFullYear();
        const m = now.getMonth() - start.getMonth();
        if (m < 0 || (m === 0 && now.getDate() < start.getDate())) years--;
        if (years >= 0) experienceYears = years;
      }
    }

    const memberData = {
      full_name: body.full_name, date_of_birth: body.date_of_birth || null, mobile: body.mobile, email: body.email,
      religion: body.religion || null, password: hashedPassword, house_address: body.house_address || null,
      designation: body.designation || null, employee_id: body.employee_id || null, college_type: body.college_type || null,
      district: body.district || null, university: body.university || null, college_name: body.college_name || null,
      college_address: body.college_address || null, membership_category: body.membership_category || null,
      service_joining_date: body.service_joining_date || null, experience_years: experienceYears,
      utr_reference: body.utr_reference || null, payment_status: body.utr_reference ? "submitted" : "pending",
      status: "pending", membership_type: "regular",
    };

    const { data: newMember, error: insertError } = await supabase.from("members").insert(memberData).select("id").single();
    if (insertError) {
      return new Response(JSON.stringify({ error: "Registration failed: " + insertError.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ success: true, member_id: newMember.id }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (_err) {
    return new Response(JSON.stringify({ error: "An error occurred during registration" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
