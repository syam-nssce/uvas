import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { mobile, email, identifier, password } = await req.json();

    // Accept any of: identifier (preferred), mobile, or email
    const rawId: string = (identifier ?? mobile ?? email ?? "").toString().trim();

    if (!rawId || !password) {
      return json({ error: "Mobile number or email and password are required" }, 400);
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    // Decide whether the input is an email or a mobile number
    const isEmail = rawId.includes("@");
    const lookupValue = isEmail ? rawId.toLowerCase() : rawId.replace(/\D/g, "");
    const lookupColumn = isEmail ? "email" : "mobile";

    const { data: member, error: queryError } = await supabase
      .from("members")
      .select("id, full_name, mobile, email, password, membership_category, status")
      .eq(lookupColumn, lookupValue)
      .maybeSingle();

    if (queryError || !member) {
      return json({ error: isEmail
        ? "No member found with this email."
        : "No member found with this mobile number." }, 401);
    }

    const { data: match } = await supabase.rpc("verify_member_password", {
      input_password: password,
      stored_hash: member.password || "",
    });

    if (!match) {
      return json({ error: "Incorrect password. Please try again." }, 401);
    }

    if (member.status !== "active" && member.status !== "pending") {
      return json({ error: "Your membership is not active. Please contact UVAS." }, 403);
    }

    // Issue signed session token (24h expiry)
    const token = await signToken(
      { sub: member.id, exp: Date.now() + 24 * 60 * 60 * 1000 },
      serviceRoleKey
    );

    return json({
      success: true,
      token,
      member: {
        id: member.id,
        full_name: member.full_name,
        mobile: member.mobile || "",
        email: member.email,
        membership_category: member.membership_category,
      },
    });
  } catch (_err) {
    return json({ error: "An error occurred during login" }, 500);
  }
});

function json(body: Record<string, unknown>, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function signToken(
  payload: Record<string, unknown>,
  secret: string
): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw", enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const data = JSON.stringify(payload);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(data));
  return btoa(data) + "." + btoa(String.fromCharCode(...new Uint8Array(sig)));
}
