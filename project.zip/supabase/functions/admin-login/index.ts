import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { username, password } = await req.json();
    if (!username || !password) {
      return new Response(JSON.stringify({ error: "Username and password are required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    const { data: adminUser, error: queryError } = await supabase.from("admin_users").select("id, username, email, password_hash, is_active").eq("username", username).eq("is_active", true).maybeSingle();
    if (queryError || !adminUser) {
      return new Response(JSON.stringify({ error: "Invalid username or password" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { data: match, error: matchError } = await supabase.rpc("verify_admin_password", { input_password: password, stored_hash: adminUser.password_hash });
    if (matchError || !match) {
      return new Response(JSON.stringify({ error: "Invalid username or password" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ success: true, username: adminUser.username, email: adminUser.email }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (_err) {
    return new Response(JSON.stringify({ error: "An error occurred during login" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
