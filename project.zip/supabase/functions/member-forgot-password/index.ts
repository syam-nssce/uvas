import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { action, email, date_of_birth, new_password, reset_token } =
      await req.json();

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    // --- Verify identity and issue reset token ---
    if (action === "verify") {
      if (!email || !date_of_birth) {
        return json({ error: "Email and date of birth are required" }, 400);
      }

      const { data: member, error: fetchError } = await supabase
        .from("members")
        .select("id, email, date_of_birth")
        .eq("email", email.trim().toLowerCase())
        .maybeSingle();

      if (fetchError || !member) {
        return json({ error: "No member found with this email." }, 404);
      }

      if (!member.date_of_birth) {
        return json(
          { error: "Date of birth not on record. Contact UVAS." },
          400
        );
      }

      if (member.date_of_birth !== date_of_birth) {
        return json({ error: "Date of birth does not match." }, 401);
      }

      // Issue a short-lived reset token (5 minutes) instead of returning member_id
      const token = await signToken(
        { sub: member.id, purpose: "reset", exp: Date.now() + 5 * 60 * 1000 },
        serviceRoleKey
      );

      return json({ success: true, reset_token: token });
    }

    // --- Reset password using signed token ---
    if (action === "reset") {
      if (!reset_token || !new_password) {
        return json(
          { error: "Reset token and new password are required" },
          400
        );
      }

      if (new_password.length < 8) {
        return json(
          { error: "Password must be at least 8 characters." },
          400
        );
      }

      // Verify the reset token
      const payload = await verifyToken(reset_token, serviceRoleKey);
      if (!payload || payload.purpose !== "reset") {
        return json(
          { error: "Invalid or expired reset link. Please try again." },
          401
        );
      }

      const { error: updateError } = await supabase.rpc(
        "update_member_password",
        { p_member_id: payload.sub, new_password }
      );

      if (updateError) {
        return json({ error: "Password reset failed." }, 500);
      }

      return json({ success: true });
    }

    return json({ error: "Invalid action" }, 400);
  } catch (_err) {
    return json({ error: "An error occurred" }, 500);
  }
});

function json(body: Record<string, unknown>, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function signToken(
  payload: Record<string, unknown>,
  secret: string
): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw", enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const data = JSON.stringify(payload);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(data));
  return btoa(data) + "." + btoa(String.fromCharCode(...new Uint8Array(sig)));
}

async function verifyToken(
  token: string,
  secret: string
): Promise<Record<string, any> | null> {
  try {
    const [p, s] = token.split(".");
    const data = atob(p);
    const parsed = JSON.parse(data);
    if (parsed.exp && parsed.exp < Date.now()) return null;
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw", enc.encode(secret),
      { name: "HMAC", hash: "SHA-256" }, false, ["verify"]
    );
    const sig = Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
    return (await crypto.subtle.verify("HMAC", key, sig, enc.encode(data)))
      ? parsed
      : null;
  } catch {
    return null;
  }
}
