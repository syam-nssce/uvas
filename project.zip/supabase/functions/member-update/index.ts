import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") { return new Response("ok", { headers: corsHeaders }); }
  try {
    const { action, member_id, token, utr_reference, update_data } = await req.json();
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    // Verify member token if provided
    if (token) {
      const payload = await verifyToken(token, serviceRoleKey);
      if (!payload) {
        return new Response(JSON.stringify({ error: "Invalid or expired session" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      // Ensure member can only update their own record
      if (member_id && member_id !== payload.sub) {
        return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
    }

    if (!member_id) {
      return new Response(JSON.stringify({ error: "Member ID is required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "submit_payment") {
      if (!utr_reference) { return new Response(JSON.stringify({ error: "UTR reference is required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      const { error: updateError } = await supabase.from("members").update({ utr_reference, payment_status: "submitted" }).eq("id", member_id);
      if (updateError) { return new Response(JSON.stringify({ error: updateError.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      return new Response(JSON.stringify({ success: true }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "update_profile") {
      if (!update_data || typeof update_data !== "object") { return new Response(JSON.stringify({ error: "Update data is required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      delete update_data.password;
      delete update_data.id;
      delete update_data.status;
      delete update_data.payment_status;
      delete update_data.user_id;
      const { error: updateError } = await supabase.from("members").update(update_data).eq("id", member_id);
      if (updateError) { return new Response(JSON.stringify({ error: updateError.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
      return new Response(JSON.stringify({ success: true }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (_err) {
    return new Response(JSON.stringify({ error: "An error occurred" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

async function verifyToken(token: string, secret: string): Promise<Record<string, any> | null> {
  try {
    const [p, s] = token.split(".");
    const data = atob(p);
    const parsed = JSON.parse(data);
    if (parsed.exp && parsed.exp < Date.now()) return null;
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
    const sig = Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
    return (await crypto.subtle.verify("HMAC", key, sig, enc.encode(data))) ? parsed : null;
  } catch { return null; }
}
