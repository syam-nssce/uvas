import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const ALLOWED_BUCKETS = ["gallery-images", "committee-photos", "documents"] as const;

type AllowedBucket = (typeof ALLOWED_BUCKETS)[number];

function json(body: Record<string, unknown>, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function sanitizeFolder(folder?: string) {
  return (folder || "")
    .split("/")
    .map((segment) => segment.replace(/[^a-zA-Z0-9_-]/g, "-").trim())
    .filter(Boolean)
    .join("/");
}

function sanitizeFileName(fileName: string) {
  const lastDotIndex = fileName.lastIndexOf(".");
  const baseName = lastDotIndex >= 0 ? fileName.slice(0, lastDotIndex) : fileName;
  const extension = lastDotIndex >= 0 ? fileName.slice(lastDotIndex).toLowerCase() : "";
  const safeBaseName = baseName
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "") || "file";

  return `${Date.now()}-${safeBaseName}${extension}`;
}

function decodeBase64(base64: string) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);

  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }

  return bytes;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { username, password, bucket, folder, file_name, file_base64, content_type } = body;

    if (!username || !password) {
      return json({ error: "Admin credentials required" }, 401);
    }

    if (!bucket || !ALLOWED_BUCKETS.includes(bucket)) {
      return json({ error: "Invalid bucket" }, 400);
    }

    if (!file_name || !file_base64) {
      return json({ error: "File data required" }, 400);
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    const { data: adminUser } = await supabase
      .from("admin_users")
      .select("id, password_hash")
      .eq("username", username)
      .eq("is_active", true)
      .maybeSingle();

    if (!adminUser) {
      return json({ error: "Unauthorized" }, 401);
    }

    const { data: passwordMatches } = await supabase.rpc("verify_admin_password", {
      input_password: password,
      stored_hash: adminUser.password_hash,
    });

    if (!passwordMatches) {
      return json({ error: "Unauthorized" }, 401);
    }

    const normalizedFolder = sanitizeFolder(folder);
    const normalizedFileName = sanitizeFileName(file_name);
    const filePath = normalizedFolder ? `${normalizedFolder}/${normalizedFileName}` : normalizedFileName;
    const fileBytes = decodeBase64(file_base64);

    const { error: uploadError } = await supabase.storage
      .from(bucket as AllowedBucket)
      .upload(filePath, fileBytes, {
        upsert: false,
        contentType: content_type || "application/octet-stream",
      });

    if (uploadError) {
      return json({ error: uploadError.message }, 500);
    }

    const { data: publicUrlData } = supabase.storage
      .from(bucket as AllowedBucket)
      .getPublicUrl(filePath);

    return json({
      success: true,
      publicUrl: publicUrlData.publicUrl,
      path: filePath,
    });
  } catch (_error) {
    return json({ error: "An error occurred" }, 500);
  }
});