
-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Members table
CREATE TABLE public.members (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  institution TEXT,
  designation TEXT,
  membership_type TEXT NOT NULL DEFAULT 'regular' CHECK (membership_type IN ('regular', 'associate', 'life', 'admin')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('active', 'pending', 'expired', 'retired')),
  joined_date DATE NOT NULL DEFAULT CURRENT_DATE,
  renewal_date DATE,
  retirement_date DATE,
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('paid', 'pending', 'failed')),
  payment_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members are viewable by everyone" ON public.members FOR SELECT USING (true);
CREATE POLICY "Members can insert themselves" ON public.members FOR INSERT WITH CHECK (true);
CREATE POLICY "Members can update own record" ON public.members FOR UPDATE USING (auth.uid() = user_id);
CREATE TRIGGER update_members_updated_at BEFORE UPDATE ON public.members FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- News & Events table
CREATE TABLE public.news_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type TEXT NOT NULL CHECK (type IN ('news', 'event')),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  image_url TEXT,
  document_url TEXT,
  event_date DATE,
  posted_date DATE DEFAULT CURRENT_DATE,
  published BOOLEAN NOT NULL DEFAULT false,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.news_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "News events are viewable by everyone" ON public.news_events FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert news_events" ON public.news_events FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can update news_events" ON public.news_events FOR UPDATE USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can delete news_events" ON public.news_events FOR DELETE USING (auth.uid() IS NOT NULL);
CREATE TRIGGER update_news_events_updated_at BEFORE UPDATE ON public.news_events FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Helpdesk Posts table
CREATE TABLE public.helpdesk_posts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  member_id UUID REFERENCES public.members(id) ON DELETE CASCADE NOT NULL,
  topic TEXT NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'answered', 'closed')),
  views INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.helpdesk_posts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Helpdesk posts are viewable by everyone" ON public.helpdesk_posts FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert helpdesk posts" ON public.helpdesk_posts FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can update helpdesk posts" ON public.helpdesk_posts FOR UPDATE USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can delete helpdesk posts" ON public.helpdesk_posts FOR DELETE USING (auth.uid() IS NOT NULL);
CREATE TRIGGER update_helpdesk_posts_updated_at BEFORE UPDATE ON public.helpdesk_posts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Helpdesk Replies table
CREATE TABLE public.helpdesk_replies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID REFERENCES public.helpdesk_posts(id) ON DELETE CASCADE NOT NULL,
  member_id UUID REFERENCES public.members(id) ON DELETE CASCADE NOT NULL,
  content TEXT NOT NULL,
  is_admin BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.helpdesk_replies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Helpdesk replies are viewable by everyone" ON public.helpdesk_replies FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert replies" ON public.helpdesk_replies FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

-- Orders & Circulars table
CREATE TABLE public.orders_circulars (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type TEXT NOT NULL CHECK (type IN ('order', 'circular')),
  reference_number TEXT NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  category TEXT,
  tags TEXT[] DEFAULT '{}',
  document_url TEXT,
  issue_date DATE NOT NULL DEFAULT CURRENT_DATE,
  published BOOLEAN NOT NULL DEFAULT false,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.orders_circulars ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Orders circulars are viewable by everyone" ON public.orders_circulars FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert orders_circulars" ON public.orders_circulars FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can update orders_circulars" ON public.orders_circulars FOR UPDATE USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can delete orders_circulars" ON public.orders_circulars FOR DELETE USING (auth.uid() IS NOT NULL);
CREATE TRIGGER update_orders_circulars_updated_at BEFORE UPDATE ON public.orders_circulars FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Gallery table
CREATE TABLE public.gallery (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  image_url TEXT NOT NULL,
  category TEXT,
  event_date DATE,
  display_order INTEGER NOT NULL DEFAULT 0,
  published BOOLEAN NOT NULL DEFAULT false,
  uploaded_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.gallery ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Gallery items are viewable by everyone" ON public.gallery FOR SELECT USING (true);
CREATE POLICY "Authenticated users can manage gallery" ON public.gallery FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can update gallery" ON public.gallery FOR UPDATE USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can delete gallery" ON public.gallery FOR DELETE USING (auth.uid() IS NOT NULL);
CREATE TRIGGER update_gallery_updated_at BEFORE UPDATE ON public.gallery FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Committee Members table
CREATE TABLE public.committee_members (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name TEXT NOT NULL,
  designation TEXT NOT NULL,
  committee_type TEXT NOT NULL,
  district TEXT,
  mobile TEXT,
  email TEXT,
  photo_url TEXT,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.committee_members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Committee members are viewable by everyone" ON public.committee_members FOR SELECT USING (true);
CREATE POLICY "Authenticated users can manage committee" ON public.committee_members FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can update committee" ON public.committee_members FOR UPDATE USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can delete committee" ON public.committee_members FOR DELETE USING (auth.uid() IS NOT NULL);
CREATE TRIGGER update_committee_members_updated_at BEFORE UPDATE ON public.committee_members FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Prajnabharati Journals table
CREATE TABLE public.prajnabharati_journals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  volume INTEGER NOT NULL,
  issue INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  cover_image_url TEXT,
  pdf_url TEXT,
  publication_date DATE NOT NULL,
  published BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.prajnabharati_journals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Journals are viewable by everyone" ON public.prajnabharati_journals FOR SELECT USING (true);
CREATE POLICY "Authenticated users can manage journals" ON public.prajnabharati_journals FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can update journals" ON public.prajnabharati_journals FOR UPDATE USING (auth.uid() IS NOT NULL);

-- News Ticker table
CREATE TABLE public.news_ticker (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  message TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.news_ticker ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Ticker messages are viewable by everyone" ON public.news_ticker FOR SELECT USING (true);
CREATE POLICY "Authenticated users can manage ticker" ON public.news_ticker FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can update ticker" ON public.news_ticker FOR UPDATE USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can delete ticker" ON public.news_ticker FOR DELETE USING (auth.uid() IS NOT NULL);

-- Site Settings table
CREATE TABLE public.site_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  setting_key TEXT NOT NULL UNIQUE,
  setting_value TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Settings are viewable by everyone" ON public.site_settings FOR SELECT USING (true);
CREATE POLICY "Authenticated users can manage settings" ON public.site_settings FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users can update settings" ON public.site_settings FOR UPDATE USING (auth.uid() IS NOT NULL);

-- Admin Users table
CREATE TABLE public.admin_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admin users readable by all" ON public.admin_users FOR SELECT USING (true);

-- Insert default admin user
INSERT INTO public.admin_users (username, email, password_hash, is_active)
VALUES ('admin', 'admin@uvaskerala.org', 'hash:admin123', true);

-- Insert default site settings
INSERT INTO public.site_settings (setting_key, setting_value) VALUES
('site_title', 'UVAS Kerala Wing'),
('hero_title', 'University Vedic Astrology Society'),
('hero_subtitle', 'Kerala Wing - ABRSM');

-- Insert sample ticker messages
INSERT INTO public.news_ticker (message, is_active, display_order) VALUES
('Welcome to UVAS Kerala Wing - ABRSM Official Website', true, 1),
('New membership registrations are now open', true, 2),
('Annual General Meeting scheduled - Check Events section', true, 3);
