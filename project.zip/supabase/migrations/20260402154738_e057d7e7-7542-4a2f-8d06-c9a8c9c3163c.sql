
-- Remove the authenticated-only policy (app doesn't use Supabase Auth)
DROP POLICY IF EXISTS "Members readable by authenticated owner only" ON public.members;

-- Re-add public read access (passwords are now bcrypt-hashed)
CREATE POLICY "Members are viewable by everyone" ON public.members
  FOR SELECT TO public
  USING (true);
