ALTER TABLE public.members ALTER COLUMN joined_date DROP NOT NULL;
ALTER TABLE public.members ALTER COLUMN joined_date DROP DEFAULT;