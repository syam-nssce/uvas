
-- Create storage bucket for hero slider images
INSERT INTO storage.buckets (id, name, public) VALUES ('hero-slides', 'hero-slides', true);

-- Allow anyone to view hero slides
CREATE POLICY "Hero slides are viewable by everyone" ON storage.objects FOR SELECT USING (bucket_id = 'hero-slides');

-- Allow anon to upload hero slides (admin uses anon key)
CREATE POLICY "Allow upload hero slides" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'hero-slides');

-- Allow anon to delete hero slides
CREATE POLICY "Allow delete hero slides" ON storage.objects FOR DELETE USING (bucket_id = 'hero-slides');
