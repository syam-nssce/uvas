
-- Create a secure view that excludes the password column
CREATE VIEW public.members_public
WITH (security_invoker = on) AS
SELECT id, full_name, email, mobile, date_of_birth, phone, house_address, district, religion, 
       employee_id, designation, college_name, college_address, college_type, university,
       area_of_specialization, experience_years, retirement_date, membership_type, membership_category,
       status, payment_status, joined_date, renewal_date, address, institution, payment_id, 
       utr_reference, user_id, created_at, updated_at
FROM public.members;

-- Allow everyone to read from the members table (needed for the view with security_invoker)
CREATE POLICY "Members are readable by everyone"
ON public.members FOR SELECT
USING (true);
