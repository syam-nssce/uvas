
-- Function to verify admin password
CREATE OR REPLACE FUNCTION public.verify_admin_password(input_password text, stored_hash text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, extensions
AS $$
  SELECT stored_hash = extensions.crypt(input_password, stored_hash);
$$;

-- Function to update admin password  
CREATE OR REPLACE FUNCTION public.update_admin_password(admin_id uuid, new_password text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  UPDATE public.admin_users 
  SET password_hash = extensions.crypt(new_password, extensions.gen_salt('bf'))
  WHERE id = admin_id;
END;
$$;

-- Revoke direct access from anon/public
REVOKE EXECUTE ON FUNCTION public.verify_admin_password(text, text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.update_admin_password(uuid, text) FROM anon, public;

-- Grant only to service_role (used by edge functions)
GRANT EXECUTE ON FUNCTION public.verify_admin_password(text, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.update_admin_password(uuid, text) TO service_role;
