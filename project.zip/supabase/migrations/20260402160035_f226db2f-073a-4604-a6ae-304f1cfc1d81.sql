
-- ============================================
-- SECURITY HARDENING: Drop all anonymous write policies
-- ============================================

-- 1. Ensure RLS is enabled on admin_users
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

-- 2. Drop ALL anonymous write policies on CMS tables
-- committee_members
DROP POLICY IF EXISTS "Allow anon delete on committee_members" ON public.committee_members;
DROP POLICY IF EXISTS "Allow anon insert on committee_members" ON public.committee_members;
DROP POLICY IF EXISTS "Allow anon update on committee_members" ON public.committee_members;

-- orders_circulars
DROP POLICY IF EXISTS "Allow anon delete on orders_circulars" ON public.orders_circulars;
DROP POLICY IF EXISTS "Allow anon insert on orders_circulars" ON public.orders_circulars;
DROP POLICY IF EXISTS "Allow anon update on orders_circulars" ON public.orders_circulars;

-- gallery
DROP POLICY IF EXISTS "Allow anon delete on gallery" ON public.gallery;
DROP POLICY IF EXISTS "Allow anon insert on gallery" ON public.gallery;
DROP POLICY IF EXISTS "Allow anon update on gallery" ON public.gallery;

-- prajnabharati_journals
DROP POLICY IF EXISTS "Allow anon delete on prajnabharati_journals" ON public.prajnabharati_journals;
DROP POLICY IF EXISTS "Allow anon insert on prajnabharati_journals" ON public.prajnabharati_journals;
DROP POLICY IF EXISTS "Allow anon update on prajnabharati_journals" ON public.prajnabharati_journals;

-- news_events
DROP POLICY IF EXISTS "Allow anon delete on news_events" ON public.news_events;
DROP POLICY IF EXISTS "Allow anon insert on news_events" ON public.news_events;
DROP POLICY IF EXISTS "Allow anon update on news_events" ON public.news_events;

-- helpdesk_posts
DROP POLICY IF EXISTS "Allow anon delete on helpdesk_posts" ON public.helpdesk_posts;
DROP POLICY IF EXISTS "Allow anon insert on helpdesk_posts" ON public.helpdesk_posts;
DROP POLICY IF EXISTS "Allow anon update on helpdesk_posts" ON public.helpdesk_posts;

-- helpdesk_replies
DROP POLICY IF EXISTS "Allow anon delete on helpdesk_replies" ON public.helpdesk_replies;
DROP POLICY IF EXISTS "Anon can insert non-admin replies only" ON public.helpdesk_replies;
DROP POLICY IF EXISTS "Anon can update non-admin fields only" ON public.helpdesk_replies;

-- news_ticker
DROP POLICY IF EXISTS "Allow anon delete on news_ticker" ON public.news_ticker;
DROP POLICY IF EXISTS "Allow anon insert on news_ticker" ON public.news_ticker;
DROP POLICY IF EXISTS "Allow anon update on news_ticker" ON public.news_ticker;

-- 3. Lock down members table (all access now via edge functions with service role)
DROP POLICY IF EXISTS "Members are viewable by everyone" ON public.members;
DROP POLICY IF EXISTS "Members can insert themselves" ON public.members;
DROP POLICY IF EXISTS "Members can update own record" ON public.members;
