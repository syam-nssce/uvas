
ALTER TABLE public.members 
ADD COLUMN IF NOT EXISTS experience_years integer DEFAULT NULL,
ADD COLUMN IF NOT EXISTS area_of_specialization text DEFAULT NULL;
