
-- Allow anon to insert, update, delete on all admin-managed tables
-- news_events
CREATE POLICY "Allow anon insert on news_events" ON public.news_events FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update on news_events" ON public.news_events FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete on news_events" ON public.news_events FOR DELETE TO anon USING (true);

-- orders_circulars
CREATE POLICY "Allow anon insert on orders_circulars" ON public.orders_circulars FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update on orders_circulars" ON public.orders_circulars FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete on orders_circulars" ON public.orders_circulars FOR DELETE TO anon USING (true);

-- gallery
CREATE POLICY "Allow anon insert on gallery" ON public.gallery FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update on gallery" ON public.gallery FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete on gallery" ON public.gallery FOR DELETE TO anon USING (true);

-- committee_members
CREATE POLICY "Allow anon insert on committee_members" ON public.committee_members FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update on committee_members" ON public.committee_members FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete on committee_members" ON public.committee_members FOR DELETE TO anon USING (true);

-- site_settings
CREATE POLICY "Allow anon insert on site_settings" ON public.site_settings FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update on site_settings" ON public.site_settings FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete on site_settings" ON public.site_settings FOR DELETE TO anon USING (true);

-- news_ticker
CREATE POLICY "Allow anon insert on news_ticker" ON public.news_ticker FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update on news_ticker" ON public.news_ticker FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete on news_ticker" ON public.news_ticker FOR DELETE TO anon USING (true);

-- helpdesk_posts
CREATE POLICY "Allow anon insert on helpdesk_posts" ON public.helpdesk_posts FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update on helpdesk_posts" ON public.helpdesk_posts FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete on helpdesk_posts" ON public.helpdesk_posts FOR DELETE TO anon USING (true);

-- helpdesk_replies
CREATE POLICY "Allow anon insert on helpdesk_replies" ON public.helpdesk_replies FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update on helpdesk_replies" ON public.helpdesk_replies FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete on helpdesk_replies" ON public.helpdesk_replies FOR DELETE TO anon USING (true);

-- members
CREATE POLICY "Allow anon insert on members" ON public.members FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update on members" ON public.members FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete on members" ON public.members FOR DELETE TO anon USING (true);

-- prajnabharati_journals
CREATE POLICY "Allow anon insert on prajnabharati_journals" ON public.prajnabharati_journals FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update on prajnabharati_journals" ON public.prajnabharati_journals FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete on prajnabharati_journals" ON public.prajnabharati_journals FOR DELETE TO anon USING (true);

-- admin_users
CREATE POLICY "Allow anon update on admin_users" ON public.admin_users FOR UPDATE TO anon USING (true) WITH CHECK (true);
