insert into storage.buckets (id, name, public)
values
  ('gallery-images', 'gallery-images', true),
  ('committee-photos', 'committee-photos', true),
  ('documents', 'documents', true)
on conflict (id) do update
set name = excluded.name,
    public = excluded.public;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'storage'
      and tablename = 'objects'
      and policyname = 'Gallery images are viewable by everyone'
  ) then
    create policy "Gallery images are viewable by everyone"
    on storage.objects
    for select
    using (bucket_id = 'gallery-images');
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'storage'
      and tablename = 'objects'
      and policyname = 'Committee photos are viewable by everyone'
  ) then
    create policy "Committee photos are viewable by everyone"
    on storage.objects
    for select
    using (bucket_id = 'committee-photos');
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'storage'
      and tablename = 'objects'
      and policyname = 'Documents are viewable by everyone'
  ) then
    create policy "Documents are viewable by everyone"
    on storage.objects
    for select
    using (bucket_id = 'documents');
  end if;
end $$;