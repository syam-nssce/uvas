
-- Add missing columns to members table that the original app uses
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS date_of_birth DATE;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS mobile TEXT;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS religion TEXT;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS password TEXT;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS house_address TEXT;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS employee_id TEXT;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS college_type TEXT;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS district TEXT;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS university TEXT;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS college_name TEXT;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS college_address TEXT;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS membership_category TEXT;
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS utr_reference TEXT;
