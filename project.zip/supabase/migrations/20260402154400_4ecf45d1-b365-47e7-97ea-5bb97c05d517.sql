
-- Function to verify member password (bcrypt compare)
CREATE OR REPLACE FUNCTION public.verify_member_password(input_password text, stored_hash text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, extensions
AS $$
  SELECT stored_hash = extensions.crypt(input_password, stored_hash);
$$;

-- Function to hash a password
CREATE OR REPLACE FUNCTION public.hash_password(plain_password text)
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, extensions
AS $$
  SELECT extensions.crypt(plain_password, extensions.gen_salt('bf'));
$$;

-- Function to update member password
CREATE OR REPLACE FUNCTION public.update_member_password(p_member_id uuid, new_password text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  UPDATE public.members 
  SET password = extensions.crypt(new_password, extensions.gen_salt('bf'))
  WHERE id = p_member_id;
END;
$$;

-- Restrict these functions to service_role only
REVOKE EXECUTE ON FUNCTION public.verify_member_password(text, text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.hash_password(text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.update_member_password(uuid, text) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.verify_member_password(text, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.hash_password(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.update_member_password(uuid, text) TO service_role;

-- Hash all existing plaintext member passwords (those not already bcrypt-hashed)
UPDATE public.members 
SET password = extensions.crypt(password, extensions.gen_salt('bf'))
WHERE password IS NOT NULL AND password != '' AND password NOT LIKE '$2%';

-- Remove anon write policies on members
DROP POLICY IF EXISTS "Allow anon delete on members" ON public.members;
DROP POLICY IF EXISTS "Allow anon insert on members" ON public.members;
DROP POLICY IF EXISTS "Allow anon update on members" ON public.members;

-- Remove overly permissive public SELECT that exposes passwords
DROP POLICY IF EXISTS "Members are viewable by everyone" ON public.members;

-- Add a restricted SELECT policy: only service_role (edge functions) can read all members
-- Public/anon gets no SELECT access
CREATE POLICY "Members readable by authenticated owner only" ON public.members
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

-- Fix helpdesk_replies: authenticated users also cannot set is_admin=true
DROP POLICY IF EXISTS "Authenticated users can insert replies" ON public.helpdesk_replies;
CREATE POLICY "Authenticated users can insert non-admin replies" ON public.helpdesk_replies
  FOR INSERT TO authenticated
  WITH CHECK (is_admin = false);
