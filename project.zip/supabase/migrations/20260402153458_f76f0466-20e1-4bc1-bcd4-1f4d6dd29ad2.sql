
-- Enable pgcrypto for password hashing
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Hash existing admin passwords properly
UPDATE public.admin_users 
SET password_hash = crypt(replace(password_hash, 'hash:', ''), gen_salt('bf'))
WHERE password_hash LIKE 'hash:%';

-- Hash any admin passwords that aren't bcrypt hashed yet
UPDATE public.admin_users 
SET password_hash = crypt(password_hash, gen_salt('bf'))
WHERE password_hash NOT LIKE '$2%';

-- Drop the overly permissive admin_users policies
DROP POLICY IF EXISTS "Admin users readable by all" ON public.admin_users;
DROP POLICY IF EXISTS "Allow anon update on admin_users" ON public.admin_users;

-- Drop site_settings anon write policies  
DROP POLICY IF EXISTS "Allow anon delete on site_settings" ON public.site_settings;
DROP POLICY IF EXISTS "Allow anon insert on site_settings" ON public.site_settings;
DROP POLICY IF EXISTS "Allow anon update on site_settings" ON public.site_settings;

-- Fix helpdesk_replies: prevent anon from setting is_admin = true
DROP POLICY IF EXISTS "Allow anon insert on helpdesk_replies" ON public.helpdesk_replies;
CREATE POLICY "Anon can insert non-admin replies only" ON public.helpdesk_replies
  FOR INSERT TO anon
  WITH CHECK (is_admin = false);

-- Fix helpdesk_replies: prevent anon from updating is_admin
DROP POLICY IF EXISTS "Allow anon update on helpdesk_replies" ON public.helpdesk_replies;
CREATE POLICY "Anon can update non-admin fields only" ON public.helpdesk_replies
  FOR UPDATE TO anon
  USING (true)
  WITH CHECK (is_admin = false);
