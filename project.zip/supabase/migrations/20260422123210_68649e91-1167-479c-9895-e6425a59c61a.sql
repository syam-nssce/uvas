ALTER TABLE public.members
  ADD COLUMN IF NOT EXISTS orcid_id text,
  ADD COLUMN IF NOT EXISTS google_scholar_url text,
  ADD COLUMN IF NOT EXISTS vidwan_id text,
  ADD COLUMN IF NOT EXISTS researcher_id text,
  ADD COLUMN IF NOT EXISTS scopus_id text;