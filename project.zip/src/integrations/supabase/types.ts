export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.4"
  }
  public: {
    Tables: {
      admin_users: {
        Row: {
          created_at: string
          email: string
          id: string
          is_active: boolean
          password_hash: string
          username: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          is_active?: boolean
          password_hash: string
          username: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          is_active?: boolean
          password_hash?: string
          username?: string
        }
        Relationships: []
      }
      committee_members: {
        Row: {
          committee_type: string
          created_at: string
          designation: string
          display_order: number
          district: string | null
          email: string | null
          full_name: string
          id: string
          is_active: boolean
          mobile: string | null
          photo_url: string | null
          updated_at: string
        }
        Insert: {
          committee_type: string
          created_at?: string
          designation: string
          display_order?: number
          district?: string | null
          email?: string | null
          full_name: string
          id?: string
          is_active?: boolean
          mobile?: string | null
          photo_url?: string | null
          updated_at?: string
        }
        Update: {
          committee_type?: string
          created_at?: string
          designation?: string
          display_order?: number
          district?: string | null
          email?: string | null
          full_name?: string
          id?: string
          is_active?: boolean
          mobile?: string | null
          photo_url?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      gallery: {
        Row: {
          category: string | null
          created_at: string
          description: string | null
          display_order: number
          event_date: string | null
          id: string
          image_url: string
          published: boolean
          title: string
          updated_at: string
          uploaded_by: string | null
        }
        Insert: {
          category?: string | null
          created_at?: string
          description?: string | null
          display_order?: number
          event_date?: string | null
          id?: string
          image_url: string
          published?: boolean
          title: string
          updated_at?: string
          uploaded_by?: string | null
        }
        Update: {
          category?: string | null
          created_at?: string
          description?: string | null
          display_order?: number
          event_date?: string | null
          id?: string
          image_url?: string
          published?: boolean
          title?: string
          updated_at?: string
          uploaded_by?: string | null
        }
        Relationships: []
      }
      helpdesk_posts: {
        Row: {
          content: string
          created_at: string
          document_url: string | null
          id: string
          member_id: string
          status: string
          title: string
          topic: string
          updated_at: string
          views: number
        }
        Insert: {
          content: string
          created_at?: string
          document_url?: string | null
          id?: string
          member_id: string
          status?: string
          title: string
          topic: string
          updated_at?: string
          views?: number
        }
        Update: {
          content?: string
          created_at?: string
          document_url?: string | null
          id?: string
          member_id?: string
          status?: string
          title?: string
          topic?: string
          updated_at?: string
          views?: number
        }
        Relationships: [
          {
            foreignKeyName: "helpdesk_posts_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "helpdesk_posts_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "members_public"
            referencedColumns: ["id"]
          },
        ]
      }
      helpdesk_replies: {
        Row: {
          approved: boolean
          content: string
          created_at: string
          id: string
          is_admin: boolean
          member_id: string
          post_id: string
        }
        Insert: {
          approved?: boolean
          content: string
          created_at?: string
          id?: string
          is_admin?: boolean
          member_id: string
          post_id: string
        }
        Update: {
          approved?: boolean
          content?: string
          created_at?: string
          id?: string
          is_admin?: boolean
          member_id?: string
          post_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "helpdesk_replies_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "helpdesk_replies_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "members_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "helpdesk_replies_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "helpdesk_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      members: {
        Row: {
          address: string | null
          area_of_specialization: string | null
          college_address: string | null
          college_name: string | null
          college_type: string | null
          created_at: string
          date_of_birth: string | null
          designation: string | null
          district: string | null
          email: string
          employee_id: string | null
          experience_years: number | null
          full_name: string
          google_scholar_url: string | null
          house_address: string | null
          id: string
          institution: string | null
          joined_date: string | null
          last_renewal_date: string | null
          membership_category: string | null
          membership_type: string
          mobile: string | null
          orcid_id: string | null
          password: string | null
          payment_id: string | null
          payment_status: string
          phone: string | null
          religion: string | null
          renewal_date: string | null
          researcher_id: string | null
          retirement_date: string | null
          scopus_id: string | null
          service_joining_date: string | null
          status: string
          university: string | null
          updated_at: string
          user_id: string | null
          utr_reference: string | null
          vidwan_id: string | null
        }
        Insert: {
          address?: string | null
          area_of_specialization?: string | null
          college_address?: string | null
          college_name?: string | null
          college_type?: string | null
          created_at?: string
          date_of_birth?: string | null
          designation?: string | null
          district?: string | null
          email: string
          employee_id?: string | null
          experience_years?: number | null
          full_name: string
          google_scholar_url?: string | null
          house_address?: string | null
          id?: string
          institution?: string | null
          joined_date?: string | null
          last_renewal_date?: string | null
          membership_category?: string | null
          membership_type?: string
          mobile?: string | null
          orcid_id?: string | null
          password?: string | null
          payment_id?: string | null
          payment_status?: string
          phone?: string | null
          religion?: string | null
          renewal_date?: string | null
          researcher_id?: string | null
          retirement_date?: string | null
          scopus_id?: string | null
          service_joining_date?: string | null
          status?: string
          university?: string | null
          updated_at?: string
          user_id?: string | null
          utr_reference?: string | null
          vidwan_id?: string | null
        }
        Update: {
          address?: string | null
          area_of_specialization?: string | null
          college_address?: string | null
          college_name?: string | null
          college_type?: string | null
          created_at?: string
          date_of_birth?: string | null
          designation?: string | null
          district?: string | null
          email?: string
          employee_id?: string | null
          experience_years?: number | null
          full_name?: string
          google_scholar_url?: string | null
          house_address?: string | null
          id?: string
          institution?: string | null
          joined_date?: string | null
          last_renewal_date?: string | null
          membership_category?: string | null
          membership_type?: string
          mobile?: string | null
          orcid_id?: string | null
          password?: string | null
          payment_id?: string | null
          payment_status?: string
          phone?: string | null
          religion?: string | null
          renewal_date?: string | null
          researcher_id?: string | null
          retirement_date?: string | null
          scopus_id?: string | null
          service_joining_date?: string | null
          status?: string
          university?: string | null
          updated_at?: string
          user_id?: string | null
          utr_reference?: string | null
          vidwan_id?: string | null
        }
        Relationships: []
      }
      news_events: {
        Row: {
          content: string
          created_at: string
          created_by: string | null
          document_url: string | null
          event_date: string | null
          id: string
          image_url: string | null
          posted_date: string | null
          published: boolean
          title: string
          type: string
          updated_at: string
        }
        Insert: {
          content: string
          created_at?: string
          created_by?: string | null
          document_url?: string | null
          event_date?: string | null
          id?: string
          image_url?: string | null
          posted_date?: string | null
          published?: boolean
          title: string
          type: string
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string | null
          document_url?: string | null
          event_date?: string | null
          id?: string
          image_url?: string | null
          posted_date?: string | null
          published?: boolean
          title?: string
          type?: string
          updated_at?: string
        }
        Relationships: []
      }
      news_ticker: {
        Row: {
          created_at: string
          display_order: number
          id: string
          is_active: boolean
          message: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          message: string
        }
        Update: {
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          message?: string
        }
        Relationships: []
      }
      orders_circulars: {
        Row: {
          category: string | null
          content: string
          created_at: string
          created_by: string | null
          document_url: string | null
          id: string
          issue_date: string
          published: boolean
          reference_number: string
          tags: string[] | null
          title: string
          type: string
          updated_at: string
        }
        Insert: {
          category?: string | null
          content: string
          created_at?: string
          created_by?: string | null
          document_url?: string | null
          id?: string
          issue_date?: string
          published?: boolean
          reference_number: string
          tags?: string[] | null
          title: string
          type: string
          updated_at?: string
        }
        Update: {
          category?: string | null
          content?: string
          created_at?: string
          created_by?: string | null
          document_url?: string | null
          id?: string
          issue_date?: string
          published?: boolean
          reference_number?: string
          tags?: string[] | null
          title?: string
          type?: string
          updated_at?: string
        }
        Relationships: []
      }
      prajnabharati_journals: {
        Row: {
          cover_image_url: string | null
          created_at: string
          description: string | null
          id: string
          issue: number
          pdf_url: string | null
          publication_date: string
          published: boolean
          title: string
          volume: number
        }
        Insert: {
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          id?: string
          issue: number
          pdf_url?: string | null
          publication_date: string
          published?: boolean
          title: string
          volume: number
        }
        Update: {
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          id?: string
          issue?: number
          pdf_url?: string | null
          publication_date?: string
          published?: boolean
          title?: string
          volume?: number
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          id: string
          setting_key: string
          setting_value: string
          updated_at: string
        }
        Insert: {
          id?: string
          setting_key: string
          setting_value: string
          updated_at?: string
        }
        Update: {
          id?: string
          setting_key?: string
          setting_value?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      members_public: {
        Row: {
          address: string | null
          area_of_specialization: string | null
          college_address: string | null
          college_name: string | null
          college_type: string | null
          created_at: string | null
          date_of_birth: string | null
          designation: string | null
          district: string | null
          email: string | null
          employee_id: string | null
          experience_years: number | null
          full_name: string | null
          house_address: string | null
          id: string | null
          institution: string | null
          joined_date: string | null
          membership_category: string | null
          membership_type: string | null
          mobile: string | null
          payment_id: string | null
          payment_status: string | null
          phone: string | null
          religion: string | null
          renewal_date: string | null
          retirement_date: string | null
          status: string | null
          university: string | null
          updated_at: string | null
          user_id: string | null
          utr_reference: string | null
        }
        Insert: {
          address?: string | null
          area_of_specialization?: string | null
          college_address?: string | null
          college_name?: string | null
          college_type?: string | null
          created_at?: string | null
          date_of_birth?: string | null
          designation?: string | null
          district?: string | null
          email?: string | null
          employee_id?: string | null
          experience_years?: number | null
          full_name?: string | null
          house_address?: string | null
          id?: string | null
          institution?: string | null
          joined_date?: string | null
          membership_category?: string | null
          membership_type?: string | null
          mobile?: string | null
          payment_id?: string | null
          payment_status?: string | null
          phone?: string | null
          religion?: string | null
          renewal_date?: string | null
          retirement_date?: string | null
          status?: string | null
          university?: string | null
          updated_at?: string | null
          user_id?: string | null
          utr_reference?: string | null
        }
        Update: {
          address?: string | null
          area_of_specialization?: string | null
          college_address?: string | null
          college_name?: string | null
          college_type?: string | null
          created_at?: string | null
          date_of_birth?: string | null
          designation?: string | null
          district?: string | null
          email?: string | null
          employee_id?: string | null
          experience_years?: number | null
          full_name?: string | null
          house_address?: string | null
          id?: string | null
          institution?: string | null
          joined_date?: string | null
          membership_category?: string | null
          membership_type?: string | null
          mobile?: string | null
          payment_id?: string | null
          payment_status?: string | null
          phone?: string | null
          religion?: string | null
          renewal_date?: string | null
          retirement_date?: string | null
          status?: string | null
          university?: string | null
          updated_at?: string | null
          user_id?: string | null
          utr_reference?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      hash_password: { Args: { plain_password: string }; Returns: string }
      update_admin_password: {
        Args: { admin_id: string; new_password: string }
        Returns: undefined
      }
      update_member_password: {
        Args: { new_password: string; p_member_id: string }
        Returns: undefined
      }
      verify_admin_password: {
        Args: { input_password: string; stored_hash: string }
        Returns: boolean
      }
      verify_member_password: {
        Args: { input_password: string; stored_hash: string }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
