import { Menu, X, ChevronDown } from 'lucide-react';
import { useState } from 'react';

interface HeaderProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

const aboutSubmenu = [
  { id: 'about-intro', label: 'Introduction' },
  { id: 'about-abrsm', label: 'ABRSM' },
  { id: 'about-history', label: 'History of UVAS' },
  { id: 'about-vision', label: 'Vision & Mission' },
];

const zonalChildren = [
  { id: 'committee-zonal-kerala', label: 'Kerala University' },
  { id: 'committee-zonal-mg', label: 'MG University' },
  { id: 'committee-zonal-calicut', label: 'Calicut University' },
  { id: 'committee-zonal-kannur', label: 'Kannur University' },
];

const committeeSubmenu: Array<{ id: string; label: string; children?: typeof zonalChildren }> = [
  { id: 'committee-state', label: 'State Committee' },
  { id: 'committee-zonal', label: 'Zonal Committee', children: zonalChildren },
  { id: 'committee-service', label: 'Service Cell' },
];

const menuItems = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About Us', hasDropdown: true, submenu: 'about' },
  { id: 'committee', label: 'Committee', hasDropdown: true, submenu: 'committee' },
  { id: 'membership', label: 'Membership' },
  { id: 'member-login', label: 'Member Login' },
  { id: 'helpdesk', label: 'Help Desk' },
  { id: 'news', label: 'News & Events' },
  { id: 'orders', label: 'Orders & Circulars' },
  { id: 'gallery', label: 'Gallery' },
  { id: 'prajnabharati', label: 'Prajnabharati' },
  { id: 'admin', label: 'Admin' },
];

export default function Header({ activeSection, setActiveSection }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [aboutDropdownOpen, setAboutDropdownOpen] = useState(false);
  const [committeeDropdownOpen, setCommitteeDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center py-3.5">
          <div className="flex items-center mr-4 shrink-0">
            <h1 className="text-lg font-bold text-black tracking-tight whitespace-nowrap">
              UVAS <span className="text-black font-bold text-sm">– ABRSM, Kerala</span>
            </h1>
          </div>

          <nav className="hidden lg:flex items-center justify-center flex-1 space-x-0.5 flex-nowrap" style={{ fontFamily: "'Open Sans', sans-serif" }}>
            {menuItems.map((item) => {
              if (item.hasDropdown) {
                const isAbout = item.submenu === 'about';
                const submenuItems = isAbout ? aboutSubmenu : committeeSubmenu;
                const dropdownOpen = isAbout ? aboutDropdownOpen : committeeDropdownOpen;
                const setDropdownOpen = isAbout ? setAboutDropdownOpen : setCommitteeDropdownOpen;

                return (
                  <div
                    key={item.id}
                    className="relative"
                    onMouseEnter={() => setDropdownOpen(true)}
                    onMouseLeave={() => setDropdownOpen(false)}
                  >
                    <button
                      onClick={() => setDropdownOpen(!dropdownOpen)}
                      className={`px-3 py-2 rounded-md text-[13px] font-medium tracking-wide transition-all duration-200 whitespace-nowrap flex items-center gap-1 uppercase ${
                        submenuItems.some(sub => sub.id === activeSection)
                          ? 'bg-primary text-primary-foreground shadow-sm'
                          : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                      }`}
                    >
                      {item.label}
                      <ChevronDown className={`w-3.5 h-3.5 opacity-60 transition-transform duration-200 ${dropdownOpen ? 'rotate-180' : ''}`} />
                    </button>
                    {dropdownOpen && (
                      <div className="absolute top-full left-0 pt-1">
                        <div className="bg-popover rounded-lg shadow-xl border border-border/80 py-1.5 min-w-[220px] z-50 animate-fade-in">
                          {submenuItems.map((subItem) => {
                            const children = (subItem as { children?: typeof zonalChildren }).children;
                            const hasChildren = !!children && children.length > 0;
                            return (
                              <div key={subItem.id} className="relative group/sub">
                                <button
                                  onClick={() => {
                                    setActiveSection(subItem.id);
                                    setDropdownOpen(false);
                                  }}
                                  className={`w-full text-left px-4 py-2.5 text-sm font-medium transition-colors flex items-center justify-between ${
                                    activeSection === subItem.id || (hasChildren && children!.some(c => c.id === activeSection))
                                      ? 'bg-primary text-primary-foreground'
                                      : 'text-foreground/80 hover:bg-accent/60 hover:text-foreground'
                                  }`}
                                >
                                  <span>{subItem.label}</span>
                                  {hasChildren && <ChevronDown className="w-3.5 h-3.5 -rotate-90 opacity-60" />}
                                </button>
                                {hasChildren && (
                                  <div className="absolute top-0 left-full pl-1 hidden group-hover/sub:block">
                                    <div className="bg-popover rounded-lg shadow-xl border border-border/80 py-1.5 min-w-[200px] z-50 animate-fade-in">
                                      {children!.map((child) => (
                                        <button
                                          key={child.id}
                                          onClick={() => {
                                            setActiveSection(child.id);
                                            setDropdownOpen(false);
                                          }}
                                          className={`w-full text-left px-4 py-2.5 text-sm font-medium transition-colors ${
                                            activeSection === child.id
                                              ? 'bg-primary text-primary-foreground'
                                              : 'text-foreground/80 hover:bg-accent/60 hover:text-foreground'
                                          }`}
                                        >
                                          {child.label}
                                        </button>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                );
              }

              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`px-3 py-2 rounded-md text-[13px] font-medium tracking-wide transition-all duration-200 whitespace-nowrap uppercase ${
                    activeSection === item.id
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-md hover:bg-accent transition-colors"
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5 text-foreground" />
            ) : (
              <Menu className="w-5 h-5 text-foreground" />
            )}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="lg:hidden bg-popover border-t border-border shadow-xl">
          <nav className="px-4 py-3 space-y-1 max-h-[calc(100vh-5rem)] overflow-y-auto" style={{ fontFamily: "'Open Sans', sans-serif" }}>
            {menuItems.map((item) => {
              if (item.hasDropdown) {
                const isAbout = item.submenu === 'about';
                const submenuItems = isAbout ? aboutSubmenu : committeeSubmenu;
                const dropdownOpen = isAbout ? aboutDropdownOpen : committeeDropdownOpen;
                const setDropdownOpen = isAbout ? setAboutDropdownOpen : setCommitteeDropdownOpen;

                return (
                  <div key={item.id} className="space-y-0.5">
                    <button
                      onClick={() => setDropdownOpen(!dropdownOpen)}
                      className={`w-full text-left px-4 py-3 rounded-md text-sm font-medium tracking-wide transition-all duration-200 flex items-center justify-between uppercase ${
                        submenuItems.some(sub => sub.id === activeSection)
                          ? 'bg-primary text-primary-foreground'
                          : 'text-foreground hover:bg-accent'
                      }`}
                    >
                      {item.label}
                      <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${dropdownOpen ? 'rotate-180' : ''}`} />
                    </button>
                    {dropdownOpen && (
                      <div className="ml-3 space-y-0.5 border-l-2 border-border pl-3">
                        {submenuItems.map((subItem) => {
                          const children = (subItem as { children?: typeof zonalChildren }).children;
                          return (
                            <div key={subItem.id}>
                              <button
                                onClick={() => {
                                  setActiveSection(subItem.id);
                                  setMobileMenuOpen(false);
                                  setDropdownOpen(false);
                                }}
                                className={`w-full text-left px-4 py-2.5 rounded-md text-sm font-medium transition-all duration-200 ${
                                  activeSection === subItem.id
                                    ? 'bg-primary text-primary-foreground'
                                    : 'text-muted-foreground hover:bg-accent/60'
                                }`}
                              >
                                {subItem.label}
                              </button>
                              {children && children.length > 0 && (
                                <div className="ml-3 mt-0.5 space-y-0.5 border-l-2 border-border pl-3">
                                  {children.map((child) => (
                                    <button
                                      key={child.id}
                                      onClick={() => {
                                        setActiveSection(child.id);
                                        setMobileMenuOpen(false);
                                        setDropdownOpen(false);
                                      }}
                                      className={`w-full text-left px-4 py-2 rounded-md text-sm transition-all duration-200 ${
                                        activeSection === child.id
                                          ? 'bg-primary text-primary-foreground'
                                          : 'text-muted-foreground hover:bg-accent/60'
                                      }`}
                                    >
                                      {child.label}
                                    </button>
                                  ))}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              }

              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveSection(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-md text-sm font-medium tracking-wide transition-all duration-200 uppercase ${
                    activeSection === item.id
                      ? 'bg-primary text-primary-foreground'
                      : 'text-foreground hover:bg-accent'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>
      )}
    </header>
  );
}
