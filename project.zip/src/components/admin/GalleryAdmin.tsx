import { useState, useEffect } from 'react';
import { supabase, type GalleryItem } from '../../lib/supabase';
import { adminCrud } from '../../lib/adminCrud';
import { uploadAdminFile } from '../../lib/adminStorage';
import { Trash2, Image } from 'lucide-react';

interface GalleryAdminProps {
  adminCredentials?: { username: string; password: string };
}

export default function GalleryAdmin({ adminCredentials }: GalleryAdminProps) {
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    image_url: '',
    category: '',
    event_date: '',
  });
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    const { data } = await supabase
      .from('gallery')
      .select('*')
      .order('created_at', { ascending: false });
    if (data) setItems(data);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminCredentials) return;

    if (!formData.image_url && !uploadedFile) {
      alert('Please provide either an image URL or upload a file');
      return;
    }

    setUploading(true);
    let finalImageUrl = formData.image_url;

    try {
      if (uploadedFile) {
        finalImageUrl = await uploadAdminFile({
          bucket: 'gallery-images',
          folder: 'gallery',
          file: uploadedFile,
          credentials: adminCredentials,
        });
      }

      await adminCrud({
        table: 'gallery',
        action: 'insert',
        data: {
          ...formData,
          image_url: finalImageUrl,
          event_date: formData.event_date || null,
          published: true,
        },
        credentials: adminCredentials,
      });

      resetForm();
      fetchItems();
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!adminCredentials) return;
    if (confirm('Delete this photo?')) {
      try {
        await adminCrud({
          table: 'gallery',
          action: 'delete',
          id,
          credentials: adminCredentials,
        });
        fetchItems();
      } catch (error) {
        console.error('Delete error:', error);
        alert('Failed to delete.');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      image_url: '',
      category: '',
      event_date: '',
    });
    setUploadedFile(null);
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center space-x-2">
        <span>🖼️</span>
        <span>Gallery</span>
      </h2>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="bg-slate-50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-slate-700 mb-4">Add Gallery Photo</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Title *</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="Photo title"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Caption</label>
              <input
                type="text"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="Optional description"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                >
                  <option value="">Select category</option>
                  <option value="Events">Events</option>
                  <option value="Conferences">Conferences</option>
                  <option value="Awards">Awards</option>
                  <option value="Office Bearers">Office Bearers</option>
                  <option value="Others">Others</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Event Date</label>
                <input
                  type="date"
                  value={formData.event_date}
                  onChange={(e) => setFormData({ ...formData, event_date: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="border-t border-slate-200 pt-4 mt-4">
              <p className="text-sm text-slate-600 mb-3 font-medium">Image Source (Choose one or both) *</p>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Upload File</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-amber-50 file:text-amber-700 hover:file:bg-amber-100"
                />
                {uploadedFile && (
                  <p className="text-xs text-green-600 mt-1">File selected: {uploadedFile.name}</p>
                )}
              </div>

              <div className="text-center my-3 text-slate-400 text-sm">OR</div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Image URL</label>
                <input
                  type="url"
                  value={formData.image_url}
                  onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={uploading}
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {uploading ? 'Uploading...' : 'Upload Photo'}
            </button>
          </form>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-slate-700 mb-4">Gallery Items</h3>
          <div className="grid grid-cols-2 gap-4">
            {items.map((item) => (
              <div key={item.id} className="bg-white border border-slate-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                <div className="aspect-video bg-slate-100 flex items-center justify-center overflow-hidden">
                  {item.image_url ? (
                    <img src={item.image_url} alt={item.title} className="w-full h-full object-cover" />
                  ) : (
                    <Image className="w-12 h-12 text-slate-400" />
                  )}
                </div>
                <div className="p-3">
                  <h4 className="font-semibold text-slate-800 text-sm mb-1">{item.title}</h4>
                  {item.category && (
                    <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded">{item.category}</span>
                  )}
                  <div className="flex justify-end mt-2">
                    <button
                      onClick={() => handleDelete(item.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          {items.length === 0 && (
            <div className="bg-slate-50 rounded-xl py-12 text-center text-slate-500">
              <Image className="w-16 h-16 mx-auto mb-3 opacity-50" />
              <p>No photos yet — upload above</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
