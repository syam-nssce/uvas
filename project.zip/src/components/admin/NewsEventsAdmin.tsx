import { useState, useEffect } from 'react';
import { supabase, type NewsEvent } from '../../lib/supabase';
import { adminCrud } from '../../lib/adminCrud';
import { uploadAdminFile } from '../../lib/adminStorage';
import { CreditCard as Edit2, Trash2, Calendar } from 'lucide-react';

interface NewsEventsAdminProps {
  adminCredentials?: { username: string; password: string };
}

export default function NewsEventsAdmin({ adminCredentials }: NewsEventsAdminProps) {
  const [items, setItems] = useState<NewsEvent[]>([]);
  const [formData, setFormData] = useState({
    type: 'event' as 'news' | 'event',
    title: '',
    content: '',
    image_url: '',
    document_url: '',
    event_date: '',
    posted_date: '',
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    const { data } = await supabase
      .from('news_events')
      .select('*')
      .order('created_at', { ascending: false });
    if (data) setItems(data);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminCredentials) return;
    setUploading(true);
    let finalImageUrl = formData.image_url;
    let finalDocumentUrl = formData.document_url;

    try {
      if (uploadedFile) {
        const isPdf = uploadedFile.type === 'application/pdf' || uploadedFile.name.toLowerCase().endsWith('.pdf');
        const uploadedUrl = await uploadAdminFile({
          bucket: isPdf ? 'documents' : 'gallery-images',
          folder: 'news-events',
          file: uploadedFile,
          credentials: adminCredentials,
        });

        if (isPdf) {
          finalDocumentUrl = uploadedUrl;
        } else {
          finalImageUrl = uploadedUrl;
        }
      }

      const dataToSubmit = {
        ...formData,
        image_url: finalImageUrl || null,
        document_url: finalDocumentUrl || null,
        published: true,
        event_date: formData.event_date || null,
        posted_date: formData.posted_date || null,
      };

      if (editingId) {
        await adminCrud({
          table: 'news_events',
          action: 'update',
          id: editingId,
          data: dataToSubmit,
          credentials: adminCredentials,
        });
      } else {
        await adminCrud({
          table: 'news_events',
          action: 'insert',
          data: dataToSubmit,
          credentials: adminCredentials,
        });
      }

      resetForm();
      fetchItems();
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to save. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!adminCredentials) return;
    if (confirm('Delete this item?')) {
      try {
        await adminCrud({
          table: 'news_events',
          action: 'delete',
          id,
          credentials: adminCredentials,
        });
        fetchItems();
      } catch (error) {
        console.error('Delete error:', error);
        alert('Failed to delete.');
      }
    }
  };

  const startEdit = (item: NewsEvent) => {
    setEditingId(item.id);
    setFormData({
      type: item.type as 'news' | 'event',
      title: item.title,
      content: item.content,
      image_url: item.image_url || '',
      document_url: item.document_url || '',
      event_date: item.event_date || '',
      posted_date: item.posted_date || '',
    });
  };

  const resetForm = () => {
    setFormData({ type: 'event', title: '', content: '', image_url: '', document_url: '', event_date: '', posted_date: '' });
    setEditingId(null);
    setUploadedFile(null);
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center space-x-2">
        <span>📰</span>
        <span>News & Events</span>
      </h2>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="bg-slate-50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-slate-700 mb-4">Post News / Event</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Title *</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="Event or news title"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Type *</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as 'news' | 'event' })}
                required
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              >
                <option value="event">Event</option>
                <option value="news">News</option>
              </select>
            </div>

            {formData.type === 'event' ? (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Date of Event *</label>
                  <input
                    type="date"
                    value={formData.event_date}
                    onChange={(e) => setFormData({ ...formData, event_date: e.target.value })}
                    required
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Date of Posting *</label>
                  <input
                    type="date"
                    value={formData.posted_date}
                    onChange={(e) => setFormData({ ...formData, posted_date: e.target.value })}
                    required
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  />
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Date of Posting *</label>
                <input
                  type="date"
                  value={formData.posted_date}
                  onChange={(e) => setFormData({ ...formData, posted_date: e.target.value })}
                  required
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Description *</label>
              <textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                required
                rows={4}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
                placeholder="Full description..."
              />
            </div>

            <div className="border-t border-slate-200 pt-4 mt-4">
              <p className="text-sm text-slate-600 mb-3 font-medium">
                {formData.type === 'news' ? 'Image or Document (Optional)' : 'Image (Optional)'}
              </p>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Upload File</label>
                <input
                  type="file"
                  accept={formData.type === 'news' ? 'image/*,application/pdf' : 'image/*'}
                  onChange={handleFileChange}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-amber-50 file:text-amber-700 hover:file:bg-amber-100"
                />
                {uploadedFile && (
                  <p className="text-xs text-green-600 mt-1">File selected: {uploadedFile.name}</p>
                )}
                {formData.type === 'news' && (
                  <p className="text-xs text-slate-500 mt-1">Accepts images or PDF documents</p>
                )}
              </div>

              <div className="text-center my-3 text-slate-400 text-sm">OR</div>

              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Image URL</label>
                  <input
                    type="url"
                    value={formData.image_url}
                    onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                {formData.type === 'news' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Document URL (PDF)</label>
                    <input
                      type="url"
                      value={formData.document_url}
                      onChange={(e) => setFormData({ ...formData, document_url: e.target.value })}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                      placeholder="https://example.com/document.pdf"
                    />
                  </div>
                )}
              </div>
            </div>

            <div className="flex space-x-3">
              <button
                type="submit"
                disabled={uploading}
                className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {uploading ? 'Uploading...' : (editingId ? 'Update' : 'Publish')}
              </button>
              {editingId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-6 py-3 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 transition-all"
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-slate-700 mb-4">Published Items</h3>
          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.id} className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center flex-wrap gap-2 mb-2">
                      <span
                        className={`text-xs font-semibold px-2 py-1 rounded ${
                          item.type === 'event' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                        }`}
                      >
                        {item.type.toUpperCase()}
                      </span>
                      {item.type === 'event' && item.event_date && (
                        <span className="text-xs text-slate-500 flex items-center">
                          <Calendar className="w-3 h-3 mr-1" />
                          Event: {new Date(item.event_date).toLocaleDateString()}
                        </span>
                      )}
                      {item.posted_date && (
                        <span className="text-xs text-slate-500 flex items-center">
                          Posted: {new Date(item.posted_date).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                    <h4 className="font-semibold text-slate-800">{item.title}</h4>
                    <p className="text-sm text-slate-600 line-clamp-2 mt-1">{item.content}</p>
                  </div>
                  <div className="flex space-x-2 ml-3">
                    <button
                      onClick={() => startEdit(item)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(item.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {items.length === 0 && (
              <div className="text-center py-8 text-slate-500">No items yet</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
