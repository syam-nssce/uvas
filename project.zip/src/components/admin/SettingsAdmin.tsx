import { useState, useEffect } from 'react';
import { supabase, type SiteSetting } from '../../lib/supabase';
import { Save } from 'lucide-react';

interface SettingsAdminProps {
  adminCredentials?: { username: string; password: string };
}

export default function SettingsAdmin({ adminCredentials }: SettingsAdminProps) {
  const [contactData, setContactData] = useState({
    address: '',
    phone: '',
    email: '',
    upi: '',
  });

  const [feesData, setFeesData] = useState({
    new_govt: '',
    new_self: '',
    renew_govt: '',
    renew_self: '',
  });

  const [journalUrl, setJournalUrl] = useState('');
  const [saving, setSaving] = useState(false);

  // Password change state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [passwordSaving, setPasswordSaving] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    const { data } = await supabase.from('site_settings').select('*');
    if (data) {
      const settings: Record<string, string> = {};
      data.forEach((s: SiteSetting) => {
        settings[s.setting_key] = s.setting_value;
      });

      setContactData({
        address: settings.contact_address || 'UVAS Kerala Wing, Affiliated to ABRSM, New Delhi, Kerala, India',
        phone: settings.contact_phone || '+91 XXX XXX XXXX',
        email: settings.contact_email || 'contact@uvas-kerala.org',
        upi: settings.payment_upi || 'syam.sankar8@oksbi',
      });

      setFeesData({
        new_govt: settings.fee_new_govt || '1000',
        new_self: settings.fee_new_self || '1500',
        renew_govt: settings.fee_renew_govt || '600',
        renew_self: settings.fee_renew_self || '800',
      });

      setJournalUrl(settings.journal_url || 'https://prajnabharati.abrsm.in');
    }
  };

  const saveSettingsViaEdgeFunction = async (settingsArray: { key: string; value: string }[]) => {
    if (!adminCredentials) {
      alert('Admin session expired. Please log in again.');
      return false;
    }

    const { data, error } = await supabase.functions.invoke('admin-settings', {
      body: {
        username: adminCredentials.username,
        password: adminCredentials.password,
        settings: settingsArray,
      },
    });

    if (error || !data?.success) {
      alert(data?.error || 'Failed to save settings.');
      return false;
    }
    return true;
  };

  const handleSaveContact = async () => {
    setSaving(true);
    const success = await saveSettingsViaEdgeFunction([
      { key: 'contact_address', value: contactData.address },
      { key: 'contact_phone', value: contactData.phone },
      { key: 'contact_email', value: contactData.email },
      { key: 'payment_upi', value: contactData.upi },
    ]);
    if (success) alert('Contact information saved!');
    setSaving(false);
  };

  const handleSaveFees = async () => {
    setSaving(true);
    const success = await saveSettingsViaEdgeFunction([
      { key: 'fee_new_govt', value: feesData.new_govt },
      { key: 'fee_new_self', value: feesData.new_self },
      { key: 'fee_renew_govt', value: feesData.renew_govt },
      { key: 'fee_renew_self', value: feesData.renew_self },
    ]);
    if (success) alert('Fee structure saved!');
    setSaving(false);
  };

  const handleSaveJournal = async () => {
    setSaving(true);
    const success = await saveSettingsViaEdgeFunction([
      { key: 'journal_url', value: journalUrl },
    ]);
    if (success) alert('Journal URL saved!');
    setSaving(false);
  };

  const handleChangePassword = async () => {
    if (!adminCredentials) {
      alert('Admin session expired. Please log in again.');
      return;
    }
    if (newPassword.length < 8) {
      alert('New password must be at least 8 characters.');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      alert('New passwords do not match.');
      return;
    }

    setPasswordSaving(true);
    try {
      const { data, error } = await supabase.functions.invoke('admin-change-password', {
        body: {
          username: adminCredentials.username,
          currentPassword,
          newPassword,
        },
      });

      if (error || !data?.success) {
        alert(data?.error || 'Failed to change password.');
      } else {
        alert('Password changed successfully! Please log in again with your new password.');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmNewPassword('');
      }
    } catch {
      alert('An error occurred while changing password.');
    } finally {
      setPasswordSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center space-x-2">
        <span>⚙️</span>
        <span>Settings</span>
      </h2>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="bg-slate-50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-slate-700 mb-4">Contact Information</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Organisation Address</label>
              <textarea
                value={contactData.address}
                onChange={(e) => setContactData({ ...contactData, address: e.target.value })}
                rows={3}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Phone</label>
                <input
                  type="tel"
                  value={contactData.phone}
                  onChange={(e) => setContactData({ ...contactData, phone: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                <input
                  type="email"
                  value={contactData.email}
                  onChange={(e) => setContactData({ ...contactData, email: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">UPI ID</label>
              <input
                type="text"
                value={contactData.upi}
                onChange={(e) => setContactData({ ...contactData, upi: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              />
            </div>

            <button
              onClick={handleSaveContact}
              disabled={saving}
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              <Save className="w-5 h-5" />
              <span>Save Contact Info</span>
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-50 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-slate-700 mb-4">Prajnabharati Journal</h3>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Journal External URL</label>
              <input
                type="url"
                value={journalUrl}
                onChange={(e) => setJournalUrl(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="https://prajnabharati.abrsm.in"
              />
            </div>
            <button
              onClick={handleSaveJournal}
              disabled={saving}
              className="mt-4 w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              <Save className="w-5 h-5" />
              <span>Save Journal URL</span>
            </button>
          </div>

          <div className="bg-slate-50 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-slate-700 mb-4">Membership Fees</h3>
            <div className="space-y-4">
              <p className="text-sm font-medium text-slate-600">New Membership</p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Govt/Aided ₹</label>
                  <input
                    type="number"
                    value={feesData.new_govt}
                    onChange={(e) => setFeesData({ ...feesData, new_govt: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Self-Financing ₹</label>
                  <input
                    type="number"
                    value={feesData.new_self}
                    onChange={(e) => setFeesData({ ...feesData, new_self: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  />
                </div>
              </div>

              <p className="text-sm font-medium text-slate-600 pt-2">Renewal</p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Govt/Aided ₹</label>
                  <input
                    type="number"
                    value={feesData.renew_govt}
                    onChange={(e) => setFeesData({ ...feesData, renew_govt: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Self-Financing ₹</label>
                  <input
                    type="number"
                    value={feesData.renew_self}
                    onChange={(e) => setFeesData({ ...feesData, renew_self: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  />
                </div>
              </div>

              <button
                onClick={handleSaveFees}
                disabled={saving}
                className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                <Save className="w-5 h-5" />
                <span>Save Fee Structure</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-slate-50 rounded-xl p-6 mt-8">
        <h3 className="text-lg font-semibold text-slate-700 mb-4">Change Admin Password</h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Current Password</label>
            <input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              placeholder="Enter current password"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">New Password</label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              placeholder="Min. 8 characters"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Confirm New Password</label>
            <input
              type="password"
              value={confirmNewPassword}
              onChange={(e) => setConfirmNewPassword(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              placeholder="Repeat new password"
            />
          </div>
        </div>
        <button
          onClick={handleChangePassword}
          disabled={passwordSaving}
          className="mt-4 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all flex items-center space-x-2 disabled:opacity-50"
        >
          <Save className="w-5 h-5" />
          <span>{passwordSaving ? 'Changing...' : 'Change Password'}</span>
        </button>
      </div>
    </div>
  );
}
