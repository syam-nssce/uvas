import { useState, useEffect } from 'react';
import { supabase, type OrderCircular } from '../../lib/supabase';
import { adminCrud } from '../../lib/adminCrud';
import { uploadAdminFile } from '../../lib/adminStorage';
import { Trash2, Download } from 'lucide-react';

interface OrdersCircularsAdminProps {
  adminCredentials?: { username: string; password: string };
}

export default function OrdersCircularsAdmin({ adminCredentials }: OrdersCircularsAdminProps) {
  const [items, setItems] = useState<OrderCircular[]>([]);
  const [formData, setFormData] = useState({
    type: 'order' as 'order' | 'circular',
    reference_number: '',
    title: '',
    content: '',
    category: '',
    issue_date: '',
    document_url: '',
  });
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    const { data } = await supabase
      .from('orders_circulars')
      .select('*')
      .order('issue_date', { ascending: false });
    if (data) setItems(data);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminCredentials) return;

    if (!formData.document_url && !uploadedFile) {
      alert('Please provide either a document URL or upload a file');
      return;
    }

    setUploading(true);
    let finalDocumentUrl = formData.document_url;

    try {
      if (uploadedFile) {
        finalDocumentUrl = await uploadAdminFile({
          bucket: 'documents',
          folder: 'orders-circulars',
          file: uploadedFile,
          credentials: adminCredentials,
        });
      }

      await adminCrud({
        table: 'orders_circulars',
        action: 'insert',
        data: {
          ...formData,
          document_url: finalDocumentUrl,
          tags: [],
          published: true,
        },
        credentials: adminCredentials,
      });

      resetForm();
      fetchItems();
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!adminCredentials) return;
    if (confirm('Delete this document?')) {
      try {
        await adminCrud({
          table: 'orders_circulars',
          action: 'delete',
          id,
          credentials: adminCredentials,
        });
        fetchItems();
      } catch (error) {
        console.error('Delete error:', error);
        alert('Failed to delete.');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      type: 'order',
      reference_number: '',
      title: '',
      content: '',
      category: '',
      issue_date: '',
      document_url: '',
    });
    setUploadedFile(null);
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center space-x-2">
        <span>📄</span>
        <span>Orders & Circulars</span>
      </h2>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="bg-slate-50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-slate-700 mb-4">Upload Order / Circular</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Reference Number *</label>
              <input
                type="text"
                value={formData.reference_number}
                onChange={(e) => setFormData({ ...formData, reference_number: e.target.value })}
                required
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="e.g. GO(P)/12/2025"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Subject / Title *</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="Full title of the order"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                >
                  <option value="">Select category</option>
                  <option value="Government Order">Government Order</option>
                  <option value="UGC Circular">UGC Circular</option>
                  <option value="ABRSM Circular">ABRSM Circular</option>
                  <option value="DPI Order">DPI Order</option>
                  <option value="Administrative">Administrative</option>
                  <option value="Academic">Academic</option>
                  <option value="Financial">Financial</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Date *</label>
                <input
                  type="date"
                  value={formData.issue_date}
                  onChange={(e) => setFormData({ ...formData, issue_date: e.target.value })}
                  required
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Content *</label>
              <textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                required
                rows={3}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
                placeholder="Brief description..."
              />
            </div>

            <div className="border-t border-slate-200 pt-4 mt-4">
              <p className="text-sm text-slate-600 mb-3 font-medium">Document Source (Choose one or both) *</p>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Upload File</label>
                <input
                  type="file"
                  accept=".pdf,.doc,.docx,.txt"
                  onChange={handleFileChange}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-amber-50 file:text-amber-700 hover:file:bg-amber-100"
                />
                {uploadedFile && (
                  <p className="text-xs text-green-600 mt-1">File selected: {uploadedFile.name}</p>
                )}
              </div>

              <div className="text-center my-3 text-slate-400 text-sm">OR</div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Document URL</label>
                <input
                  type="url"
                  value={formData.document_url}
                  onChange={(e) => setFormData({ ...formData, document_url: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  placeholder="https://example.com/document.pdf"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={uploading}
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {uploading ? 'Uploading...' : 'Upload & Publish'}
            </button>
          </form>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-slate-700 mb-4">Uploaded Documents</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-2 border-slate-200">
                  <th className="text-left py-3 px-2 text-xs font-semibold text-slate-600 uppercase">Ref No.</th>
                  <th className="text-left py-3 px-2 text-xs font-semibold text-slate-600 uppercase">Subject</th>
                  <th className="text-left py-3 px-2 text-xs font-semibold text-slate-600 uppercase">Category</th>
                  <th className="text-center py-3 px-2 text-xs font-semibold text-slate-600 uppercase">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {items.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50">
                    <td className="py-3 px-2 font-mono text-xs">{item.reference_number}</td>
                    <td className="py-3 px-2">
                      <div className="font-medium text-slate-800">{item.title}</div>
                      <div className="text-xs text-slate-500">{new Date(item.issue_date).toLocaleDateString()}</div>
                    </td>
                    <td className="py-3 px-2 text-slate-600">{item.category}</td>
                    <td className="py-3 px-2">
                      <div className="flex justify-center space-x-2">
                        {item.document_url && (
                          <a
                            href={item.document_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                          >
                            <Download className="w-4 h-4" />
                          </a>
                        )}
                        <button
                          onClick={() => handleDelete(item.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {items.length === 0 && (
              <div className="text-center py-8 text-slate-500">No documents yet</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
