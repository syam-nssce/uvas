import { useState, useEffect } from 'react';
import { supabase, type HelpdeskPost, type HelpdeskReply } from '../../lib/supabase';
import { adminCrud } from '../../lib/adminCrud';
import { MessageSquare, Trash2, Send, CheckCircle, Clock, Archive } from 'lucide-react';

interface HelpdeskAdminProps {
  adminCredentials?: { username: string; password: string };
}

export default function HelpdeskAdmin({ adminCredentials }: HelpdeskAdminProps) {
  const [posts, setPosts] = useState<HelpdeskPost[]>([]);
  const [pendingPosts, setPendingPosts] = useState<HelpdeskPost[]>([]);
  const [allApproved, setAllApproved] = useState<(HelpdeskPost & { replies?: HelpdeskReply[] })[]>([]);
  const [selectedPost, setSelectedPost] = useState<HelpdeskPost | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [activeTab, setActiveTab] = useState<'pending' | 'open' | 'all'>('pending');

  useEffect(() => {
    fetchAll();
  }, []);

  const fetchAll = async () => {
    const [{ data: pending }, { data: open }, { data: approved }] = await Promise.all([
      supabase.from('helpdesk_posts').select('*, members(full_name, college_name)').eq('status', 'pending').order('created_at', { ascending: false }),
      supabase.from('helpdesk_posts').select('*, members(full_name, college_name)').eq('status', 'open').order('created_at', { ascending: false }),
      supabase.from('helpdesk_posts').select('*, members(full_name, college_name)').neq('status', 'pending').order('created_at', { ascending: false }),
    ]);
    setPendingPosts(pending || []);
    setPosts(open || []);

    const approvedPosts = approved || [];
    if (approvedPosts.length > 0) {
      const postIds = approvedPosts.map(p => p.id);
      const { data: replies } = await supabase
        .from('helpdesk_replies')
        .select('*')
        .in('post_id', postIds)
        .order('created_at', { ascending: true });

      const repliesByPost: Record<string, HelpdeskReply[]> = {};
      (replies || []).forEach(r => {
        if (!repliesByPost[r.post_id]) repliesByPost[r.post_id] = [];
        repliesByPost[r.post_id].push(r);
      });

      setAllApproved(approvedPosts.map(p => ({ ...p, replies: repliesByPost[p.id] || [] })));
    } else {
      setAllApproved([]);
    }
  };

  const handleApprove = async (id: string) => {
    if (!adminCredentials) return;
    try {
      await adminCrud({
        table: 'helpdesk_posts',
        action: 'update',
        id,
        data: { status: 'open' },
        credentials: adminCredentials,
      });
      fetchAll();
    } catch (error) {
      console.error('Approve error:', error);
      alert('Failed to approve.');
    }
  };

  const handleReply = async () => {
    if (!selectedPost || !replyContent.trim() || !adminCredentials) return;

    try {
      await adminCrud({
        table: 'helpdesk_replies',
        action: 'insert',
        data: {
          post_id: selectedPost.id,
          member_id: selectedPost.member_id,
          content: replyContent,
          is_admin: true,
          approved: true,
        },
        credentials: adminCredentials,
      });

      await adminCrud({
        table: 'helpdesk_posts',
        action: 'update',
        id: selectedPost.id,
        data: { status: 'answered' },
        credentials: adminCredentials,
      });

      setReplyContent('');
      setSelectedPost(null);
      fetchAll();
      alert('Reply posted successfully!');
    } catch (error) {
      console.error('Reply error:', error);
      alert('Failed to post reply.');
    }
  };

  const handleDeleteReply = async (id: string) => {
    if (!adminCredentials) return;
    if (confirm('Delete this reply?')) {
      try {
        await adminCrud({
          table: 'helpdesk_replies',
          action: 'delete',
          id,
          credentials: adminCredentials,
        });
        fetchAll();
      } catch (error) {
        console.error('Delete error:', error);
        alert('Failed to delete reply.');
      }
    }
  };

  const handleDelete = async (id: string) => {
    if (!adminCredentials) return;
    if (confirm('Remove this query?')) {
      try {
        await adminCrud({
          table: 'helpdesk_posts',
          action: 'delete',
          id,
          credentials: adminCredentials,
        });
        fetchAll();
      } catch (error) {
        console.error('Delete error:', error);
        alert('Failed to delete.');
      }
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-blue-100 text-blue-800';
      case 'answered': return 'bg-green-100 text-green-800';
      case 'closed': return 'bg-slate-100 text-slate-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const currentList = activeTab === 'pending' ? pendingPosts : activeTab === 'open' ? posts : [];

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center space-x-2">
        <span>💬</span>
        <span>Help Desk</span>
      </h2>

      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setActiveTab('pending')}
          className={`px-5 py-2.5 rounded-lg font-medium text-sm flex items-center gap-2 transition-all ${
            activeTab === 'pending'
              ? 'bg-amber-100 text-amber-800 border-2 border-amber-300'
              : 'bg-slate-100 text-slate-600 border-2 border-transparent hover:bg-slate-200'
          }`}
        >
          <Clock className="w-4 h-4" />
          Pending Approval
          {pendingPosts.length > 0 && (
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
              {pendingPosts.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('open')}
          className={`px-5 py-2.5 rounded-lg font-medium text-sm flex items-center gap-2 transition-all ${
            activeTab === 'open'
              ? 'bg-blue-100 text-blue-800 border-2 border-blue-300'
              : 'bg-slate-100 text-slate-600 border-2 border-transparent hover:bg-slate-200'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          Open Queries
          {posts.length > 0 && (
            <span className="bg-blue-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
              {posts.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('all')}
          className={`px-5 py-2.5 rounded-lg font-medium text-sm flex items-center gap-2 transition-all ${
            activeTab === 'all'
              ? 'bg-green-100 text-green-800 border-2 border-green-300'
              : 'bg-slate-100 text-slate-600 border-2 border-transparent hover:bg-slate-200'
          }`}
        >
          <Archive className="w-4 h-4" />
          All Approved
          {allApproved.length > 0 && (
            <span className="bg-green-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
              {allApproved.length}
            </span>
          )}
        </button>
      </div>

      {activeTab === 'all' ? (
        <div className="space-y-4">
          {allApproved.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <MessageSquare className="w-16 h-16 mx-auto mb-3 opacity-50" />
              <p>No approved queries yet</p>
            </div>
          )}
          {allApproved.map((post) => (
            <div key={post.id} className="bg-white border border-slate-200 rounded-lg p-5 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <h4 className="font-semibold text-slate-800 text-lg">{post.title}</h4>
                  <div className="flex items-center space-x-2 text-xs text-slate-500 mt-1">
                    <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded">{post.topic}</span>
                    <span>{new Date(post.created_at).toLocaleDateString()}</span>
                    <span className={`px-2 py-0.5 rounded-full ${getStatusColor(post.status)}`}>{post.status}</span>
                  </div>
                  {(post as any).members && (
                    <div className="text-xs text-slate-500 mt-1">
                      <span className="font-medium text-slate-700">{(post as any).members.full_name}</span>
                      {(post as any).members.college_name && <span>, {(post as any).members.college_name}</span>}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => handleDelete(post.id)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <p className="text-sm text-slate-600 mt-2">{post.content}</p>

              {post.replies && post.replies.length > 0 && (
                <div className="mt-4 border-t border-slate-100 pt-3 space-y-2">
                  <h5 className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Responses ({post.replies.length})</h5>
                  {post.replies.map((reply) => (
                    <div key={reply.id} className={`p-3 rounded-lg text-sm flex items-start justify-between ${reply.is_admin ? 'bg-amber-50 border border-amber-200' : 'bg-slate-50'}`}>
                      <div className="flex-1">
                        {reply.is_admin && (
                          <span className="text-xs font-semibold text-amber-600 mb-1 block">OFFICIAL REPLY</span>
                        )}
                        <p className="text-slate-700">{reply.content}</p>
                        <p className="text-xs text-slate-400 mt-1">{new Date(reply.created_at).toLocaleString()}</p>
                      </div>
                      <button
                        onClick={() => handleDeleteReply(reply.id)}
                        className="p-1 text-red-600 hover:bg-red-50 rounded ml-2"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {(!post.replies || post.replies.length === 0) && (
                <div className="mt-3 text-xs text-slate-400 italic">No responses yet</div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <div className="space-y-3">
              {currentList.map((post) => (
                <div key={post.id} className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="font-semibold text-slate-800 mb-1">{post.title}</h4>
                      <div className="flex items-center space-x-2 text-xs text-slate-500">
                        <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded">{post.topic}</span>
                        <span>{new Date(post.created_at).toLocaleDateString()}</span>
                      </div>
                      {(post as any).members && (
                        <div className="text-xs text-slate-500 mt-1">
                          <span className="font-medium text-slate-700">{(post as any).members.full_name}</span>
                          {(post as any).members.college_name && <span>, {(post as any).members.college_name}</span>}
                        </div>
                      )}
                      <p className="text-sm text-slate-600 mt-2 line-clamp-2">{post.content}</p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    {activeTab === 'pending' && (
                      <button
                        onClick={() => handleApprove(post.id)}
                        className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm font-medium flex items-center justify-center gap-1"
                      >
                        <CheckCircle className="w-4 h-4" />
                        Approve
                      </button>
                    )}
                    {activeTab === 'open' && (
                      <button
                        onClick={() => setSelectedPost(post)}
                        className="flex-1 bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors text-sm font-medium"
                      >
                        Reply as Official
                      </button>
                    )}
                    <button
                      onClick={() => handleDelete(post.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}

              {currentList.length === 0 && (
                <div className="text-center py-12 text-slate-500">
                  <MessageSquare className="w-16 h-16 mx-auto mb-3 opacity-50" />
                  <p>{activeTab === 'pending' ? 'No pending queries' : 'No open queries'}</p>
                </div>
              )}
            </div>
          </div>

          <div className="bg-slate-50 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-slate-700 mb-4">Post Official Reply</h3>

            {selectedPost ? (
              <div className="space-y-4">
                <div className="bg-white rounded-lg p-4 border border-slate-200">
                  <div className="text-sm font-medium text-slate-700 mb-2">Replying to:</div>
                  <div className="font-semibold text-slate-800">{selectedPost.title}</div>
                  <div className="text-sm text-slate-600 mt-1">{selectedPost.content}</div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Official Response *</label>
                  <textarea
                    value={replyContent}
                    onChange={(e) => setReplyContent(e.target.value)}
                    rows={8}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
                    placeholder="Type the official UVAS response here..."
                  />
                </div>

                <div className="flex space-x-3">
                  <button
                    onClick={handleReply}
                    className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all flex items-center justify-center space-x-2"
                  >
                    <Send className="w-5 h-5" />
                    <span>Post as UVAS Official</span>
                  </button>
                  <button
                    onClick={() => { setSelectedPost(null); setReplyContent(''); }}
                    className="px-6 py-3 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-slate-500">
                <MessageSquare className="w-16 h-16 mx-auto mb-3 opacity-50" />
                <p>{activeTab === 'pending' ? 'Select a query to approve or delete' : 'Select a query to reply'}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
