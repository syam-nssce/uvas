import { useState, useEffect } from 'react';
import { supabase, type CommitteeMember } from '../../lib/supabase';
import { adminCrud } from '../../lib/adminCrud';
import { uploadAdminFile } from '../../lib/adminStorage';
import { CreditCard as Edit2, Trash2, Upload, X as XIcon } from 'lucide-react';

interface CommitteeAdminProps {
  adminCredentials?: { username: string; password: string };
}

export default function CommitteeAdmin({ adminCredentials }: CommitteeAdminProps) {
  const [members, setMembers] = useState<CommitteeMember[]>([]);
  const [filterType, setFilterType] = useState('all');
  const [formData, setFormData] = useState({
    full_name: '',
    designation: '',
    committee_type: 'State Committee',
    district: '',
    mobile: '',
    email: '',
    photo_url: '',
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');

  useEffect(() => {
    fetchMembers();
  }, []);

  const fetchMembers = async () => {
    const { data } = await supabase
      .from('committee_members')
      .select('*')
      .order('display_order', { ascending: true });
    if (data) setMembers(data);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const uploadPhoto = async (): Promise<string | null> => {
    if (!selectedFile || !adminCredentials) return null;

    setUploading(true);
    try {
      return await uploadAdminFile({
        bucket: 'committee-photos',
        folder: 'committee',
        file: selectedFile,
        credentials: adminCredentials,
      });
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload photo');
      return null;
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminCredentials) return;

    let photoUrl = formData.photo_url;
    if (selectedFile) {
      const uploadedUrl = await uploadPhoto();
      if (!uploadedUrl && !photoUrl) {
        return;
      }
      if (uploadedUrl) {
        photoUrl = uploadedUrl;
      }
    }

    const dataToSubmit = {
      ...formData,
      district: formData.district || null,
      mobile: formData.mobile || null,
      email: formData.email || null,
      photo_url: photoUrl || null,
    };

    try {
      if (editingId) {
        await adminCrud({
          table: 'committee_members',
          action: 'update',
          id: editingId,
          data: dataToSubmit,
          credentials: adminCredentials,
        });
      } else {
        await adminCrud({
          table: 'committee_members',
          action: 'insert',
          data: dataToSubmit,
          credentials: adminCredentials,
        });
      }

      resetForm();
      fetchMembers();
    } catch (error) {
      console.error('Save error:', error);
      alert('Failed to save. Please try again.');
    }
  };

  const handleDelete = async (id: string) => {
    if (!adminCredentials) return;
    if (confirm('Delete this member?')) {
      try {
        await adminCrud({
          table: 'committee_members',
          action: 'delete',
          id,
          credentials: adminCredentials,
        });
        fetchMembers();
      } catch (error) {
        console.error('Delete error:', error);
        alert('Failed to delete.');
      }
    }
  };

  const startEdit = (member: CommitteeMember) => {
    setEditingId(member.id);
    setFormData({
      full_name: member.full_name,
      designation: member.designation,
      committee_type: member.committee_type,
      district: member.district || '',
      mobile: member.mobile || '',
      email: member.email || '',
      photo_url: member.photo_url || '',
    });
    setPreviewUrl(member.photo_url || '');
    setSelectedFile(null);
  };

  const resetForm = () => {
    setFormData({
      full_name: '',
      designation: '',
      committee_type: 'State Committee',
      district: '',
      mobile: '',
      email: '',
      photo_url: '',
    });
    setEditingId(null);
    setSelectedFile(null);
    setPreviewUrl('');
  };

  const filteredMembers = filterType === 'all'
    ? members
    : members.filter(m => m.committee_type === filterType);

  const districts = [
    'Thiruvananthapuram', 'Kollam', 'Pathanamthitta', 'Alappuzha', 'Kottayam',
    'Idukki', 'Ernakulam', 'Thrissur', 'Palakkad', 'Malappuram',
    'Kozhikode', 'Wayanad', 'Kannur', 'Kasaragod'
  ];

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center space-x-2">
        <span>👥</span>
        <span>Committee Members</span>
      </h2>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="bg-slate-50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-slate-700 mb-4">Add Committee Member</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Full Name *</label>
              <input
                type="text"
                value={formData.full_name}
                onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                required
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="Member full name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Designation *</label>
              <input
                type="text"
                value={formData.designation}
                onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                required
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="e.g. President, Secretary, Convenor"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Committee *</label>
                <select
                  value={formData.committee_type}
                  onChange={(e) => setFormData({ ...formData, committee_type: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                >
                  <option value="State Committee">State Committee</option>
                  <option value="Zonal Committee">Zonal Committee</option>
                  <option value="Kerala University">Kerala University</option>
                  <option value="MG University">MG University</option>
                  <option value="Calicut University">Calicut University</option>
                  <option value="Kannur University">Kannur University</option>
                  <option value="Service Cell">Service Cell</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">District</label>
                <select
                  value={formData.district}
                  onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                >
                  <option value="">-- Select --</option>
                  {districts.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Mobile</label>
                <input
                  type="tel"
                  value={formData.mobile}
                  onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  placeholder="+91 XXXXX XXXXX"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  placeholder="email@example.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Photo</label>

              {(previewUrl || formData.photo_url) && (
                <div className="mb-3 relative inline-block">
                  <img
                    src={previewUrl || formData.photo_url}
                    alt="Preview"
                    className="w-32 h-32 rounded-lg object-cover border-2 border-amber-200"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setPreviewUrl('');
                      setSelectedFile(null);
                      setFormData({ ...formData, photo_url: '' });
                    }}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                  >
                    <XIcon className="w-4 h-4" />
                  </button>
                </div>
              )}

              <div className="flex gap-3">
                <label className="flex-1 cursor-pointer">
                  <div className="flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 rounded-lg hover:border-amber-500 hover:bg-amber-50 transition-all">
                    <Upload className="w-5 h-5 text-slate-600" />
                    <span className="text-sm font-medium text-slate-700">
                      {selectedFile ? selectedFile.name : 'Upload Photo'}
                    </span>
                  </div>
                  <input
                    type="file"
                    accept="image/jpeg,image/jpg,image/png,image/webp"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </label>
              </div>

              <p className="text-xs text-slate-500 mt-2">Or enter a photo URL below (optional)</p>
              <input
                type="url"
                value={formData.photo_url}
                onChange={(e) => {
                  setFormData({ ...formData, photo_url: e.target.value });
                  setPreviewUrl(e.target.value);
                  setSelectedFile(null);
                }}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent mt-2"
                placeholder="https://example.com/photo.jpg"
              />
            </div>

            <div className="flex space-x-3">
              <button
                type="submit"
                disabled={uploading}
                className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {uploading ? 'Uploading...' : editingId ? 'Update' : 'Add Member'}
              </button>
              {editingId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-6 py-3 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 transition-all"
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-slate-700 mb-4">Members List</h3>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent mb-4"
          >
            <option value="all">All Committees</option>
            <option value="State Committee">State Committee</option>
            <option value="Zonal Committee">Zonal Committee</option>
            <option value="Kerala University">Kerala University</option>
            <option value="MG University">MG University</option>
            <option value="Calicut University">Calicut University</option>
            <option value="Kannur University">Kannur University</option>
            <option value="Service Cell">Service Cell</option>
          </select>

          <div className="space-y-3">
            {filteredMembers.map((member) => (
              <div key={member.id} className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex gap-4">
                  {member.photo_url && (
                    <img
                      src={member.photo_url}
                      alt={member.full_name}
                      className="w-16 h-16 rounded-lg object-cover border-2 border-amber-200 flex-shrink-0"
                    />
                  )}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-slate-800">{member.full_name}</h4>
                    <p className="text-sm text-slate-600">{member.designation}</p>
                    <div className="flex items-center flex-wrap gap-2 mt-2">
                      <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded">{member.committee_type}</span>
                      {member.district && (
                        <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded">{member.district}</span>
                      )}
                    </div>
                  </div>
                  <div className="flex space-x-2 flex-shrink-0">
                    <button
                      onClick={() => startEdit(member)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors h-fit"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(member.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors h-fit"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {filteredMembers.length === 0 && (
              <div className="text-center py-8 text-slate-500">No members found</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
