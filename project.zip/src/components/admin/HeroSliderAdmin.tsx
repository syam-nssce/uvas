import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Upload, Trash2, Loader2 } from 'lucide-react';

interface SlideFile {
  name: string;
  url: string;
}

export default function HeroSliderAdmin() {
  const [slides, setSlides] = useState<SlideFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);

  useEffect(() => {
    fetchSlides();
  }, []);

  const fetchSlides = async () => {
    const { data, error } = await supabase.storage.from('hero-slides').list('', {
      sortBy: { column: 'name', order: 'asc' },
    });
    if (error || !data) return;

    const items = data
      .filter((f) => f.name !== '.emptyFolderPlaceholder')
      .map((file) => {
        const { data: urlData } = supabase.storage.from('hero-slides').getPublicUrl(file.name);
        return { name: file.name, url: urlData.publicUrl };
      });
    setSlides(items);
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    for (const file of Array.from(files)) {
      const fileName = `slide_${Date.now()}_${file.name.replace(/\s+/g, '_')}`;
      await supabase.storage.from('hero-slides').upload(fileName, file, {
        cacheControl: '3600',
        upsert: false,
      });
    }
    await fetchSlides();
    setUploading(false);
    e.target.value = '';
  };

  const handleDelete = async (name: string) => {
    if (!confirm('Delete this slide?')) return;
    setDeleting(name);
    await supabase.storage.from('hero-slides').remove([name]);
    await fetchSlides();
    setDeleting(null);
  };

  return (
    <div className="bg-slate-50 rounded-xl p-6">
      <h3 className="text-lg font-semibold text-slate-700 mb-4">Hero Slider Images</h3>
      <p className="text-sm text-slate-600 mb-4">Recommended size: 1920×900px. Images auto-rotate every 5 seconds.</p>

      {slides.length > 0 && (
        <div className="grid md:grid-cols-3 gap-4 mb-4">
          {slides.map((slide) => (
            <div key={slide.name} className="relative group rounded-lg overflow-hidden border border-slate-200">
              <img src={slide.url} alt={slide.name} className="w-full h-32 object-cover" />
              <button
                onClick={() => handleDelete(slide.name)}
                disabled={deleting === slide.name}
                className="absolute top-2 right-2 bg-red-600 hover:bg-red-700 text-white p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
              >
                {deleting === slide.name ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4" />
                )}
              </button>
              <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs px-2 py-1 truncate">
                {slide.name}
              </div>
            </div>
          ))}
        </div>
      )}

      {slides.length === 0 && (
        <div className="text-center py-8 text-slate-500 bg-white rounded-lg border-2 border-dashed border-slate-300 mb-4">
          No slides uploaded yet. Upload images below.
        </div>
      )}

      <label className="flex items-center justify-center gap-2 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all cursor-pointer">
        {uploading ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Uploading...</span>
          </>
        ) : (
          <>
            <Upload className="w-5 h-5" />
            <span>Upload Slide Images</span>
          </>
        )}
        <input
          type="file"
          accept="image/*"
          multiple
          onChange={handleUpload}
          disabled={uploading}
          className="hidden"
        />
      </label>
    </div>
  );
}
