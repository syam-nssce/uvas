import { useState, useEffect, useMemo } from 'react';
import { supabase } from '../../integrations/supabase/client';
import { Search, Filter, X, Download, Eye, CheckCircle, ArrowLeft, Trash2, Upload, FileSpreadsheet } from 'lucide-react';
import * as XLSX from 'xlsx';

interface MembersAdminProps {
  adminCredentials?: { username: string; password: string };
}

export default function MembersAdmin({ adminCredentials }: MembersAdminProps) {
  const [members, setMembers] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [districtFilter, setDistrictFilter] = useState('all');
  const [designationFilter, setDesignationFilter] = useState('all');
  const [experienceFilter, setExperienceFilter] = useState('all');
  const [specializationFilter, setSpecializationFilter] = useState('all');
  const [selectedMember, setSelectedMember] = useState<any | null>(null);
  const [approving, setApproving] = useState(false);
  const [removing, setRemoving] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [defaultPassword, setDefaultPassword] = useState('uvas@2026');
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ created: any[]; skipped: any[] } | null>(null);

  useEffect(() => {
    fetchMembers();
  }, [statusFilter, districtFilter]);

  const fetchMembers = async () => {
    if (!adminCredentials) return;
    
    const { data, error } = await supabase.functions.invoke('admin-members', {
      body: {
        action: 'list',
        username: adminCredentials.username,
        password: adminCredentials.password,
        status_filter: statusFilter,
      },
    });

    if (!error && data?.members) setMembers(data.members);
  };

  const handleApprove = async (memberId: string) => {
    if (!adminCredentials) return;
    setApproving(true);
    try {
      const { data, error } = await supabase.functions.invoke('admin-members', {
        body: {
          action: 'approve',
          username: adminCredentials.username,
          password: adminCredentials.password,
          member_id: memberId,
        },
      });

      if (error || !data?.success) {
        alert('Failed to approve: ' + (data?.error || 'Unknown error'));
      } else {
        setSelectedMember((prev: any) => prev ? { ...prev, status: 'active', payment_status: 'paid' } : null);
        await fetchMembers();
      }
    } catch (err) {
      alert('An error occurred while approving.');
    } finally {
      setApproving(false);
    }
  };

  const handleRemoveMember = async (memberId: string, memberName: string) => {
    const confirmed = window.confirm(`Are you sure you want to permanently remove "${memberName}" from the UVAS directory? This action cannot be undone.`);
    if (!confirmed) return;
    if (!adminCredentials) return;

    setRemoving(true);
    try {
      const { data, error } = await supabase.functions.invoke('admin-members', {
        body: {
          action: 'delete',
          username: adminCredentials.username,
          password: adminCredentials.password,
          member_id: memberId,
        },
      });

      if (error || !data?.success) {
        alert('Failed to remove member: ' + (data?.error || 'Unknown error'));
      } else {
        setSelectedMember(null);
        await fetchMembers();
      }
    } catch (err) {
      alert('An error occurred while removing the member.');
    } finally {
      setRemoving(false);
    }
  };

  const designations = useMemo(() => {
    const set = new Set(members.map(m => m.designation).filter(Boolean));
    return Array.from(set).sort();
  }, [members]);

  const specializations = useMemo(() => {
    const set = new Set(members.map(m => (m as any).area_of_specialization).filter(Boolean));
    return Array.from(set).sort();
  }, [members]);

  const activeFiltersCount = [designationFilter, experienceFilter, specializationFilter]
    .filter(f => f !== 'all').length;

  const exportToExcel = () => {
    const exportData = filteredMembers.map((member) => {
      const m = member as any;
      return {
        'Full Name': member.full_name,
        'Email': member.email,
        'Phone': member.phone || '',
        'District': m.district || '',
        'Institution': member.institution || '',
        'Designation': member.designation || '',
        'Experience (Years)': m.experience_years ?? '',
        'Specialization': m.area_of_specialization || '',
        'Membership Type': member.membership_type,
        'Status': member.status,
        'Joined Date': member.joined_date ? new Date(member.joined_date).toLocaleDateString() : '',
      };
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Members');

    const colWidths = Object.keys(exportData[0] || {}).map(key => ({
      wch: Math.max(key.length, ...exportData.map(row => String((row as any)[key] || '').length)) + 2
    }));
    ws['!cols'] = colWidths;

    XLSX.writeFile(wb, `UVAS_Members_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const downloadImportTemplate = () => {
    const ws = XLSX.utils.json_to_sheet([
      { 'Full Name': 'John Doe', 'Date of Birth': '12-01-1992', 'Mobile Number': '9876543210', 'Email': 'john.doe@example.com' },
    ]);
    ws['!cols'] = [{ wch: 25 }, { wch: 18 }, { wch: 18 }, { wch: 30 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Members');
    XLSX.writeFile(wb, 'UVAS_Member_Import_Template.xlsx');
  };

  const normalizeDob = (val: any): string | null => {
    if (val == null || val === '') return null;
    if (val instanceof Date) return val.toISOString().slice(0, 10);
    if (typeof val === 'number') {
      // Excel serial date
      const d = XLSX.SSF.parse_date_code(val);
      if (d) return `${d.y}-${String(d.m).padStart(2, '0')}-${String(d.d).padStart(2, '0')}`;
    }
    const s = String(val).trim();
    // Accept dd-mm-yyyy, dd/mm/yyyy, dd.mm.yyyy (day-month-year format)
    const dmy = s.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
    if (dmy) {
      const [, dd, mm, yyyy] = dmy;
      const day = parseInt(dd, 10);
      const month = parseInt(mm, 10);
      if (day >= 1 && day <= 31 && month >= 1 && month <= 12) {
        return `${yyyy}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      }
    }
    // Accept yyyy-mm-dd directly
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
    // Fallback: try native parser
    const parsed = new Date(s);
    if (!isNaN(parsed.getTime())) return parsed.toISOString().slice(0, 10);
    return null;
  };

  const handleImportMembers = async () => {
    if (!adminCredentials || !importFile) return;
    if (defaultPassword.length < 8) {
      alert('Default password must be at least 8 characters.');
      return;
    }
    setImporting(true);
    setImportResult(null);
    try {
      const buf = await importFile.arrayBuffer();
      const wb = XLSX.read(buf, { type: 'array' });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<any>(sheet, { defval: '' });

      const members_list = rows.map((r) => {
        const fullName = r['Full Name'] ?? r['full_name'] ?? r['Name'] ?? r['name'] ?? '';
        const mobile = r['Mobile Number'] ?? r['Mobile'] ?? r['mobile'] ?? r['Phone'] ?? '';
        const dob = r['Date of Birth'] ?? r['DOB'] ?? r['date_of_birth'] ?? '';
        const email = r['Email'] ?? r['email'] ?? r['Email Address'] ?? r['Email ID'] ?? '';
        return {
          full_name: String(fullName).trim(),
          mobile: String(mobile).trim(),
          date_of_birth: normalizeDob(dob),
          email: String(email).trim().toLowerCase(),
        };
      }).filter((r) => r.full_name && r.mobile && r.email);

      if (members_list.length === 0) {
        alert('No valid rows found. Required columns: Full Name, Mobile Number, Email (Date of Birth optional).');
        setImporting(false);
        return;
      }

      const { data, error } = await supabase.functions.invoke('admin-members', {
        body: {
          action: 'bulk_import',
          username: adminCredentials.username,
          password: adminCredentials.password,
          members_list,
          default_password: defaultPassword,
        },
      });

      if (error || !data?.success) {
        alert('Import failed: ' + (data?.error || error?.message || 'Unknown error'));
      } else {
        setImportResult({ created: data.created || [], skipped: data.skipped || [] });
        if ((data.created || []).length > 0) {
          // Build sheet manually to ensure mobile is a plain text cell with NO prefixes/formatting
          const header = ['Full Name', 'Username (Mobile)', 'Default Password'];
          const aoa: any[][] = [header];
          for (const c of data.created) {
            const cleanMobile = String(c.mobile ?? '').replace(/[^0-9]/g, '');
            aoa.push([String(c.full_name ?? ''), cleanMobile, String(c.password ?? '')]);
          }
          const ws = XLSX.utils.aoa_to_sheet(aoa);
          // Force every mobile cell to be plain text type (no leading quote, no number formatting)
          for (let i = 0; i < data.created.length; i++) {
            const cellRef = XLSX.utils.encode_cell({ r: i + 1, c: 1 });
            const cleanMobile = String(data.created[i].mobile ?? '').replace(/[^0-9]/g, '');
            ws[cellRef] = { t: 's', v: cleanMobile, w: cleanMobile };
          }
          ws['!cols'] = [{ wch: 28 }, { wch: 20 }, { wch: 20 }];
          const wbOut = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wbOut, ws, 'Credentials');
          XLSX.writeFile(wbOut, `UVAS_Member_Credentials_${new Date().toISOString().slice(0, 10)}.xlsx`);
        }
        await fetchMembers();
      }
    } catch (err: any) {
      alert('Failed to read file: ' + (err?.message || 'Unknown error'));
    } finally {
      setImporting(false);
    }
  };

  const clearAllFilters = () => {
    setStatusFilter('all');
    setDistrictFilter('all');
    setDesignationFilter('all');
    setExperienceFilter('all');
    setSpecializationFilter('all');
    setSearchTerm('');
  };

  const filteredMembers = members.filter(member => {
    const m = member as any;

    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      const match =
        member.full_name.toLowerCase().includes(search) ||
        member.email?.toLowerCase().includes(search) ||
        member.phone?.toLowerCase().includes(search) ||
        member.institution?.toLowerCase().includes(search) ||
        m.employee_id?.toLowerCase().includes(search);
      if (!match) return false;
    }

    if (designationFilter !== 'all' && member.designation !== designationFilter) return false;

    if (experienceFilter !== 'all') {
      const exp = m.experience_years;
      if (experienceFilter === '0-5' && (exp == null || exp > 5)) return false;
      if (experienceFilter === '6-10' && (exp == null || exp < 6 || exp > 10)) return false;
      if (experienceFilter === '11-20' && (exp == null || exp < 11 || exp > 20)) return false;
      if (experienceFilter === '20+' && (exp == null || exp <= 20)) return false;
    }

    if (specializationFilter !== 'all' && m.area_of_specialization !== specializationFilter) return false;

    return true;
  });

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      active: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      expired: 'bg-red-100 text-red-800',
      retired: 'bg-slate-100 text-slate-800',
    };
    return `text-xs font-semibold px-2 py-1 rounded ${styles[status] || 'bg-slate-100 text-slate-800'}`;
  };

  // ---- Member Detail View ----
  if (selectedMember) {
    const m = selectedMember;
    return (
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <button
          onClick={() => setSelectedMember(null)}
          className="flex items-center gap-2 text-amber-600 hover:text-amber-700 font-medium mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Members List
        </button>

        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-800">Member Application Details</h2>
          <span className={getStatusBadge(m.status)}>{m.status.toUpperCase()}</span>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <DetailCard label="Full Name" value={m.full_name} />
          <DetailCard label="Email" value={m.email} />
          <DetailCard label="Mobile" value={m.mobile} />
          <DetailCard label="Date of Birth" value={m.date_of_birth ? new Date(m.date_of_birth).toLocaleDateString() : '—'} />
          <DetailCard label="Religion" value={m.religion} />
          <DetailCard label="House Address" value={m.house_address} />
          <DetailCard label="District" value={m.district} />
          <DetailCard label="Employee ID" value={m.employee_id} />
          <DetailCard label="Designation" value={m.designation} />
          <DetailCard label="College Name" value={m.college_name} />
          <DetailCard label="College Type" value={m.college_type} />
          <DetailCard label="College Address" value={m.college_address} />
          <DetailCard label="University" value={m.university} />
          <DetailCard label="Area of Specialization" value={m.area_of_specialization} />
          <DetailCard label="Experience (Years)" value={m.experience_years} />
          <DetailCard label="Membership Category" value={m.membership_category?.replace('-', ' / ')} />
          <DetailCard label="Membership Type" value={m.membership_type} />
          <DetailCard label="Payment Status" value={m.payment_status} />
          <DetailCard label="UTR Reference" value={m.utr_reference} />
          <DetailCard label="Joined Date" value={m.joined_date ? new Date(m.joined_date).toLocaleDateString() : '—'} />
          <DetailCard label="Renewal Date" value={m.renewal_date ? new Date(m.renewal_date).toLocaleDateString() : '—'} />
          <DetailCard label="Retirement Date" value={m.retirement_date ? new Date(m.retirement_date).toLocaleDateString() : '—'} />
        </div>

        {m.status === 'pending' && (
          <div className="mt-8 pt-6 border-t border-slate-200">
            <button
              onClick={() => handleApprove(m.id)}
              disabled={approving}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]"
            >
              <CheckCircle className="w-5 h-5" />
              {approving ? 'Approving...' : 'Approve & Activate Membership'}
            </button>
          </div>
        )}

        {m.status === 'active' && (
          <div className="mt-8 pt-6 border-t border-slate-200">
            <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-lg px-4 py-3">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <p className="text-green-800 font-semibold">This member is approved and active.</p>
            </div>
          </div>
        )}

        {/* Remove Member */}
        <div className="mt-6 pt-6 border-t border-slate-200">
          <button
            onClick={() => handleRemoveMember(m.id, m.full_name)}
            disabled={removing}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-red-600 to-red-700 text-white font-bold rounded-lg hover:from-red-700 hover:to-red-800 transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]"
          >
            <Trash2 className="w-5 h-5" />
            {removing ? 'Removing...' : 'Remove Member from UVAS'}
          </button>
          <p className="text-xs text-slate-500 mt-2">This will permanently delete the member from the directory.</p>
        </div>
      </div>
    );
  }

  // ---- Members List View ----
  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-800 flex items-center space-x-2">
          <span>🪪</span>
          <span>Members</span>
        </h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => { setShowImport(true); setImportResult(null); setImportFile(null); }}
            className="flex items-center space-x-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors text-sm font-medium"
          >
            <Upload className="w-4 h-4" />
            <span>Import from Excel</span>
          </button>
          <button
            onClick={exportToExcel}
            disabled={filteredMembers.length === 0}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium"
          >
            <Download className="w-4 h-4" />
            <span>Export to Excel ({filteredMembers.length})</span>
          </button>
        </div>
      </div>

      {showImport && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-amber-600" />
                Bulk Import Members
              </h3>
              <button onClick={() => setShowImport(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-sm text-slate-600 mb-3">
              Upload an Excel file with columns: <strong>Full Name</strong>, <strong>Email</strong>, <strong>Mobile Number</strong>, <strong>Date of Birth</strong> (format <code className="bg-slate-100 px-1 rounded">dd-mm-yyyy</code>, e.g. 12-01-1992).
              Email and Mobile Number are <strong>mandatory and must be unique</strong>. Members are created as <strong>Regular</strong> with status <em>active</em> and payment <em>paid</em>. They can log in with either mobile number or email; the default password below applies to all. They will set their <strong>Joining Date</strong> on first login — renewal eligibility is based on it.
            </p>

            <button onClick={downloadImportTemplate} className="text-xs text-amber-600 hover:text-amber-700 font-medium underline mb-4">
              Download Excel template
            </button>

            <label className="block text-sm font-semibold text-slate-700 mb-1">Excel File (.xlsx)</label>
            <input
              type="file"
              accept=".xlsx,.xls"
              onChange={(e) => setImportFile(e.target.files?.[0] || null)}
              className="w-full mb-4 text-sm border border-slate-300 rounded-lg p-2"
            />

            <label className="block text-sm font-semibold text-slate-700 mb-1">Default Password (min 8 chars)</label>
            <input
              type="text"
              value={defaultPassword}
              onChange={(e) => setDefaultPassword(e.target.value)}
              className="w-full mb-4 px-3 py-2 border border-slate-300 rounded-lg text-sm"
            />

            {importResult && (
              <div className="mb-4 p-3 bg-slate-50 border border-slate-200 rounded-lg text-sm">
                <p className="font-semibold text-green-700">Created: {importResult.created.length}</p>
                <p className="font-semibold text-red-700">Skipped: {importResult.skipped.length}</p>
                {importResult.skipped.length > 0 && (
                  <ul className="mt-2 text-xs text-slate-600 list-disc list-inside max-h-32 overflow-y-auto">
                    {importResult.skipped.map((s, i) => (
                      <li key={i}>{s.full_name || '—'} ({s.mobile || '—'}): {s.reason}</li>
                    ))}
                  </ul>
                )}
                {importResult.created.length > 0 && (
                  <p className="mt-2 text-xs text-slate-600">A credentials file has been downloaded automatically.</p>
                )}
              </div>
            )}

            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setShowImport(false)}
                className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800"
              >
                Close
              </button>
              <button
                onClick={handleImportMembers}
                disabled={!importFile || importing}
                className="px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium"
              >
                {importing ? 'Importing...' : 'Import & Generate Credentials'}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
        <input
          type="text"
          placeholder="Search by name, mobile, employee ID, college..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
        />
      </div>

      <div className="flex flex-wrap gap-3 mb-4 items-center">
        <Filter className="text-slate-500 w-4 h-4" />
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-1.5 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent">
          <option value="all">All Status</option>
          <option value="active">Active</option>
          <option value="pending">Pending</option>
          <option value="expired">Expired</option>
          <option value="retired">Retired</option>
        </select>

        <select value={districtFilter} onChange={(e) => setDistrictFilter(e.target.value)}
          className="px-3 py-1.5 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent">
          <option value="all">All Districts</option>
          <option value="Thiruvananthapuram">Thiruvananthapuram</option>
          <option value="Kollam">Kollam</option>
          <option value="Pathanamthitta">Pathanamthitta</option>
          <option value="Alappuzha">Alappuzha</option>
          <option value="Kottayam">Kottayam</option>
          <option value="Idukki">Idukki</option>
          <option value="Ernakulam">Ernakulam</option>
          <option value="Thrissur">Thrissur</option>
          <option value="Palakkad">Palakkad</option>
          <option value="Malappuram">Malappuram</option>
          <option value="Kozhikode">Kozhikode</option>
          <option value="Wayanad">Wayanad</option>
          <option value="Kannur">Kannur</option>
          <option value="Kasaragod">Kasaragod</option>
        </select>

        <select value={designationFilter} onChange={(e) => setDesignationFilter(e.target.value)}
          className="px-3 py-1.5 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent">
          <option value="all">All Designations</option>
          {designations.map(d => <option key={d} value={d!}>{d}</option>)}
        </select>

        <select value={experienceFilter} onChange={(e) => setExperienceFilter(e.target.value)}
          className="px-3 py-1.5 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent">
          <option value="all">All Experience</option>
          <option value="0-5">0–5 years</option>
          <option value="6-10">6–10 years</option>
          <option value="11-20">11–20 years</option>
          <option value="20+">20+ years</option>
        </select>

        <select value={specializationFilter} onChange={(e) => setSpecializationFilter(e.target.value)}
          className="px-3 py-1.5 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent">
          <option value="all">All Specializations</option>
          {specializations.map(s => <option key={s as string} value={s as string}>{s as string}</option>)}
        </select>

        {activeFiltersCount > 0 && (
          <button onClick={clearAllFilters}
            className="flex items-center space-x-1 text-xs text-red-600 hover:text-red-700 font-medium px-2 py-1 bg-red-50 rounded-lg">
            <X className="w-3 h-3" />
            <span>Clear filters ({activeFiltersCount})</span>
          </button>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b-2 border-slate-200">
              <th className="text-left py-3 px-3 text-xs font-semibold text-slate-600 uppercase">Name</th>
              <th className="text-left py-3 px-3 text-xs font-semibold text-slate-600 uppercase">Email</th>
              <th className="text-left py-3 px-3 text-xs font-semibold text-slate-600 uppercase">Institution</th>
              <th className="text-left py-3 px-3 text-xs font-semibold text-slate-600 uppercase">Designation</th>
              <th className="text-left py-3 px-3 text-xs font-semibold text-slate-600 uppercase">Exp (yrs)</th>
              <th className="text-left py-3 px-3 text-xs font-semibold text-slate-600 uppercase">Specialization</th>
              <th className="text-left py-3 px-3 text-xs font-semibold text-slate-600 uppercase">Status</th>
              <th className="text-center py-3 px-3 text-xs font-semibold text-slate-600 uppercase">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {filteredMembers.map((member) => {
              const m = member as any;
              return (
                <tr key={member.id} className="hover:bg-slate-50">
                  <td className="py-3 px-3">
                    <div className="font-semibold text-slate-800">{member.full_name}</div>
                    {member.phone && <div className="text-xs text-slate-500">{member.phone}</div>}
                  </td>
                  <td className="py-3 px-3 text-slate-600">{member.email}</td>
                  <td className="py-3 px-3 text-slate-600">{member.institution || '—'}</td>
                  <td className="py-3 px-3 text-slate-600">{member.designation || '—'}</td>
                  <td className="py-3 px-3 text-slate-600">{m.experience_years ?? '—'}</td>
                  <td className="py-3 px-3 text-slate-600">{m.area_of_specialization || '—'}</td>
                  <td className="py-3 px-3">
                    <span className={getStatusBadge(member.status)}>{member.status.toUpperCase()}</span>
                  </td>
                  <td className="py-3 px-3 text-center">
                    <button
                      onClick={() => setSelectedMember(m)}
                      className="inline-flex items-center gap-1 text-amber-600 hover:text-amber-700 font-medium"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <p className="text-sm text-slate-600 mt-4">
        Showing {filteredMembers.length} of {members.length} members
      </p>
    </div>
  );
}

function DetailCard({ label, value }: { label: string; value: any }) {
  return (
    <div className="bg-slate-50 rounded-lg px-4 py-3">
      <p className="text-xs text-slate-500 mb-1">{label}</p>
      <p className="font-semibold text-slate-800 capitalize">{value || '—'}</p>
    </div>
  );
}
