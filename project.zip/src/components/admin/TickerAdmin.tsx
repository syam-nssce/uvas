import { useState, useEffect } from 'react';
import { supabase, type NewsTicker } from '../../lib/supabase';
import { adminCrud } from '../../lib/adminCrud';
import { Trash2, Plus } from 'lucide-react';

interface TickerAdminProps {
  adminCredentials?: { username: string; password: string };
}

export default function TickerAdmin({ adminCredentials }: TickerAdminProps) {
  const [tickers, setTickers] = useState<NewsTicker[]>([]);
  const [newMessage, setNewMessage] = useState('');

  useEffect(() => {
    fetchTickers();
  }, []);

  const fetchTickers = async () => {
    const { data } = await supabase
      .from('news_ticker')
      .select('*')
      .order('display_order', { ascending: true });
    if (data) setTickers(data);
  };

  const handleAdd = async () => {
    if (!newMessage.trim() || !adminCredentials) return;
    try {
      await adminCrud({
        table: 'news_ticker',
        action: 'insert',
        data: {
          message: newMessage,
          display_order: tickers.length + 1,
        },
        credentials: adminCredentials,
      });
      setNewMessage('');
      fetchTickers();
    } catch (error) {
      console.error('Add error:', error);
      alert('Failed to add ticker message.');
    }
  };

  const handleDelete = async (id: string) => {
    if (!adminCredentials) return;
    if (confirm('Remove this ticker message?')) {
      try {
        await adminCrud({
          table: 'news_ticker',
          action: 'delete',
          id,
          credentials: adminCredentials,
        });
        fetchTickers();
      } catch (error) {
        console.error('Delete error:', error);
        alert('Failed to delete ticker message.');
      }
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8 max-w-3xl">
      <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center space-x-2">
        <span>📢</span>
        <span>News Ticker</span>
      </h2>

      <p className="text-sm text-slate-600 mb-6">
        These messages scroll across the top of the home page.
      </p>

      <div className="space-y-3 mb-6">
        {tickers.map((ticker) => (
          <div key={ticker.id} className="bg-white border border-slate-200 rounded-lg p-4 flex items-center justify-between hover:shadow-md transition-shadow">
            <span className="text-slate-800">{ticker.message}</span>
            <button
              onClick={() => handleDelete(ticker.id)}
              className="ml-4 p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors flex-shrink-0"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        ))}
        {tickers.length === 0 && (
          <div className="text-center py-8 text-slate-500">No ticker messages yet</div>
        )}
      </div>

      <div className="flex gap-3">
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleAdd()}
          placeholder="Add new ticker message..."
          className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
        />
        <button
          onClick={handleAdd}
          className="bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold px-6 py-3 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all flex items-center space-x-2"
        >
          <Plus className="w-5 h-5" />
          <span>Add</span>
        </button>
      </div>
    </div>
  );
}
