import { useState, useEffect } from 'react';
import { supabase, type SiteSetting } from '../../lib/supabase';
import { adminCrud } from '../../lib/adminCrud';
import { Save } from 'lucide-react';
import HeroSliderAdmin from './HeroSliderAdmin';

interface HomeContentAdminProps {
  adminCredentials?: { username: string; password: string };
}

export default function HomeContentAdmin({ adminCredentials }: HomeContentAdminProps) {
  const [heroData, setHeroData] = useState({
    heading: '',
    subheading: '',
    affiliation: '',
    button_text: '',
  });

  const [welcomeData, setWelcomeData] = useState({
    welcome_text: '',
    banner_text: '',
  });

  const [saving, setSaving] = useState('');

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    const { data } = await supabase.from('site_settings').select('*');
    if (data) {
      const settings: Record<string, string> = {};
      data.forEach((s: SiteSetting) => {
        settings[s.setting_key] = s.setting_value;
      });

      setHeroData({
        heading: settings.hero_heading || 'Unnatha Vidyabhyasa\nAdhyapaka Sangham',
        subheading: settings.hero_subheading || 'UVAS – ABRSM, Kerala',
        affiliation: settings.hero_affiliation || 'Affiliated to ABRSM, New Delhi',
        button_text: settings.hero_button_text || 'Become a Member',
      });

      setWelcomeData({
        welcome_text: settings.home_welcome_text || 'Welcome to Unnatha Vidyabhyasa Adhyapaka Sangham (UVAS), Kerala\'s Higher Education Teachers\' Association established in 1998. Affiliated with the Akhil Bhartiya Shaikshik Mahasangh (ABRSM), New Delhi, we serve as a professional platform for teachers committed to excellence in education and cultural progress rooted in principled values.',
        banner_text: settings.home_banner_text || '✦ ഉന്നത വിദ്യാഭ്യാസ അദ്ധ്യാപക സംഘം ✦',
      });
    }
  };

  const saveSetting = async (key: string, value: string) => {
    if (!adminCredentials) return;
    await adminCrud({
      table: 'site_settings',
      action: 'upsert',
      data: { setting_key: key, setting_value: value },
      upsert_conflict: 'setting_key',
      credentials: adminCredentials,
    });
  };

  const handleSaveHero = async () => {
    if (!adminCredentials) return;
    setSaving('hero');
    try {
      await Promise.all([
        saveSetting('hero_heading', heroData.heading),
        saveSetting('hero_subheading', heroData.subheading),
        saveSetting('hero_affiliation', heroData.affiliation),
        saveSetting('hero_button_text', heroData.button_text),
      ]);
      alert('Hero section saved!');
    } catch (error) {
      console.error('Save error:', error);
      alert('Failed to save hero section.');
    }
    setSaving('');
  };

  const handleSaveWelcome = async () => {
    if (!adminCredentials) return;
    setSaving('welcome');
    try {
      await Promise.all([
        saveSetting('home_welcome_text', welcomeData.welcome_text),
        saveSetting('home_banner_text', welcomeData.banner_text),
      ]);
      alert('Home content saved!');
    } catch (error) {
      console.error('Save error:', error);
      alert('Failed to save home content.');
    }
    setSaving('');
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center space-x-2">
        <span>🏠</span>
        <span>Home Content</span>
      </h2>

      <div className="grid lg:grid-cols-2 gap-8 mb-8">
        <div className="bg-slate-50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-slate-700 mb-4">Hero Section</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Main Heading</label>
              <textarea
                value={heroData.heading}
                onChange={(e) => setHeroData({ ...heroData, heading: e.target.value })}
                rows={2}
                placeholder="Unnatha Vidyabhyasa&#10;Adhyapaka Sangham"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
              />
              <p className="text-xs text-slate-500 mt-1">Use new line for line break</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Sub-heading</label>
              <input
                type="text"
                value={heroData.subheading}
                onChange={(e) => setHeroData({ ...heroData, subheading: e.target.value })}
                placeholder="UVAS – ABRSM, Kerala"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Affiliation Text</label>
              <input
                type="text"
                value={heroData.affiliation}
                onChange={(e) => setHeroData({ ...heroData, affiliation: e.target.value })}
                placeholder="Affiliated to ABRSM, New Delhi"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Button Text</label>
              <input
                type="text"
                value={heroData.button_text}
                onChange={(e) => setHeroData({ ...heroData, button_text: e.target.value })}
                placeholder="Become a Member"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              />
            </div>

            <button
              onClick={handleSaveHero}
              disabled={saving === 'hero'}
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              <Save className="w-5 h-5" />
              <span>{saving === 'hero' ? 'Saving...' : 'Save Hero'}</span>
            </button>
          </div>
        </div>

        <div className="bg-slate-50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-slate-700 mb-4">Home Page Content</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Malayalam Banner Text</label>
              <input
                type="text"
                value={welcomeData.banner_text}
                onChange={(e) => setWelcomeData({ ...welcomeData, banner_text: e.target.value })}
                placeholder="✦ ഉന്നത വിദ്യാഭ്യാസ അദ്ധ്യാപക സംഘം ✦"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              />
              <p className="text-xs text-slate-500 mt-1">Shown between hero and welcome section</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Welcome Text</label>
              <textarea
                value={welcomeData.welcome_text}
                onChange={(e) => setWelcomeData({ ...welcomeData, welcome_text: e.target.value })}
                rows={6}
                placeholder="Welcome to Unnatha Vidyabhyasa Adhyapaka Sangham..."
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
              />
              <p className="text-xs text-slate-500 mt-1">Displayed under "Welcome to UVAS" heading</p>
            </div>

            <button
              onClick={handleSaveWelcome}
              disabled={saving === 'welcome'}
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              <Save className="w-5 h-5" />
              <span>{saving === 'welcome' ? 'Saving...' : 'Save Home Content'}</span>
            </button>
          </div>
        </div>
      </div>

      <HeroSliderAdmin />
    </div>
  );
}
