import { useState, useEffect } from 'react';
import { Newspaper, Calendar, ArrowRight, ArrowLeft } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface NewsItem {
  id: string;
  title: string;
  content: string;
  image_url: string | null;
  event_date: string | null;
  posted_date: string | null;
  created_at: string;
}

interface RecentNewsProps {
  onNavigate: (section: string) => void;
}

export default function RecentNews({ onNavigate }: RecentNewsProps) {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [selectedNews, setSelectedNews] = useState<NewsItem | null>(null);

  useEffect(() => {
    fetchRecentNews();
  }, []);

  const fetchRecentNews = async () => {
    const { data, error } = await supabase
      .from('news_events')
      .select('id, title, content, image_url, event_date, posted_date, created_at')
      .eq('published', true)
      .eq('type', 'news')
      .order('posted_date', { ascending: false, nullsFirst: false })
      .limit(6);

    if (error) {
      console.error('Error fetching news:', error);
      return;
    }

    console.log('Recent news fetched:', data);
    if (data) {
      setNews(data);
    }
  };

  const handleNewsClick = (item: NewsItem) => {
    setSelectedNews(item);
  };

  const handleBackClick = () => {
    setSelectedNews(null);
  };

  if (selectedNews) {
    return (
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden h-full flex flex-col">
        <div className="bg-gradient-to-r from-amber-600 to-orange-600 p-6">
          <button
            onClick={handleBackClick}
            className="flex items-center gap-2 text-white hover:text-amber-100 transition-colors mb-3"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm font-medium">Back to news list</span>
          </button>
          <div className="flex items-center gap-3 text-white">
            <Newspaper className="w-6 h-6" />
            <h3 className="text-xl font-bold">News Details</h3>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <h2 className="text-2xl font-bold text-slate-800 mb-4">{selectedNews.title}</h2>

          <div className="flex items-center gap-2 text-sm text-slate-500 mb-6">
            <Calendar className="w-4 h-4" />
            <span>
              {new Date(selectedNews.posted_date || selectedNews.created_at).toLocaleDateString('en-US', {
                month: 'long',
                day: 'numeric',
                year: 'numeric',
              })}
            </span>
          </div>

          {selectedNews.image_url && (
            <img
              src={selectedNews.image_url}
              alt={selectedNews.title}
              className="w-full rounded-lg mb-6 object-cover max-h-64"
            />
          )}

          <div className="prose prose-slate max-w-none">
            <p className="text-slate-700 text-base leading-relaxed whitespace-pre-wrap">
              {selectedNews.content}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden h-full">
      <div className="bg-gradient-to-r from-amber-600 to-orange-600 p-6">
        <div className="flex items-center gap-3 text-white">
          <Newspaper className="w-6 h-6" />
          <h3 className="text-xl font-bold">Recent News</h3>
        </div>
      </div>

      <div className="divide-y divide-slate-200">
        {news.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <Newspaper className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p>No recent news available</p>
          </div>
        ) : (
          news.map((item) => (
            <div
              key={item.id}
              onClick={() => handleNewsClick(item)}
              className="p-5 hover:bg-amber-50 transition-colors duration-200 cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-100 rounded-lg group-hover:bg-amber-200 transition-colors">
                  <Newspaper className="w-4 h-4 text-amber-700" />
                </div>
                <h4 className="flex-1 font-semibold text-slate-800 line-clamp-2 group-hover:text-amber-700 transition-colors leading-snug">
                  {item.title}
                </h4>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-amber-600 transition-colors shrink-0" />
              </div>
            </div>
          ))
        )}
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-200">
        <button
          onClick={() => onNavigate('news')}
          className="w-full flex items-center justify-center gap-1 text-amber-700 hover:text-amber-900 py-2 text-sm font-medium transition-colors duration-200 underline-offset-4 hover:underline"
        >
          View All News
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}
