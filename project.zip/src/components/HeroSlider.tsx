import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface HeroSliderProps {
  onSlideChange?: (isImageSlide: boolean) => void;
}

export default function HeroSlider({ onSlideChange }: HeroSliderProps) {
  const [images, setImages] = useState<string[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    fetchSlides();
  }, []);

  const totalSlides = 1 + images.length;

  useEffect(() => {
    if (totalSlides <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % totalSlides);
    }, 5000);
    return () => clearInterval(interval);
  }, [totalSlides]);

  useEffect(() => {
    onSlideChange?.(currentIndex > 0);
  }, [currentIndex, onSlideChange]);

  const fetchSlides = async () => {
    const { data, error } = await supabase.storage.from('hero-slides').list('', {
      sortBy: { column: 'name', order: 'asc' },
    });
    if (error || !data || data.length === 0) return;

    const urls = data
      .filter((f) => f.name !== '.emptyFolderPlaceholder')
      .map((file) => {
        const { data: urlData } = supabase.storage.from('hero-slides').getPublicUrl(file.name);
        return urlData.publicUrl;
      });
    setImages(urls);
  };

  if (images.length === 0) return null;

  return (
    <div className="absolute inset-0">
      <div
        className={`absolute inset-0 transition-opacity duration-1000 ${
          currentIndex === 0 ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {images.map((url, i) => (
        <img
          key={url}
          src={url}
          alt={`Slide ${i + 1}`}
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
            i + 1 === currentIndex ? 'opacity-100' : 'opacity-0'
          }`}
        />
      ))}

      <div
        className={`absolute inset-0 bg-black/30 transition-opacity duration-1000 ${
          currentIndex === 0 ? 'opacity-0' : 'opacity-100'
        }`}
      />

      {totalSlides > 1 && (
        <>
          <button
            onClick={() => setCurrentIndex((prev) => (prev - 1 + totalSlides) % totalSlides)}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full transition-all z-10"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={() => setCurrentIndex((prev) => (prev + 1) % totalSlides)}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full transition-all z-10"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="absolute bottom-20 left-1/2 -translate-x-1/2 flex gap-2 z-10">
            {Array.from({ length: totalSlides }).map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentIndex(i)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  i === currentIndex ? 'w-8 bg-white' : 'w-2 bg-white/50 hover:bg-white/75'
                }`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
