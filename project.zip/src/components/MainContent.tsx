import { useState, useEffect } from 'react';
import { Users, Award, FileText, Calendar, HelpCircle, Image, BookOpen, Shield } from 'lucide-react';
import MembershipForm from './sections/MembershipForm';
import MembershipManagement from './sections/MembershipManagement';
import HelpDesk from './sections/HelpDesk';
import NewsEvents from './sections/NewsEvents';
import OrdersCirculars from './sections/OrdersCirculars';
import Prajnabharati from './sections/Prajnabharati';
import Gallery from './sections/Gallery';
import CommitteeDisplay from './sections/CommitteeDisplay';
import EventSlider from './EventSlider';
import RecentNews from './RecentNews';
import MemberPortal from './sections/MemberPortal';
import { supabase } from '../lib/supabase';

function HomeSection({ onNavigate }: { onNavigate: (section: string) => void }) {
  const [welcomeText, setWelcomeText] = useState(
    "Welcome to Unnatha Vidyabhyasa Adhyapaka Sangham (UVAS), Kerala's Higher Education Teachers' Association established in 1998. Affiliated with the Akhil Bhartiya Shaikshik Mahasangh (ABRSM), New Delhi, we serve as a professional platform for teachers committed to excellence in education and cultural progress rooted in principled values."
  );

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from('site_settings')
        .select('setting_value')
        .eq('setting_key', 'home_welcome_text')
        .maybeSingle();
      if (data?.setting_value) {
        setWelcomeText(data.setting_value);
      }
    };
    fetch();
  }, []);

  return (
    <div className="grid lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-gradient-to-br from-white to-amber-50/40 rounded-2xl shadow-lg p-8 border border-amber-100/60 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-amber-500 via-orange-500 to-amber-600 rounded-r" />
          <p className="text-lg text-slate-700 leading-relaxed text-justify pl-4 first-letter:text-4xl first-letter:font-bold first-letter:text-amber-700 first-letter:float-left first-letter:mr-2 first-letter:leading-none">
            {welcomeText}
          </p>
        </div>
          <div className="flex items-center gap-4 pt-2">
            <h3 className="text-base font-semibold tracking-wide text-slate-700 uppercase whitespace-nowrap">
              Recent Events
            </h3>
            <div className="h-px flex-1 bg-gradient-to-r from-amber-400 to-transparent" />
          </div>
        <EventSlider onNavigate={onNavigate} />
      </div>
      <div className="lg:col-span-1">
        <RecentNews onNavigate={onNavigate} />
      </div>
    </div>
  );
}

interface MainContentProps {
  activeSection: string;
  onNavigate: (section: string) => void;
}

const getContentData = (onNavigate: (section: string) => void): Record<string, { title: string; icon: React.ReactNode; content: React.ReactNode }> => ({
  home: {
    title: 'Welcome to UVAS',
    icon: <Award className="w-8 h-8" />,
    content: <HomeSection onNavigate={onNavigate} />,
  },
  about: {
    title: 'About Us',
    icon: <BookOpen className="w-8 h-8" />,
    content: (
      <div className="space-y-4 text-slate-700 leading-relaxed">
        <p className="text-lg">
          Unnatha Vidyabhyasa Adhyapaka Sangham (UVAS) is Kerala's Higher Education Teachers' Association, registered as organization E.R. 299/98. Established in 1998, UVAS is committed to promoting excellence in education throughout Kerala and serves as a professional body for teachers across all educational levels.
        </p>
        <p>
          As an affiliate of the Akhil Bhartiya Shaikshik Mahasangh (ABRSM), New Delhi - India's largest teacher organization with over 1.4 million members - we provide our members with access to a nationwide network, professional development opportunities, and a platform for collective advocacy on educational issues. Our mission is to foster cultural, economic and intellectual progress rooted in Dharma and principled values.
        </p>
      </div>
    ),
  },
  'about-intro': {
    title: 'Introduction',
    icon: <BookOpen className="w-8 h-8" />,
    content: (
      <div className="space-y-6 text-slate-700 leading-relaxed">
        <p className="text-lg font-medium text-slate-800">
          Welcome to Unnatha Vidyabhyasa Adhyapaka Sangham (UVAS)
        </p>
        <p>
          Unnatha Vidyabhyasa Adhyapaka Sangham (UVAS) began functioning in the year 1998. It works as an affiliated organisation of Akhil Bharathiya Rashtriya Shaikshik Mahasangh (ABRSM), New Delhi.
        </p>
        <p>
          ABRSM is the largest organisation of teachers in the country with a total membership of over fourteen hundred thousand teachers ranging from the pre-primary stage to the university level. It has membership from all states and union territories of the country and is firmly cemented by a nationalistic identity.
        </p>
        <p>
          ABRSM and UVAS envision a cultural, economic and intellectual progress rooted in 'Dharma' and fostered by the principled stand and moral integrity of each of its members. The organisation has vociferously and adamantly taken a strong stand against any anti-national and sectarian aspect of the curricula; it is intolerant to the practice among certain section of the teachers to spread retrogressive and anti-India ideas into the young minds in colleges and universities.
        </p>
        <p>
          UVAS is firmly entrenched in the values of cultural nationalism and is duty bound to serve the society and country in a selfless manner.
        </p>

        <div className="grid md:grid-cols-3 gap-6 mt-8">
          <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border border-amber-200 text-center">
            <div className="text-4xl font-bold text-amber-600 mb-2">1998</div>
            <div className="text-slate-700 font-medium">Year Founded</div>
          </div>
          <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border border-amber-200 text-center">
            <div className="text-4xl font-bold text-amber-600 mb-2">14L+</div>
            <div className="text-slate-700 font-medium">National Members</div>
          </div>
          <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border border-amber-200 text-center">
            <div className="text-4xl font-bold text-amber-600 mb-2">All</div>
            <div className="text-slate-700 font-medium">States & UTs</div>
          </div>
        </div>

        <div className="bg-amber-50 border-l-4 border-amber-600 p-6 rounded-r-lg mt-8">
          <p className="font-semibold text-amber-900 mb-2">Our Core Values</p>
          <ul className="space-y-2 text-amber-800">
            <li className="flex items-start space-x-2">
              <span className="text-amber-600 font-bold mt-1">•</span>
              <span>Cultural nationalism and service to society and country</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-amber-600 font-bold mt-1">•</span>
              <span>Cultural, economic and intellectual progress rooted in Dharma</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-amber-600 font-bold mt-1">•</span>
              <span>Principled stand and moral integrity in education</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-amber-600 font-bold mt-1">•</span>
              <span>Strong stance against anti-national and sectarian curricula</span>
            </li>
          </ul>
        </div>

        <div className="bg-slate-50 border border-slate-200 p-6 rounded-xl mt-6">
          <h3 className="font-bold text-slate-800 mb-4 text-lg">Contact Us</h3>
          <div className="space-y-2 text-slate-700">
            <p className="flex items-start gap-2">
              <span className="text-xl">🏠</span>
              <span>Madhava Nivas, Elamakkara, Kochi - 26</span>
            </p>
            <p className="flex items-start gap-2">
              <span className="text-xl">✉️</span>
              <a href="mailto:uvasangh@gmail.com" className="text-amber-600 hover:text-amber-700">uvasangh@gmail.com</a>
            </p>
            <p className="flex items-start gap-2">
              <span className="text-xl">📞</span>
              <span>+91 98475 98896</span>
            </p>
          </div>
        </div>
      </div>
    ),
  },
  'about-abrsm': {
    title: 'ABRSM',
    icon: <Award className="w-8 h-8" />,
    content: (
      <div className="space-y-6 text-slate-700 leading-relaxed">
        <div className="bg-gradient-to-r from-amber-600 to-orange-600 text-white p-6 rounded-xl shadow-lg">
          <h2 className="text-2xl font-bold mb-2">Akhil Bharathiya Rashtriya Shaikshik Mahasangh</h2>
          <p className="text-white/90">National Headquarters, New Delhi · Founded 1988</p>
        </div>

        <p className="text-lg">
          Akhil Bharathiya Rashtriya Shaikshik Mahasangh (ABRSM) is the largest organisation of teachers in India, with a total membership of over fourteen hundred thousand teachers ranging from the pre-primary stage to the university level.
        </p>

        <p>
          It has membership from all states and union territories of the country and is firmly cemented by a nationalistic identity. The organisation was founded in 1988 and has its headquarters at 606/13, Krishna Gali No. 9, Mauzpur, New Delhi.
        </p>

        <p>
          ABRSM functions as a non-partisan, non-political professional organisation rooted in Indian values. It recognises that the inspiration for the teaching profession must come from India's own hoary culture and civilisation — not from western methodologies alien to Indian thought and thinking.
        </p>

        <p>
          Along with safeguarding teachers' interests including their salary, allowances, service conditions and other facilities, the Mahasangh keeps in mind its national objectives and plans and executes programmes of social concern and educational upgradation.
        </p>

        <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-8 rounded-xl border-2 border-amber-200 mt-8">
          <h3 className="text-xl font-bold text-slate-800 mb-4 text-center">Our Motto</h3>
          <div className="space-y-3 text-center">
            <p className="text-lg font-semibold text-amber-900 italic">
              "Rashtra Ke Hit Mein Shiksha<br />
              Shiksha Ke Hit Mein Shikshak<br />
              Shikshak Ke Hit Mein Samaj"
            </p>
            <div className="border-t-2 border-amber-300 my-4 mx-auto w-32"></div>
            <p className="text-slate-700 font-medium">
              Education for the nation · Teaching for education · Society for teachers
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mt-8">
          <div className="bg-white border-2 border-slate-200 p-6 rounded-xl">
            <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
              <Award className="w-6 h-6 text-amber-600" />
              National Reach
            </h3>
            <p className="text-slate-600">
              With over 14 lakh members across all states and union territories, ABRSM is firmly cemented by a nationalistic identity, bringing together teachers from pre-primary through university levels.
            </p>
          </div>

          <div className="bg-white border-2 border-slate-200 p-6 rounded-xl">
            <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-amber-600" />
              Indian Values
            </h3>
            <p className="text-slate-600">
              A non-partisan, non-political professional organisation rooted in Indian values, drawing inspiration from India's own culture and civilisation rather than western methodologies.
            </p>
          </div>
        </div>

        <div className="bg-slate-50 border border-slate-200 p-8 rounded-xl mt-6">
          <h3 className="text-xl font-bold text-slate-800 mb-4">Key Focus Areas</h3>
          <ul className="space-y-3">
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold text-xl">✓</span>
              <span>Safeguarding teachers' interests including salary, allowances, and service conditions</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold text-xl">✓</span>
              <span>Ensuring teachers receive all facilities and support they deserve</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold text-xl">✓</span>
              <span>Planning and executing programmes of social concern</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold text-xl">✓</span>
              <span>Educational upgradation initiatives aligned with national objectives</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold text-xl">✓</span>
              <span>Promoting teaching profession rooted in Indian cultural values</span>
            </li>
          </ul>
        </div>

        <div className="bg-white border-2 border-amber-200 p-6 rounded-xl mt-6">
          <h3 className="font-bold text-slate-800 mb-3">Headquarters</h3>
          <p className="text-slate-700">
            606/13, Krishna Gali No. 9, Mauzpur, New Delhi
          </p>
        </div>
      </div>
    ),
  },
  'about-history': {
    title: 'History of UVAS',
    icon: <BookOpen className="w-8 h-8" />,
    content: (
      <div className="space-y-6 text-slate-700 leading-relaxed">
        <div className="bg-gradient-to-r from-amber-600 to-orange-600 text-white p-6 rounded-xl shadow-lg">
          <h2 className="text-2xl font-bold mb-2">Our Journey</h2>
          <p className="text-white/90">Reg. No. E.R. 299/98, Kerala · Est. 1998</p>
        </div>

        <div className="space-y-8 mt-8">
          <div className="border-l-4 border-amber-600 pl-6">
            <h3 className="text-xl font-bold text-slate-800 mb-2">1998 — Foundation</h3>
            <p className="text-slate-600">
              UVAS was established in Kerala as the state wing of ABRSM, registered under Registration No. E.R. 299/98. The organisation began with a mission to unite college teachers of Kerala under a platform rooted in Indian values.
            </p>
          </div>

          <div className="border-l-4 border-amber-600 pl-6">
            <h3 className="text-xl font-bold text-slate-800 mb-2">Growth & Expansion</h3>
            <p className="text-slate-600">
              Over the years UVAS expanded its membership across all 14 districts of Kerala, covering Government, Aided, and Self-Financing colleges. District units were established to strengthen grassroots representation.
            </p>
          </div>

          <div className="border-l-4 border-amber-600 pl-6">
            <h3 className="text-xl font-bold text-slate-800 mb-2">Service & Advocacy</h3>
            <p className="text-slate-600">
              UVAS has consistently advocated for the service rights of college teachers — pay revisions, promotion under CAS, pension rights, and protection against arbitrary transfers. The organisation has met government officials and filed representations at the state level.
            </p>
          </div>

          <div className="border-l-4 border-amber-600 pl-6 bg-gradient-to-r from-amber-50 to-transparent -ml-1 pl-7 py-4">
            <h3 className="text-xl font-bold text-slate-800 mb-2">Today — 2026</h3>
            <p className="text-slate-600">
              UVAS continues to grow with 1,200+ active members across Kerala, a robust digital platform for member services, and a firm commitment to cultural nationalism and educational excellence.
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-8 rounded-xl border border-amber-200 mt-8">
          <h3 className="text-xl font-bold text-slate-800 mb-4">Key Achievements</h3>
          <ul className="space-y-3">
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold">•</span>
              <span>Registered as state wing of ABRSM (Reg. No. E.R. 299/98)</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold">•</span>
              <span>Established district units across all 14 districts of Kerala</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold">•</span>
              <span>Expanded membership to Government, Aided, and Self-Financing colleges</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold">•</span>
              <span>Advocated for pay revisions, CAS promotions, and pension rights</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold">•</span>
              <span>Successfully represented teachers in meetings with government officials</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold">•</span>
              <span>Built a robust digital platform for member services</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold">•</span>
              <span>Grew membership to over 1,200 active members statewide</span>
            </li>
          </ul>
        </div>

        <div className="bg-white border-2 border-slate-200 p-6 rounded-xl">
          <h3 className="font-bold text-slate-800 mb-3">Our Continuing Mission</h3>
          <p className="text-slate-700 leading-relaxed">
            Since 1998, UVAS has remained steadfast in its commitment to supporting Kerala's college teachers while upholding the values of cultural nationalism and educational excellence rooted in Indian traditions. We continue to advocate for teachers' welfare and provide a platform for collective voice and action.
          </p>
        </div>
      </div>
    ),
  },
  'about-vision': {
    title: 'Vision & Mission',
    icon: <Award className="w-8 h-8" />,
    content: (
      <div className="space-y-8 text-slate-700 leading-relaxed">
        <div className="bg-gradient-to-br from-amber-600 to-orange-600 text-white p-8 rounded-2xl shadow-lg">
          <h3 className="text-2xl font-bold mb-6 flex items-center gap-3">
            <Award className="w-8 h-8" />
            Vision of UVAS
          </h3>
          <div className="space-y-4 text-center">
            <p className="text-xl font-semibold text-white italic leading-relaxed">
              "Rashtra Ke Hith Mein Shiksha"
            </p>
            <p className="text-white/90">Education for National Glory</p>
            <p className="text-xl font-semibold text-white italic leading-relaxed mt-4">
              "Shiksha Ke Hith Mein Shikshak"
            </p>
            <p className="text-white/90">Teachers for Educational Glory</p>
            <p className="text-xl font-semibold text-white italic leading-relaxed mt-4">
              "Shikshak Ke Hith Mein Samaj"
            </p>
            <p className="text-white/90">Society for Teachers' Glory</p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-slate-50 to-amber-50 p-8 rounded-2xl border-2 border-amber-200">
          <h3 className="text-2xl font-bold mb-6 text-slate-800 text-center flex items-center justify-center gap-3">
            <BookOpen className="w-8 h-8 text-amber-600" />
            Emblem & Motto
          </h3>
          <div className="text-center space-y-6">
            <div className="flex justify-center mb-6">
              <div className="bg-white p-6 rounded-2xl shadow-lg border-2 border-amber-300">
                <img
                  src="/uvas.jpg"
                  alt="UVAS Emblem - Chinmudra"
                  className="w-64 h-auto mx-auto object-contain"
                />
              </div>
            </div>
            <p className="text-lg font-semibold text-slate-800">UVAS Emblem — Chinmudra</p>
            <p className="text-slate-700 leading-relaxed max-w-2xl mx-auto">
              The emblem of UNNATHA VIDYABHYASA ADHYAPAKA SANGHAM (UVAS) is the "Chinmudra image" — the gesture of knowledge and wisdom — and the motto is:
            </p>
            <div className="bg-white p-6 rounded-xl border border-amber-300 my-6">
              <p className="text-2xl font-bold text-amber-700 italic mb-2">
                "Saa Vidya Yaa Vimukthaye"
              </p>
              <p className="text-slate-600">That which liberates is true education</p>
            </div>
            <p className="text-amber-700 font-medium">
              ഉന്നത വിദ്യാഭ്യാസ അദ്ധ്യാപക സംഘം — Kerala Wing of ABRSM
            </p>
          </div>
        </div>

        <div className="bg-white border-2 border-amber-200 p-8 rounded-2xl shadow-md">
          <h3 className="text-2xl font-bold mb-6 text-slate-800 flex items-center gap-3">
            <Award className="w-8 h-8 text-amber-600" />
            Our Mission
          </h3>
          <div className="space-y-5">
            <div className="flex items-start gap-4">
              <div className="bg-amber-100 rounded-full p-2 mt-1 flex-shrink-0">
                <span className="text-amber-600 font-bold">a</span>
              </div>
              <p className="text-slate-700">
                To promote co-operative feeling amongst teachers of the Higher Education Institutions in Kerala affiliated to various Universities.
              </p>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-amber-100 rounded-full p-2 mt-1 flex-shrink-0">
                <span className="text-amber-600 font-bold">b</span>
              </div>
              <p className="text-slate-700">
                To secure for them fair conditions of life and work, better emoluments and other rights and privileges as University and various College teachers.
              </p>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-amber-100 rounded-full p-2 mt-1 flex-shrink-0">
                <span className="text-amber-600 font-bold">c</span>
              </div>
              <p className="text-slate-700">
                To establish contact with educational organizations with similar aims.
              </p>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-amber-100 rounded-full p-2 mt-1 flex-shrink-0">
                <span className="text-amber-600 font-bold">d</span>
              </div>
              <p className="text-slate-700">
                To promote higher education and research.
              </p>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-amber-100 rounded-full p-2 mt-1 flex-shrink-0">
                <span className="text-amber-600 font-bold">e</span>
              </div>
              <p className="text-slate-700">
                To enable the teaching community to safeguard harmony, peace, discipline, and ethics.
              </p>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-amber-100 rounded-full p-2 mt-1 flex-shrink-0">
                <span className="text-amber-600 font-bold">f</span>
              </div>
              <p className="text-slate-700">
                To promote healthy relationships between teachers and students, university administration, other sections of the community etc.
              </p>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-amber-100 rounded-full p-2 mt-1 flex-shrink-0">
                <span className="text-amber-600 font-bold">g</span>
              </div>
              <p className="text-slate-700">
                To work for the improvement of education in response to the challenges to the ever-changing socio-economic situation.
              </p>
            </div>

            <div className="flex items-start gap-4 bg-gradient-to-r from-amber-50 to-transparent p-4 rounded-lg -ml-2">
              <div className="bg-amber-600 rounded-full p-2 mt-1 flex-shrink-0">
                <span className="text-white font-bold">h</span>
              </div>
              <div>
                <p className="font-bold text-slate-800 mb-2">Above all</p>
                <p className="text-slate-700">
                  To work for national integration without making compromise on tradition, cultural heritage, and national pride.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    ),
  },
  'committee-state': {
    title: 'State Committee',
    icon: <Users className="w-8 h-8" />,
    content: (
      <CommitteeDisplay
        committeeType="State Committee"
        description="The State Committee leads UVAS and guides our mission across Kerala, ensuring effective governance and support for higher education teachers. The State Committee is the apex body of UVAS, responsible for policy formulation, strategic planning, and overall coordination of activities across all districts in Kerala."
        contactInfo={{
          address: 'Madhava Nivas, Elamakkara, Kochi-26, Kerala',
          email: 'uvasangh@gmail.com',
          phone: '+91 95390 00040 | +91 9847777789',
          registration: 'E.R. 299/98, Kerala',
        }}
      />
    ),
  },
  'committee-zonal': {
    title: 'Zonal Committee',
    icon: <Users className="w-8 h-8" />,
    content: (
      <CommitteeDisplay
        committeeType="Zonal Committee"
        description="UVAS is organized into four university zones across Kerala. Select a zone from the menu — Kerala University, MG University, Calicut University, or Kannur University — to view its committee."
      />
    ),
  },
  'committee-zonal-kerala': {
    title: 'Kerala University Zone',
    icon: <Users className="w-8 h-8" />,
    content: (
      <CommitteeDisplay
        committeeType="Kerala University"
        description="Zonal Committee for the Kerala University region."
      />
    ),
  },
  'committee-zonal-mg': {
    title: 'MG University Zone',
    icon: <Users className="w-8 h-8" />,
    content: (
      <CommitteeDisplay
        committeeType="MG University"
        description="Zonal Committee for the Mahatma Gandhi University region."
      />
    ),
  },
  'committee-zonal-calicut': {
    title: 'Calicut University Zone',
    icon: <Users className="w-8 h-8" />,
    content: (
      <CommitteeDisplay
        committeeType="Calicut University"
        description="Zonal Committee for the Calicut University region."
      />
    ),
  },
  'committee-zonal-kannur': {
    title: 'Kannur University Zone',
    icon: <Users className="w-8 h-8" />,
    content: (
      <CommitteeDisplay
        committeeType="Kannur University"
        description="Zonal Committee for the Kannur University region."
      />
    ),
  },
  'committee-service': {
    title: 'Service Cell',
    icon: <Shield className="w-8 h-8" />,
    content: (
      <div className="space-y-6">
        <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-8 rounded-xl border-2 border-amber-200 mb-6">
          <h3 className="text-xl font-bold text-slate-800 mb-4">Our Services</h3>
          <ul className="space-y-3">
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold text-xl">✓</span>
              <span>Guidance on service matters, promotions, and career advancement</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold text-xl">✓</span>
              <span>Support for grievance redressal and conflict resolution</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold text-xl">✓</span>
              <span>Assistance with salary, pension, and benefits queries</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold text-xl">✓</span>
              <span>Legal support and representation when needed</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-amber-600 font-bold text-xl">✓</span>
              <span>Welfare programs and member support initiatives</span>
            </li>
          </ul>
        </div>

        <CommitteeDisplay
          committeeType="Service Cell"
          description="The Service Cell provides dedicated support to UVAS members on professional matters, welfare issues, and service-related concerns. Contact the Service Cell for support with service-related matters. We're here to help UVAS members navigate professional challenges and ensure their rights are protected."
        />
      </div>
    ),
  },
  membership: {
    title: 'Membership',
    icon: <Award className="w-8 h-8" />,
    content: <MembershipForm />,
  },
  helpdesk: {
    title: 'Help Desk',
    icon: <HelpCircle className="w-8 h-8" />,
    content: <HelpDesk onNavigate={onNavigate} />,
  },
  news: {
    title: 'News & Events',
    icon: <Calendar className="w-8 h-8" />,
    content: <NewsEvents isAdmin={false} />,
  },
  orders: {
    title: 'Orders & Circulars',
    icon: <FileText className="w-8 h-8" />,
    content: <OrdersCirculars isAdmin={false} />,
  },
  gallery: {
    title: 'Gallery',
    icon: <Image className="w-8 h-8" />,
    content: <Gallery isAdmin={false} />,
  },
  prajnabharati: {
    title: 'Prajnabharati',
    icon: <BookOpen className="w-8 h-8" />,
    content: <Prajnabharati isAdmin={false} />,
  },
  'member-login': {
    title: 'Member Login',
    icon: <Users className="w-8 h-8" />,
    content: <MemberPortal onNavigate={onNavigate} />,
  },
  admin: {
    title: 'Admin',
    icon: <Shield className="w-8 h-8" />,
    content: <MembershipManagement />,
  },
});

export default function MainContent({ activeSection, onNavigate }: MainContentProps) {
  const contentData = getContentData(onNavigate);
  const section = contentData[activeSection] || contentData.home;

  const fullScreenSections = ['membership', 'member-login', 'helpdesk', 'news', 'orders', 'prajnabharati', 'gallery', 'admin'];
  const isFullScreen = fullScreenSections.includes(activeSection);

  if (isFullScreen) {
    return <>{section.content}</>;
  }

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      <div className="mb-8">
        <div className="flex items-center space-x-3 mb-4">
          <div className="bg-gradient-to-br from-amber-600 to-orange-600 p-2 rounded-lg text-white">
            {section.icon}
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-800">{section.title}</h2>
        </div>
        <div className="h-1 w-24 bg-gradient-to-r from-amber-600 to-orange-600 rounded-full"></div>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-6 sm:p-10 border border-slate-100">
        {section.content}
      </div>
    </main>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-white p-6 rounded-xl border border-slate-200 hover:shadow-lg transition-shadow duration-200">
      <div className="mb-4">{icon}</div>
      <h3 className="text-lg font-bold text-slate-800 mb-2">{title}</h3>
      <p className="text-slate-600 text-sm leading-relaxed">{description}</p>
    </div>
  );
}

function CommitteeMember({ position, name }: { position: string; name: string }) {
  return (
    <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
      <p className="font-bold text-slate-800">{position}</p>
      <p className="text-slate-600">{name}</p>
    </div>
  );
}

function BenefitItem({ text }: { text: string }) {
  return (
    <li className="flex items-start space-x-2">
      <span className="text-amber-600 font-bold">✓</span>
      <span>{text}</span>
    </li>
  );
}

function NewsCard({ date, title, description }: { date: string; title: string; description: string }) {
  return (
    <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 hover:border-amber-300 transition-colors duration-200">
      <p className="text-sm text-amber-700 font-semibold mb-2">{date}</p>
      <h3 className="text-xl font-bold text-slate-800 mb-2">{title}</h3>
      <p className="text-slate-600 leading-relaxed">{description}</p>
    </div>
  );
}

function DocumentItem({ title, date }: { title: string; date: string }) {
  return (
    <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 hover:border-amber-300 transition-colors duration-200 flex items-center justify-between">
      <div className="flex items-center space-x-3">
        <FileText className="w-5 h-5 text-amber-600" />
        <div>
          <p className="font-semibold text-slate-800">{title}</p>
          <p className="text-sm text-slate-600">{date}</p>
        </div>
      </div>
      <button className="text-amber-600 hover:text-amber-700 font-medium text-sm">View</button>
    </div>
  );
}

function GalleryPlaceholder({ text }: { text: string }) {
  return (
    <div className="aspect-square bg-gradient-to-br from-slate-100 to-amber-100 rounded-lg border-2 border-slate-200 flex items-center justify-center hover:shadow-lg transition-shadow duration-200">
      <div className="text-center p-4">
        <Image className="w-12 h-12 text-slate-400 mx-auto mb-2" />
        <p className="text-sm font-medium text-slate-600">{text}</p>
      </div>
    </div>
  );
}
