import { useState, useCallback, useEffect } from 'react';
import { Award, MapPin } from 'lucide-react';
import { UVASLogo, ABRSMLogo } from './Logos';
import HeroSlider from './HeroSlider';
import { supabase } from '../lib/supabase';

interface HeroProps {
  onNavigate: (section: string) => void;
}

export default function Hero({ onNavigate }: HeroProps) {
  const [isImageSlide, setIsImageSlide] = useState(false);
  const [heroContent, setHeroContent] = useState({
    heading: 'Unnatha Vidyabhyasa\nAdhyapaka Sangham',
    subheading: 'UVAS – ABRSM, Kerala',
    affiliation: 'Affiliated to ABRSM, New Delhi',
    button_text: 'Become a Member',
  });

  useEffect(() => {
    const fetchSettings = async () => {
      const { data } = await supabase.from('site_settings').select('*');
      if (data) {
        const settings: Record<string, string> = {};
        data.forEach((s) => {
          settings[s.setting_key] = s.setting_value;
        });
        setHeroContent({
          heading: settings.hero_heading || 'Unnatha Vidyabhyasa\nAdhyapaka Sangham',
          subheading: settings.hero_subheading || 'UVAS – ABRSM, Kerala',
          affiliation: settings.hero_affiliation || 'Affiliated to ABRSM, New Delhi',
          button_text: settings.hero_button_text || 'Become a Member',
        });
      }
    };
    fetchSettings();
  }, []);

  const handleSlideChange = useCallback((showing: boolean) => {
    setIsImageSlide(showing);
  }, []);

  const headingLines = heroContent.heading.split('\n');

  return (
    <section className="relative bg-gradient-to-b from-[hsl(220,25%,12%)] via-[hsl(220,20%,18%)] to-[hsl(24,40%,18%)] text-white overflow-hidden">
      <HeroSlider onSlideChange={handleSlideChange} />

      {/* Subtle pattern overlay */}
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '32px 32px' }} />

      <div
        className={`relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-24 transition-opacity duration-700 ${
          isImageSlide ? 'opacity-0 pointer-events-none' : 'opacity-100'
        }`}
      >
        <div className="text-center">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-8 sm:gap-12 mb-12">
            <div className="flex flex-col items-center group">
              <div className="bg-white p-6 rounded-2xl mb-3 shadow-2xl shadow-black/20 group-hover:shadow-black/30 transition-shadow duration-300">
                <div className="w-28 h-28 flex items-center justify-center">
                  <UVASLogo />
                </div>
              </div>
              <p className="text-sm font-semibold text-[hsl(40,60%,72%)] tracking-wider uppercase">UVAS</p>
              <p className="text-xs text-white/50 tracking-wide">Kerala Wing</p>
            </div>

            <div className="hidden sm:block h-20 w-px bg-gradient-to-b from-transparent via-white/20 to-transparent"></div>

            <div className="flex flex-col items-center group">
              <div className="bg-white p-6 rounded-2xl mb-3 shadow-2xl shadow-black/20 group-hover:shadow-black/30 transition-shadow duration-300">
                <div className="w-28 h-28 flex items-center justify-center">
                  <ABRSMLogo />
                </div>
              </div>
              <p className="text-sm font-semibold text-[hsl(40,60%,72%)] tracking-wider uppercase">ABRSM</p>
              <p className="text-xs text-white/50 tracking-wide">New Delhi</p>
            </div>
          </div>

          <div className="inline-flex items-center space-x-2 bg-white/[0.06] backdrop-blur-sm px-5 py-2 rounded-full mb-8 border border-white/10">
            <Award className="w-4 h-4 text-[hsl(40,60%,72%)]" />
            <span className="text-sm font-medium tracking-wider text-white/70">Reg. E.R. 299/98</span>
          </div>

          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold mb-5 leading-tight tracking-tight">
            {headingLines.map((line, i) => (
              <span key={i}>
                {line}
                {i < headingLines.length - 1 && <br />}
              </span>
            ))}
          </h1>

          <p className="text-xl sm:text-2xl text-[hsl(40,60%,72%)] font-body font-light mb-3 tracking-wide">
            {heroContent.subheading}
          </p>

          <div className="flex items-center justify-center space-x-2 text-white/40 mb-10">
            <MapPin className="w-4 h-4" />
            <p className="text-sm tracking-wide">{heroContent.affiliation}</p>
          </div>

          <div className="flex flex-wrap justify-center gap-4">
            <button
              onClick={() => onNavigate('membership')}
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium px-8 py-3.5 rounded-lg shadow-lg shadow-primary/20 transition-all duration-300 tracking-wide text-sm uppercase hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5"
            >
              {heroContent.button_text}
            </button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-background to-transparent"></div>
    </section>
  );
}
