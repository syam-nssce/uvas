import { useState, useEffect } from 'react';
import { BookOpen, Download, Eye, Plus, CreditCard as Edit2, Trash2 } from 'lucide-react';
import { supabase, type PrajnabharatiJournal } from '../../lib/supabase';

export default function Prajnabharati({ isAdmin = false }: { isAdmin?: boolean }) {
  const [journals, setJournals] = useState<PrajnabharatiJournal[]>([]);
  const [selectedJournal, setSelectedJournal] = useState<PrajnabharatiJournal | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState<PrajnabharatiJournal | null>(null);
  const [formData, setFormData] = useState({
    volume: '',
    issue: '',
    title: '',
    description: '',
    cover_image_url: '',
    pdf_url: '',
    publication_date: '',
  });

  useEffect(() => {
    fetchJournals();
  }, []);

  const fetchJournals = async () => {
    const { data } = await supabase
      .from('prajnabharati_journals')
      .select('*')
      .eq('published', true)
      .order('volume', { ascending: false })
      .order('issue', { ascending: false });

    setJournals((data as PrajnabharatiJournal[]) || []);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const dataToSubmit = {
      volume: parseInt(formData.volume),
      issue: parseInt(formData.issue),
      title: formData.title,
      description: formData.description || null,
      cover_image_url: formData.cover_image_url || null,
      pdf_url: formData.pdf_url || null,
      publication_date: formData.publication_date,
      published: true,
    };

    if (editingItem) {
      await supabase
        .from('prajnabharati_journals')
        .update(dataToSubmit)
        .eq('id', editingItem.id);
    } else {
      await supabase
        .from('prajnabharati_journals')
        .insert([dataToSubmit]);
    }

    resetForm();
    fetchJournals();
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this journal edition?')) {
      await supabase.from('prajnabharati_journals').delete().eq('id', id);
      fetchJournals();
    }
  };

  const resetForm = () => {
    setFormData({
      volume: '',
      issue: '',
      title: '',
      description: '',
      cover_image_url: '',
      pdf_url: '',
      publication_date: '',
    });
    setEditingItem(null);
    setShowForm(false);
  };

  const startEdit = (item: PrajnabharatiJournal) => {
    setEditingItem(item);
    setFormData({
      volume: item.volume.toString(),
      issue: item.issue.toString(),
      title: item.title,
      description: item.description || '',
      cover_image_url: item.cover_image_url || '',
      pdf_url: item.pdf_url || '',
      publication_date: item.publication_date,
    });
    setShowForm(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-amber-50 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-gradient-to-r from-amber-600 to-orange-600 px-8 py-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold text-white flex items-center">
                  <BookOpen className="w-8 h-8 mr-3" />
                  Prajnabharati Journal
                </h2>
                <p className="text-amber-50 mt-2">International, Multidisciplinary & Peer Reviewed Research Journal</p>
              </div>
              {isAdmin && (
                <button
                  onClick={() => setShowForm(true)}
                  className="bg-white text-amber-600 px-6 py-2 rounded-lg font-semibold hover:bg-amber-50 transition-all shadow-lg flex items-center space-x-2"
                >
                  <Plus className="w-5 h-5" />
                  <span>Add Edition</span>
                </button>
              )}
            </div>
          </div>

          {showForm && isAdmin && (
            <div className="p-8 border-b border-slate-200 bg-slate-50">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Volume</label>
                    <input
                      type="number"
                      value={formData.volume}
                      onChange={(e) => setFormData({ ...formData, volume: e.target.value })}
                      required
                      min="1"
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                      placeholder="1"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Issue</label>
                    <input
                      type="number"
                      value={formData.issue}
                      onChange={(e) => setFormData({ ...formData, issue: e.target.value })}
                      required
                      min="1"
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                      placeholder="1"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Publication Date</label>
                    <input
                      type="date"
                      value={formData.publication_date}
                      onChange={(e) => setFormData({ ...formData, publication_date: e.target.value })}
                      required
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Title</label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    placeholder="Edition title"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Description</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={4}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
                    placeholder="Brief description of this edition..."
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Cover Image URL</label>
                    <input
                      type="url"
                      value={formData.cover_image_url}
                      onChange={(e) => setFormData({ ...formData, cover_image_url: e.target.value })}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                      placeholder="https://example.com/cover.jpg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">PDF URL</label>
                    <input
                      type="url"
                      value={formData.pdf_url}
                      onChange={(e) => setFormData({ ...formData, pdf_url: e.target.value })}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                      placeholder="https://example.com/journal.pdf"
                    />
                  </div>
                </div>

                <div className="flex space-x-4">
                  <button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all"
                  >
                    {editingItem ? 'Update' : 'Publish'}
                  </button>
                  <button
                    type="button"
                    onClick={resetForm}
                    className="px-6 py-3 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="relative p-8 md:p-10 border-b border-slate-200 bg-gradient-to-br from-amber-50/60 via-white to-orange-50/40">
            <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-amber-500 to-orange-500 rounded-r" />
            <div className="max-w-4xl mx-auto pl-4">
              <p className="text-lg md:text-xl font-semibold text-slate-800 italic leading-relaxed mb-4 border-l-0">
                "An India-centred platform for open enquiry and academic intervention"
              </p>
              <p className="text-slate-600 leading-[1.8] text-sm md:text-[15px] first-letter:text-3xl first-letter:font-bold first-letter:text-amber-700 first-letter:float-left first-letter:mr-2 first-letter:leading-none">
                Prajnabharathi is an international, multidisciplinary and peer reviewed research journal covering India centered research on history, politics, international studies, philosophy, literature, sociology and Indology. Prajnabharathi aims to promote open enquiry in India's knowledge practices in light of a new paradigm.
              </p>
              <p className="text-slate-600 leading-[1.8] text-sm md:text-[15px] mt-3">
                While it is said that ancient India was the home of knowledge and inquiry, it is often not possible to present our knowledge and its sources in a contemporary way or to critically approach the basic concepts of the scientific field of India. While recognizing that there are problems with our inquiries using Western research metaphors, this journal aims to rectify our epistemological lacunas by providing an India-centred investigation.
              </p>
              <p className="text-slate-600 leading-[1.8] text-sm md:text-[15px] mt-3">
                In addition to understanding the current problems in the scientific fields of India using such a methodology, this journal also proposes an academic intervention in the thematic part of the Indian scientific field. The fact that this journal is only concerned with the scientific wealth of India means that it aims to provide a platform for open debate for thinkers from different backgrounds.
              </p>
              <a
                href="https://informaticsjournals.co.in/index.php/pbharathi/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 mt-6 bg-gradient-to-r from-amber-600 to-orange-600 text-white px-6 py-2.5 rounded-full font-semibold hover:from-amber-700 hover:to-orange-700 transition-all shadow-md hover:shadow-lg"
              >
                <BookOpen className="w-4 h-4" />
                <span>Visit Prajnabharathi Journal Portal</span>
              </a>
            </div>
          </div>

          <div className="p-8">
            {journals.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <BookOpen className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p>No journal editions available yet.</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {journals.map((journal) => (
                  <div
                    key={journal.id}
                    className="bg-white border-2 border-slate-200 rounded-xl overflow-hidden hover:shadow-2xl transition-all hover:border-amber-300 group"
                  >
                    {journal.cover_image_url ? (
                      <div className="relative overflow-hidden bg-slate-100 h-80">
                        <img
                          src={journal.cover_image_url}
                          alt={journal.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    ) : (
                      <div className="bg-gradient-to-br from-amber-100 to-orange-100 h-80 flex items-center justify-center">
                        <BookOpen className="w-24 h-24 text-amber-600 opacity-50" />
                      </div>
                    )}

                    <div className="p-6">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-bold bg-amber-100 text-amber-800 px-3 py-1 rounded-full">
                            Vol. {journal.volume}
                          </span>
                          <span className="text-xs font-bold bg-orange-100 text-orange-800 px-3 py-1 rounded-full">
                            Issue {journal.issue}
                          </span>
                        </div>
                      </div>

                      <h3 className="text-xl font-bold text-slate-800 mb-2 line-clamp-2">
                        {journal.title}
                      </h3>

                      {journal.description && (
                        <p className="text-sm text-slate-600 mb-4 line-clamp-3">
                          {journal.description}
                        </p>
                      )}

                      <p className="text-xs text-slate-500 mb-4">
                        Published: {new Date(journal.publication_date).toLocaleDateString('en-IN', {
                          year: 'numeric',
                          month: 'long',
                        })}
                      </p>

                      <div className="flex items-center space-x-2">
                        {journal.pdf_url && (
                          <a
                            href={journal.pdf_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 flex items-center justify-center space-x-2 bg-gradient-to-r from-amber-600 to-orange-600 text-white px-4 py-2 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all"
                          >
                            <Download className="w-4 h-4" />
                            <span>Download PDF</span>
                          </a>
                        )}
                        <button
                          onClick={() => setSelectedJournal(journal)}
                          className="p-2 border border-slate-300 rounded-lg hover:bg-slate-50 transition-all"
                        >
                          <Eye className="w-5 h-5 text-slate-600" />
                        </button>
                        {isAdmin && (
                          <>
                            <button
                              onClick={() => startEdit(journal)}
                              className="p-2 border border-slate-300 rounded-lg hover:bg-blue-50 transition-all"
                            >
                              <Edit2 className="w-5 h-5 text-blue-600" />
                            </button>
                            <button
                              onClick={() => handleDelete(journal.id)}
                              className="p-2 border border-slate-300 rounded-lg hover:bg-red-50 transition-all"
                            >
                              <Trash2 className="w-5 h-5 text-red-600" />
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {selectedJournal && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          onClick={() => setSelectedJournal(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {selectedJournal.cover_image_url && (
              <img
                src={selectedJournal.cover_image_url}
                alt={selectedJournal.title}
                className="w-full h-96 object-cover"
              />
            )}
            <div className="p-8">
              <div className="flex items-center space-x-2 mb-4">
                <span className="text-sm font-bold bg-amber-100 text-amber-800 px-3 py-1 rounded-full">
                  Volume {selectedJournal.volume}
                </span>
                <span className="text-sm font-bold bg-orange-100 text-orange-800 px-3 py-1 rounded-full">
                  Issue {selectedJournal.issue}
                </span>
              </div>
              <h2 className="text-3xl font-bold text-slate-800 mb-4">{selectedJournal.title}</h2>
              <p className="text-slate-600 mb-4">{selectedJournal.description}</p>
              <p className="text-sm text-slate-500 mb-6">
                Published: {new Date(selectedJournal.publication_date).toLocaleDateString('en-IN', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </p>
              {selectedJournal.pdf_url && (
                <a
                  href={selectedJournal.pdf_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-2 bg-gradient-to-r from-amber-600 to-orange-600 text-white px-6 py-3 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all"
                >
                  <Download className="w-5 h-5" />
                  <span>Download Full PDF</span>
                </a>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
