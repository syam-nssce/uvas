import { useState, useEffect } from 'react';
import { Calendar, Newspaper, Plus, CreditCard as Edit2, Trash2, ArrowLeft, FileText } from 'lucide-react';
import { supabase, type NewsEvent } from '../../lib/supabase';

export default function NewsEvents({ isAdmin = false, selectedNewsId }: { isAdmin?: boolean; selectedNewsId?: string }) {
  const [items, setItems] = useState<NewsEvent[]>([]);
  const [filter, setFilter] = useState<'all' | 'news' | 'event'>('all');
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState<NewsEvent | null>(null);
  const [selectedItem, setSelectedItem] = useState<NewsEvent | null>(null);
  const [formData, setFormData] = useState({
    type: 'news' as 'news' | 'event',
    title: '',
    content: '',
    image_url: '',
    document_url: '',
    event_date: '',
    posted_date: '',
  });

  useEffect(() => {
    fetchItems();
  }, []);

  useEffect(() => {
    if (selectedNewsId && items.length > 0) {
      const item = items.find(i => i.id === selectedNewsId);
      if (item) {
        setSelectedItem(item);
      }
    } else {
      setSelectedItem(null);
    }
  }, [selectedNewsId, items]);

  const fetchItems = async () => {
    const query = supabase
      .from('news_events')
      .select('*')
      .eq('published', true)
      .order('posted_date', { ascending: false, nullsFirst: false });

    const { data, error } = await query;
    console.log('News/Events fetched:', data, 'Error:', error);
    setItems(data || []);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (editingItem) {
      await supabase
        .from('news_events')
        .update({
          ...formData,
          event_date: formData.event_date || null,
          posted_date: formData.posted_date || null,
        })
        .eq('id', editingItem.id);
    } else {
      await supabase
        .from('news_events')
        .insert([{
          ...formData,
          event_date: formData.event_date || null,
          posted_date: formData.posted_date || null,
          published: true,
          created_by: 'demo-admin-id',
        }]);
    }

    resetForm();
    fetchItems();
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this item?')) {
      await supabase.from('news_events').delete().eq('id', id);
      fetchItems();
    }
  };

  const resetForm = () => {
    setFormData({
      type: 'news',
      title: '',
      content: '',
      image_url: '',
      document_url: '',
      event_date: '',
      posted_date: '',
    });
    setEditingItem(null);
    setShowForm(false);
  };

  const startEdit = (item: NewsEvent) => {
    setEditingItem(item);
    setFormData({
      type: item.type as 'news' | 'event',
      title: item.title,
      content: item.content,
      image_url: item.image_url || '',
      document_url: item.document_url || '',
      event_date: item.event_date || '',
      posted_date: item.posted_date || '',
    });
    setShowForm(true);
  };

  const filteredItems = filter === 'all' ? items : items.filter(item => item.type === filter);

  if (selectedItem) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-amber-50 py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-amber-600 to-orange-600 px-8 py-6">
              <button
                onClick={() => setSelectedItem(null)}
                className="mb-4 flex items-center gap-2 text-white hover:text-amber-100 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back to all news</span>
              </button>
              <div className="flex items-start justify-between">
                <div>
                  <span className={`inline-block text-xs font-semibold px-3 py-1 rounded-full mb-3 ${
                    selectedItem.type === 'news' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                  }`}>
                    {selectedItem.type === 'news' ? 'NEWS' : 'EVENT'}
                  </span>
                  <h2 className="text-3xl font-bold text-white">{selectedItem.title}</h2>
                  <div className="flex items-center gap-4 mt-3 text-amber-50">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {new Date(selectedItem.created_at).toLocaleDateString('en-US', {
                        month: 'long',
                        day: 'numeric',
                        year: 'numeric',
                      })}
                    </span>
                    {selectedItem.event_date && (
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Event: {new Date(selectedItem.event_date).toLocaleDateString('en-US', {
                          month: 'long',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

<div className="p-8">
              {selectedItem.image_url && (
                <img
                  src={selectedItem.image_url}
                  alt={selectedItem.title}
                  className="w-full h-96 object-cover rounded-xl mb-8"
                />
              )}
              <div className="prose prose-lg max-w-none">
                <p className="text-slate-700 text-lg leading-relaxed whitespace-pre-wrap">
                  {selectedItem.content}
                </p>
              </div>
              {selectedItem.type === 'news' && selectedItem.document_url && (
                <div className="mt-8">
                  <a
                    href={selectedItem.document_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-amber-700 hover:to-orange-700 transition-all shadow-lg"
                  >
                    <FileText className="w-5 h-5" />
                    <span>Download Document (PDF)</span>
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-amber-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-gradient-to-r from-amber-600 to-orange-600 px-8 py-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold text-white">News & Events</h2>
                <p className="text-amber-50 mt-2">Stay updated with latest announcements</p>
              </div>
              {isAdmin && (
                <button
                  onClick={() => setShowForm(true)}
                  className="bg-white text-amber-600 px-6 py-2 rounded-lg font-semibold hover:bg-amber-50 transition-all shadow-lg flex items-center space-x-2"
                >
                  <Plus className="w-5 h-5" />
                  <span>Add New</span>
                </button>
              )}
            </div>
          </div>

          {showForm && isAdmin && (
            <div className="p-8 border-b border-slate-200 bg-slate-50">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Type</label>
                    <select
                      value={formData.type}
                      onChange={(e) => setFormData({ ...formData, type: e.target.value as 'news' | 'event' })}
                      required
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    >
                      <option value="news">News</option>
                      <option value="event">Event</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Title</label>
                    <input
                      type="text"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      required
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                      placeholder="Enter title"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Content</label>
                  <textarea
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    required
                    rows={5}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
                    placeholder="Enter content..."
                  />
                </div>

<div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Image URL (optional)</label>
                  <input
                    type="url"
                    value={formData.image_url}
                    onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                {formData.type === 'event' ? (
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Date of Event</label>
                      <input
                        type="date"
                        value={formData.event_date}
                        onChange={(e) => setFormData({ ...formData, event_date: e.target.value })}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Date of Posting</label>
                      <input
                        type="date"
                        value={formData.posted_date}
                        onChange={(e) => setFormData({ ...formData, posted_date: e.target.value })}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Date of Posting</label>
                      <input
                        type="date"
                        value={formData.posted_date}
                        onChange={(e) => setFormData({ ...formData, posted_date: e.target.value })}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Document URL (optional PDF)</label>
                      <input
                        type="url"
                        value={formData.document_url}
                        onChange={(e) => setFormData({ ...formData, document_url: e.target.value })}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                        placeholder="https://example.com/document.pdf"
                      />
                    </div>
                  </div>
                )}

                <div className="flex space-x-4">
                  <button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all"
                  >
                    {editingItem ? 'Update' : 'Publish'}
                  </button>
                  <button
                    type="button"
                    onClick={resetForm}
                    className="px-6 py-3 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="p-6">
            <div className="flex items-center space-x-3 mb-6">
              <button
                onClick={() => setFilter('all')}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  filter === 'all' ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilter('news')}
                className={`px-4 py-2 rounded-lg font-medium transition-all flex items-center space-x-2 ${
                  filter === 'news' ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Newspaper className="w-4 h-4" />
                <span>News</span>
              </button>
              <button
                onClick={() => setFilter('event')}
                className={`px-4 py-2 rounded-lg font-medium transition-all flex items-center space-x-2 ${
                  filter === 'event' ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Events</span>
              </button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => !isAdmin && setSelectedItem(item)}
                  className={`bg-white border border-slate-200 rounded-xl overflow-hidden hover:shadow-lg transition-all ${!isAdmin ? 'cursor-pointer' : ''}`}
                >
                  {item.image_url && (
                    <img src={item.image_url} alt={item.title} className="w-full h-48 object-cover" />
                  )}
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-semibold px-3 py-1 rounded-full ${
                          item.type === 'news' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                        }`}>
                          {item.type === 'news' ? 'NEWS' : 'EVENT'}
                        </span>
                        {item.type === 'news' && item.document_url && (
                          <span className="text-xs font-semibold px-2 py-1 rounded-full bg-red-100 text-red-800 flex items-center gap-1">
                            <FileText className="w-3 h-3" />
                            PDF
                          </span>
                        )}
                      </div>
                      {isAdmin && (
                        <div className="flex space-x-2">
                          <button onClick={() => startEdit(item)} className="text-amber-600 hover:text-amber-700">
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button onClick={() => handleDelete(item.id)} className="text-red-600 hover:text-red-700">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>
                    <h3 className="text-xl font-bold text-slate-800 mb-2">{item.title}</h3>
                    <p className="text-slate-600 text-sm line-clamp-3 mb-4">{item.content}</p>
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      {item.type === 'event' && item.event_date && (
                        <span className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>Event: {new Date(item.event_date).toLocaleDateString()}</span>
                        </span>
                      )}
                      <span className="ml-auto">Posted: {new Date(item.posted_date || item.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredItems.length === 0 && (
              <div className="text-center py-12 text-slate-500">
                <p>No {filter !== 'all' ? filter : 'items'} available at the moment.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
