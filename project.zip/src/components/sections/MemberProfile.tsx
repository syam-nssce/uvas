import { useState, useEffect } from 'react';
import { Save, X, Edit2, User, Mail, Phone, MapPin, Building, GraduationCap, Calendar, Briefcase, Hash, BookOpen, Link as LinkIcon } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface MemberProfileProps {
  memberId: string;
}

interface MemberData {
  id: string;
  full_name: string;
  email: string;
  mobile: string | null;
  date_of_birth: string | null;
  phone: string | null;
  house_address: string | null;
  district: string | null;
  religion: string | null;
  employee_id: string | null;
  designation: string | null;
  college_name: string | null;
  college_address: string | null;
  college_type: string | null;
  university: string | null;
  area_of_specialization: string | null;
  experience_years: number | null;
  service_joining_date: string | null;
  retirement_date: string | null;
  membership_type: string;
  membership_category: string | null;
  status: string;
  payment_status: string;
  joined_date: string | null;
  renewal_date: string | null;
  last_renewal_date: string | null;
  orcid_id: string | null;
  google_scholar_url: string | null;
  vidwan_id: string | null;
  researcher_id: string | null;
  scopus_id: string | null;
}

const KERALA_DISTRICTS = [
  'Thiruvananthapuram', 'Kollam', 'Pathanamthitta', 'Alappuzha', 'Kottayam',
  'Idukki', 'Ernakulam', 'Thrissur', 'Palakkad', 'Malappuram',
  'Kozhikode', 'Wayanad', 'Kannur', 'Kasaragod'
];

const DESIGNATIONS = ['Professor', 'Associate Professor', 'Assistant Professor', 'Lecturer', 'Other'];
const COLLEGE_TYPES = ['Government', 'Aided', 'Self-Financing'];
const UNIVERSITIES = [
  'Kerala University', 'Mahatma Gandhi University', 'Calicut University',
  'Kannur University', 'APJ Abdul Kalam Technological University', 'Other'
];
const RELIGIONS = ['Hindu', 'Muslim', 'Christian', 'Sikh', 'Buddhist', 'Jain', 'Other'];
const MEMBERSHIP_CATEGORIES = ['govt-aided', 'self-financing'];

export default function MemberProfile({ memberId }: MemberProfileProps) {
  const [member, setMember] = useState<MemberData | null>(null);
  const [editing, setEditing] = useState(false);
  const [editData, setEditData] = useState<Partial<MemberData>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchMember();
  }, [memberId]);

  const fetchMember = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('members')
      .select('id, full_name, email, mobile, date_of_birth, phone, house_address, district, religion, employee_id, designation, college_name, college_address, college_type, university, area_of_specialization, experience_years, service_joining_date, retirement_date, membership_type, membership_category, status, payment_status, joined_date, renewal_date, last_renewal_date, orcid_id, google_scholar_url, vidwan_id, researcher_id, scopus_id')
      .eq('id', memberId)
      .maybeSingle();
    if (data) setMember(data as MemberData);
    if (error) setError('Failed to load profile');
    setLoading(false);
  };

  const calcExperience = (startDate: string | null | undefined): { years: number | null; label: string } => {
    if (!startDate) return { years: null, label: '' };
    const start = new Date(startDate);
    if (isNaN(start.getTime())) return { years: null, label: '' };
    const now = new Date();
    if (start > now) return { years: null, label: '' };
    let years = now.getFullYear() - start.getFullYear();
    const m = now.getMonth() - start.getMonth();
    if (m < 0 || (m === 0 && now.getDate() < start.getDate())) years--;
    if (years < 0) return { years: null, label: '' };
    const totalMonths = (now.getFullYear() - start.getFullYear()) * 12 + (now.getMonth() - start.getMonth()) - (now.getDate() < start.getDate() ? 1 : 0);
    const months = totalMonths - years * 12;
    if (years === 0 && months === 0) return { years: 0, label: 'Less than a month' };
    const parts: string[] = [];
    if (years > 0) parts.push(`${years} year${years > 1 ? 's' : ''}`);
    if (months > 0) parts.push(`${months} month${months > 1 ? 's' : ''}`);
    return { years, label: parts.join(' ') };
  };

  const startEdit = () => {
    if (!member) return;
    setEditData({ ...member });
    setEditing(true);
    setError('');
    setSuccess('');
  };

  const cancelEdit = () => {
    setEditing(false);
    setEditData({});
    setError('');
  };

  const handleSave = async () => {
    if (!member) return;
    setSaving(true);
    setError('');

    // Exclude non-editable fields. joined_date is editable ONLY if it has not been set yet.
    // Email and date_of_birth are LOCKED. Mobile IS editable.
    const { id, email, date_of_birth, status, payment_status, joined_date, renewal_date, last_renewal_date, membership_type, membership_category, experience_years, ...rest } = editData as MemberData;
    const updatable: Record<string, any> = { ...rest };
    // Normalize mobile to digits only (max 10)
    if (typeof updatable.mobile === 'string') {
      updatable.mobile = updatable.mobile.replace(/\D/g, '').slice(0, 10);
      if (updatable.mobile.length !== 10) {
        setError('Mobile number must be exactly 10 digits.');
        setSaving(false);
        return;
      }
    }
    if (!member.joined_date && joined_date) {
      updatable.joined_date = joined_date;
    }
    // Derive membership_category from college_type (Govt/Aided -> govt-aided, Self-Financing -> self-financing)
    const ct = (rest.college_type || '').toLowerCase();
    if (ct === 'government' || ct === 'aided') {
      updatable.membership_category = 'govt-aided';
    } else if (ct === 'self-financing') {
      updatable.membership_category = 'self-financing';
    }
    // Derive experience_years from service_joining_date
    const exp = calcExperience(rest.service_joining_date);
    if (exp.years !== null) {
      updatable.experience_years = exp.years;
    }

    const { data, error: fnError } = await supabase.functions.invoke('member-update', {
      body: {
        action: 'update_profile',
        member_id: member.id,
        update_data: updatable,
      },
    });

    if (fnError || !data?.success) {
      setError(data?.error || 'Failed to update profile');
    } else {
      setSuccess('Profile updated successfully!');
      setEditing(false);
      fetchMember();
      setTimeout(() => setSuccess(''), 3000);
    }
    setSaving(false);
  };

  const updateField = (field: string, value: string | number | null) => {
    setEditData(prev => ({ ...prev, [field]: value }));
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
        <div className="animate-spin w-8 h-8 border-4 border-amber-500 border-t-transparent rounded-full mx-auto"></div>
        <p className="text-slate-500 mt-3">Loading profile...</p>
      </div>
    );
  }

  if (!member) return null;

  const ReadOnlyField = ({ icon: Icon, label, value }: { icon: any; label: string; value: string | null | undefined }) => (
    <div className="flex items-start gap-3 py-3">
      <Icon className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
      <div className="min-w-0">
        <p className="text-xs text-slate-500 font-medium">{label}</p>
        <p className="text-sm text-slate-800 font-medium">{value || '—'}</p>
      </div>
    </div>
  );

  const EditableField = ({ label, field, value, type = 'text', disabled = false, options }: {
    label: string; field: string; value: string | number | null | undefined; type?: string; disabled?: boolean; options?: string[];
  }) => (
    <div>
      <label className="block text-xs font-medium text-slate-600 mb-1">{label}</label>
      {options ? (
        <select
          value={value?.toString() || ''}
          onChange={(e) => updateField(field, e.target.value)}
          disabled={disabled}
          className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent disabled:bg-slate-100 disabled:text-slate-500"
        >
          <option value="">Select</option>
          {options.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : (
        <input
          type={type}
          value={value?.toString() || ''}
          onChange={(e) => updateField(field, type === 'number' ? (e.target.value ? Number(e.target.value) : null) : e.target.value)}
          disabled={disabled}
          className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed"
        />
      )}
      {disabled && <p className="text-xs text-red-400 mt-0.5">Cannot be edited</p>}
    </div>
  );

  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
      <div className="px-8 py-5 border-b border-slate-200 flex items-center justify-between">
        <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <User className="w-5 h-5 text-amber-600" />
          My Profile
        </h3>
        <div className="flex gap-2">
          {editing ? (
            <>
              <button onClick={cancelEdit} className="flex items-center gap-1 px-4 py-2 text-sm border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-700">
                <X className="w-4 h-4" /> Cancel
              </button>
              <button onClick={handleSave} disabled={saving} className="flex items-center gap-1 px-4 py-2 text-sm bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg hover:from-amber-700 hover:to-orange-700 disabled:opacity-50">
                <Save className="w-4 h-4" /> {saving ? 'Saving...' : 'Save'}
              </button>
            </>
          ) : (
            <button onClick={startEdit} className="flex items-center gap-1 px-4 py-2 text-sm bg-amber-50 text-amber-700 rounded-lg hover:bg-amber-100 font-medium">
              <Edit2 className="w-4 h-4" /> Edit Profile
            </button>
          )}
        </div>
      </div>

      {error && <div className="mx-8 mt-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>}
      {success && <div className="mx-8 mt-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">{success}</div>}

      {!editing ? (
        /* View Mode */
        <div className="p-8">
          {/* Status badges */}
          <div className="flex flex-wrap gap-2 mb-6">
            <span className={`text-xs px-3 py-1 rounded-full font-medium ${member.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
              {member.status?.toUpperCase()}
            </span>
            <span className={`text-xs px-3 py-1 rounded-full font-medium ${member.payment_status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}`}>
              Payment: {member.payment_status}
            </span>
            <span className="text-xs px-3 py-1 rounded-full font-medium bg-blue-100 text-blue-800">
              {member.membership_category || member.membership_type}
            </span>
          </div>

          <div className="grid md:grid-cols-2 gap-x-12">
            <div>
              <h4 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-2 border-b pb-1">Personal</h4>
              <ReadOnlyField icon={User} label="Full Name" value={member.full_name} />
              <ReadOnlyField icon={Mail} label="Email" value={member.email} />
              <ReadOnlyField icon={Phone} label="Mobile" value={member.mobile} />
              <ReadOnlyField icon={Phone} label="Phone" value={member.phone} />
              <ReadOnlyField icon={Calendar} label="Date of Birth" value={member.date_of_birth} />
              <ReadOnlyField icon={User} label="Religion" value={member.religion} />
              <ReadOnlyField icon={MapPin} label="House Address" value={member.house_address} />
              <ReadOnlyField icon={MapPin} label="District" value={member.district} />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-2 border-b pb-1">Professional</h4>
              <ReadOnlyField icon={Hash} label="Employee ID" value={member.employee_id} />
              <ReadOnlyField icon={Briefcase} label="Designation" value={member.designation} />
              <ReadOnlyField icon={Building} label="College Name" value={member.college_name} />
              <ReadOnlyField icon={Building} label="College Address" value={member.college_address} />
              <ReadOnlyField icon={Building} label="College Type" value={member.college_type} />
              <ReadOnlyField icon={GraduationCap} label="University" value={member.university} />
              <ReadOnlyField icon={GraduationCap} label="Area of Specialization" value={member.area_of_specialization} />
              <ReadOnlyField icon={Calendar} label="Date of Joining Service" value={member.service_joining_date} />
              <ReadOnlyField icon={Briefcase} label="Experience (auto-calculated)" value={calcExperience(member.service_joining_date).label || (member.experience_years ? `${member.experience_years} years` : null)} />
              <ReadOnlyField icon={Calendar} label="Retirement Date" value={member.retirement_date} />
            </div>
          </div>

          <div className="mt-6 pt-4 border-t">
            <h4 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-2">Academic Profiles</h4>
            <div className="grid md:grid-cols-2 gap-x-12">
              <div>
                <ReadOnlyField icon={Hash} label="ORCID iD" value={member.orcid_id} />
                <ReadOnlyField icon={LinkIcon} label="Google Scholar" value={member.google_scholar_url} />
                <ReadOnlyField icon={BookOpen} label="Vidwan ID" value={member.vidwan_id} />
              </div>
              <div>
                <ReadOnlyField icon={Hash} label="Researcher ID" value={member.researcher_id} />
                <ReadOnlyField icon={Hash} label="Scopus ID" value={member.scopus_id} />
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t">
            <h4 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-2">Membership</h4>
            <div className="grid md:grid-cols-3 gap-4 text-sm">
              <div><span className="text-slate-500">Joined UVAS:</span> <span className="font-medium">{member.joined_date || <span className="text-orange-600">Not set — please update in Edit Profile</span>}</span></div>
              <div><span className="text-slate-500">Last Renewal:</span> <span className="font-medium">{member.last_renewal_date || '—'}</span></div>
              {member.joined_date && (
                <div><span className="text-slate-500">Renewal Due:</span> <span className="font-medium">{member.renewal_date || '—'}</span></div>
              )}
              <div><span className="text-slate-500">Category:</span> <span className="font-medium">{member.membership_category || '—'}</span></div>
            </div>
          </div>
        </div>
      ) : (
        /* Edit Mode */
        <div className="p-8">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-slate-700 uppercase tracking-wider border-b pb-1">Personal</h4>
              <EditableField label="Full Name *" field="full_name" value={editData.full_name} />
              <EditableField label="Email (locked)" field="email" value={editData.email} type="email" disabled />
              <EditableField label="Mobile Number *" field="mobile" value={editData.mobile} type="tel" />
              <EditableField label="Phone" field="phone" value={editData.phone} />
              <EditableField label="Date of Birth (locked)" field="date_of_birth" value={editData.date_of_birth} type="date" disabled />
              <EditableField label="Religion *" field="religion" value={editData.religion} options={RELIGIONS} />
              <EditableField label="House / Residential Address *" field="house_address" value={editData.house_address} />
              <EditableField label="District *" field="district" value={editData.district} options={KERALA_DISTRICTS} />
            </div>
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-slate-700 uppercase tracking-wider border-b pb-1">Professional</h4>
              <EditableField label="Designation *" field="designation" value={editData.designation} options={DESIGNATIONS} />
              <EditableField label="Employee ID *" field="employee_id" value={editData.employee_id} />
              <EditableField label="Type of College *" field="college_type" value={editData.college_type} options={COLLEGE_TYPES} />
              <EditableField label="University *" field="university" value={editData.university} options={UNIVERSITIES} />
              <EditableField label="College Name *" field="college_name" value={editData.college_name} />
              <EditableField label="College Address *" field="college_address" value={editData.college_address} />
              <EditableField label="Area of Specialization" field="area_of_specialization" value={editData.area_of_specialization} />
              <div>
                <EditableField label="Date of Joining Service *" field="service_joining_date" value={editData.service_joining_date} type="date" />
                {editData.service_joining_date && (
                  <p className="text-xs text-amber-700 mt-1 font-medium">
                    Years of Experience: <span className="font-bold">{calcExperience(editData.service_joining_date).label || '—'}</span>
                  </p>
                )}
              </div>
              <EditableField label="Retirement Date" field="retirement_date" value={editData.retirement_date} type="date" />
              <EditableField
                label={member.joined_date ? 'Date of Joining UVAS (locked)' : 'Date of Joining UVAS * — set this once'}
                field="joined_date"
                value={editData.joined_date}
                type="date"
                disabled={!!member.joined_date}
              />
            </div>
          </div>

          <div className="mt-6 pt-4 border-t">
            <h4 className="text-sm font-bold text-slate-700 uppercase tracking-wider border-b pb-1 mb-4">Academic Profiles (optional)</h4>
            <div className="grid md:grid-cols-2 gap-6">
              <EditableField label="ORCID iD" field="orcid_id" value={editData.orcid_id} />
              <EditableField label="Google Scholar Profile URL" field="google_scholar_url" value={editData.google_scholar_url} type="url" />
              <EditableField label="Vidwan ID" field="vidwan_id" value={editData.vidwan_id} />
              <EditableField label="Researcher ID (Web of Science)" field="researcher_id" value={editData.researcher_id} />
              <EditableField label="Scopus Author ID" field="scopus_id" value={editData.scopus_id} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}