import { useState, useEffect } from 'react';
import { supabase, type CommitteeMember } from '../../lib/supabase';
import { Mail, Phone, MapPin } from 'lucide-react';

interface CommitteeDisplayProps {
  committeeType: string;
  description: string;
  contactInfo?: {
    address?: string;
    email?: string;
    phone?: string;
    registration?: string;
  };
}

export default function CommitteeDisplay({ committeeType, description, contactInfo }: CommitteeDisplayProps) {
  const [members, setMembers] = useState<CommitteeMember[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMembers();
  }, [committeeType]);

  const fetchMembers = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('committee_members')
      .select('*')
      .eq('committee_type', committeeType)
      .order('display_order', { ascending: true });
    if (data) setMembers(data);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-pulse text-slate-600">Loading committee members...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <p className="text-slate-700 mb-6">{description}</p>

      {members.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {members.map((member) => (
            <div
              key={member.id}
              className="group bg-white border-2 border-slate-200 rounded-xl overflow-hidden hover:border-amber-400 hover:shadow-xl transition-all duration-300"
            >
              {member.photo_url ? (
                <div className="relative h-64 bg-gradient-to-br from-amber-50 to-orange-50 overflow-hidden">
                  <img
                    src={member.photo_url}
                    alt={member.full_name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                    <h3 className="font-bold text-xl mb-1">{member.full_name}</h3>
                    <p className="text-amber-200 font-semibold text-sm">{member.designation}</p>
                  </div>
                </div>
              ) : (
                <div className="bg-gradient-to-br from-amber-100 to-orange-100 p-6 text-center">
                  <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-white/50 flex items-center justify-center">
                    <span className="text-4xl font-bold text-amber-700">
                      {member.full_name.charAt(0)}
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-800 text-lg mb-1">{member.full_name}</h3>
                  <p className="text-amber-700 font-semibold text-sm">{member.designation}</p>
                </div>
              )}

              <div className="p-4 space-y-2">
                {member.district && (
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <MapPin className="w-4 h-4 text-amber-600 flex-shrink-0" />
                    <span>{member.district}</span>
                  </div>
                )}
                {member.mobile && (
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Phone className="w-4 h-4 text-amber-600 flex-shrink-0" />
                    <a href={`tel:${member.mobile}`} className="hover:text-amber-600 transition-colors">
                      {member.mobile}
                    </a>
                  </div>
                )}
                {member.email && (
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Mail className="w-4 h-4 text-amber-600 flex-shrink-0" />
                    <a href={`mailto:${member.email}`} className="hover:text-amber-600 break-all transition-colors">
                      {member.email}
                    </a>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-amber-50 border-l-4 border-amber-600 p-6 rounded-r-lg mb-6">
          <p className="text-slate-700">
            Committee member information will be updated soon. Please check back later.
          </p>
        </div>
      )}

      {contactInfo && (
        <div className="bg-white border-2 border-slate-200 p-6 rounded-xl">
          <h3 className="font-bold text-slate-800 mb-4 text-lg">Contact Information</h3>
          <div className="space-y-3 text-slate-700">
            {contactInfo.address && (
              <p className="flex items-start gap-2">
                <span className="font-semibold min-w-[100px]">Address:</span>
                <span>{contactInfo.address}</span>
              </p>
            )}
            {contactInfo.email && (
              <p className="flex items-start gap-2">
                <span className="font-semibold min-w-[100px]">Email:</span>
                <a href={`mailto:${contactInfo.email}`} className="text-amber-600 hover:text-amber-700">
                  {contactInfo.email}
                </a>
              </p>
            )}
            {contactInfo.phone && (
              <p className="flex items-start gap-2">
                <span className="font-semibold min-w-[100px]">Phone:</span>
                <span>{contactInfo.phone}</span>
              </p>
            )}
            {contactInfo.registration && (
              <p className="flex items-start gap-2">
                <span className="font-semibold min-w-[100px]">Registration:</span>
                <span>{contactInfo.registration}</span>
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
