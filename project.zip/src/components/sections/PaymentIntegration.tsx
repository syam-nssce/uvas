import { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { CheckCircle, AlertCircle, Smartphone } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

export default function PaymentIntegration({ memberId, amount = 1000 }: { memberId?: string; amount?: number }) {
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'success' | 'failed'>('idle');
  const [upiId, setUpiId] = useState('syam.sankar8@oksbi');
  const [utrInput, setUtrInput] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const fetchUpiId = async () => {
      const { data } = await supabase
        .from('site_settings')
        .select('setting_value')
        .eq('setting_key', 'gpay_upi_id')
        .single();
      if (data?.setting_value) setUpiId(data.setting_value);
    };
    fetchUpiId();
  }, []);

  const upiUrl = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent('UVAS Membership')}&am=${amount}&cu=INR&tn=${encodeURIComponent('UVAS Membership Fee')}`;

  const handleConfirmPayment = async () => {
    if (!utrInput.trim()) return;
    setSubmitting(true);
    try {
      if (memberId) {
        const { data, error } = await supabase.functions.invoke('member-update', {
          body: {
            action: 'submit_payment',
            member_id: memberId,
            utr_reference: utrInput.trim(),
          },
        });
        if (error || !data?.success) throw new Error('Failed');
      }
      setPaymentStatus('success');
    } catch {
      setPaymentStatus('failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 max-w-md mx-auto">
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-amber-100 rounded-full mb-4">
          <Smartphone className="w-8 h-8 text-amber-600" />
        </div>
        <h3 className="text-2xl font-bold text-slate-800 mb-2">Pay via GPay / UPI</h3>
        <p className="text-slate-600">Scan the QR code to pay membership fee</p>
      </div>

      <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg p-6 mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-slate-600">Membership Type</span>
          <span className="font-semibold text-slate-800">Regular</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-slate-600">Amount</span>
          <span className="text-3xl font-bold text-amber-600">₹{amount}</span>
        </div>
      </div>

      {paymentStatus === 'idle' && (
        <>
          <div className="flex flex-col items-center mb-6">
            <div className="bg-white border-2 border-slate-200 rounded-xl p-4 shadow-sm">
              <QRCodeSVG
                value={upiUrl}
                size={200}
                level="H"
                includeMargin
                bgColor="#ffffff"
                fgColor="#1e293b"
              />
            </div>
            <p className="text-sm text-slate-500 mt-3 text-center">
              Open <span className="font-semibold text-green-600">GPay</span>, <span className="font-semibold text-purple-600">PhonePe</span>, or any UPI app and scan
            </p>
            <p className="text-xs text-slate-400 mt-1">UPI ID: {upiId}</p>
          </div>

          <div className="space-y-3">
            <label className="block text-sm font-medium text-slate-700">
              After payment, enter your UTR / Transaction Reference
            </label>
            <input
              type="text"
              value={utrInput}
              onChange={(e) => setUtrInput(e.target.value)}
              placeholder="e.g. 412345678901"
              className="w-full border border-slate-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
            />
            <button
              onClick={handleConfirmPayment}
              disabled={!utrInput.trim() || submitting}
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]"
            >
              {submitting ? 'Submitting...' : 'Confirm Payment'}
            </button>
            <p className="text-xs text-slate-500 text-center">
              Payment is optional — you can submit without it
            </p>
          </div>
        </>
      )}

      {paymentStatus === 'success' && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start">
          <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 mr-3 flex-shrink-0" />
          <div>
            <p className="font-semibold text-green-800">Payment Reference Submitted!</p>
            <p className="text-sm text-green-700 mt-1">Your payment will be verified by the admin.</p>
          </div>
        </div>
      )}

      {paymentStatus === 'failed' && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start">
          <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 mr-3 flex-shrink-0" />
          <div>
            <p className="font-semibold text-red-800">Submission Failed</p>
            <p className="text-sm text-red-700 mt-1">Please try again or contact support.</p>
          </div>
        </div>
      )}

      <div className="mt-6 pt-6 border-t border-slate-200">
        <p className="text-sm text-slate-600 text-center mb-3">Accepted via</p>
        <div className="flex justify-center space-x-3">
          <div className="bg-slate-100 px-4 py-2 rounded text-xs font-semibold text-slate-700">GPay</div>
          <div className="bg-slate-100 px-4 py-2 rounded text-xs font-semibold text-slate-700">PhonePe</div>
          <div className="bg-slate-100 px-4 py-2 rounded text-xs font-semibold text-slate-700">Paytm</div>
          <div className="bg-slate-100 px-4 py-2 rounded text-xs font-semibold text-slate-700">UPI</div>
        </div>
      </div>
    </div>
  );
}
