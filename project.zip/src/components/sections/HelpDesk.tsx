import { useState, useEffect } from 'react';
import { MessageSquare, Send, Search, Eye, Clock, Upload, X, LogIn, User, ArrowLeft, FileText } from 'lucide-react';
import { supabase, type HelpdeskPost, type HelpdeskReply } from '../../lib/supabase';
import MemberLogin, { type LoggedInMember } from '../MemberLogin';

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== 'string') { reject(new Error('Failed to read file')); return; }
      const [, base64] = reader.result.split(',');
      if (!base64) { reject(new Error('Failed to encode file')); return; }
      resolve(base64);
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

// Extract a useful error message from a supabase.functions.invoke error/data pair.
// Edge functions returning non-2xx put the body in error.context.response (a Response).
async function extractFnError(fnError: any, data: any): Promise<string | null> {
  if (data?.error) return data.error;
  try {
    const resp: Response | undefined = fnError?.context?.response;
    if (resp) {
      const text = await resp.clone().text();
      try {
        const parsed = JSON.parse(text);
        if (parsed?.error) return parsed.error;
      } catch {
        if (text) return text;
      }
    }
  } catch {}
  return fnError?.message || null;
}

interface HelpDeskProps {
  onNavigate?: (section: string) => void;
}

export default function HelpDesk({ onNavigate }: HelpDeskProps) {
  const [posts, setPosts] = useState<HelpdeskPost[]>([]);
  const [selectedPost, setSelectedPost] = useState<HelpdeskPost | null>(null);
  const [replies, setReplies] = useState<HelpdeskReply[]>([]);
  const [showNewPost, setShowNewPost] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [loggedInMember, setLoggedInMember] = useState<LoggedInMember | null>(null);
  const [profileComplete, setProfileComplete] = useState<boolean | null>(null);
  const [missingFields, setMissingFields] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [newPost, setNewPost] = useState({ topic: '', title: '', content: '' });
  const [newReply, setNewReply] = useState('');
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    fetchPosts();
    // Check if member is already logged in from session
    const saved = sessionStorage.getItem('loggedInMember');
    if (saved) {
      try { setLoggedInMember(JSON.parse(saved)); } catch {}
    }
  }, []);

  useEffect(() => {
    if (loggedInMember) {
      checkProfileCompleteness(loggedInMember.id);
    } else {
      setProfileComplete(null);
      setMissingFields([]);
    }
  }, [loggedInMember]);

  const checkProfileCompleteness = async (memberId: string) => {
    const { data } = await supabase
      .from('members')
      .select('joined_date, college_type, college_name, designation, district, service_joining_date')
      .eq('id', memberId)
      .maybeSingle();
    if (!data) { setProfileComplete(false); return; }
    const required: { key: keyof typeof data; label: string }[] = [
      { key: 'joined_date', label: 'Date of Joining UVAS' },
      { key: 'college_type', label: 'College Type (Govt/Aided/Self-Financing)' },
      { key: 'college_name', label: 'College Name' },
      { key: 'designation', label: 'Designation' },
      { key: 'district', label: 'District' },
      { key: 'service_joining_date', label: 'Date of Joining Service' },
    ];
    const missing = required.filter(f => !data[f.key]).map(f => f.label);
    setMissingFields(missing);
    setProfileComplete(missing.length === 0);
  };

  useEffect(() => {
    if (selectedPost) {
      fetchReplies(selectedPost.id);
      incrementViews(selectedPost.id);
    }
  }, [selectedPost]);

  const fetchPosts = async () => {
    // Only show approved posts (status != 'pending') to public
    const { data } = await supabase
      .from('helpdesk_posts')
      .select('*, members(full_name, college_name)')
      .neq('status', 'pending')
      .order('created_at', { ascending: false });
    setPosts(data || []);
  };

  const fetchReplies = async (postId: string) => {
    const { data } = await supabase
      .from('helpdesk_replies')
      .select('*, members(full_name, college_name)')
      .eq('post_id', postId)
      .order('created_at', { ascending: true });
    setReplies(data || []);
  };

  const incrementViews = async (postId: string) => {
    const post = posts.find(p => p.id === postId);
    if (post) {
      await supabase.functions.invoke('member-helpdesk', {
        body: { action: 'increment_views', post_id: postId, current_views: post.views },
      });
    }
  };

  const [pendingNewPost, setPendingNewPost] = useState(false);

  const handleMemberLogin = (member: LoggedInMember) => {
    setLoggedInMember(member);
    sessionStorage.setItem('loggedInMember', JSON.stringify(member));
    setShowLogin(false);
    // Only show new post form if they clicked "New Query" before login
    if (pendingNewPost) {
      setShowNewPost(true);
      setPendingNewPost(false);
    }
  };

  const handleLogout = () => {
    setLoggedInMember(null);
    sessionStorage.removeItem('loggedInMember');
  };

  const handleNewQueryClick = () => {
    if (!loggedInMember) {
      setPendingNewPost(true);
      setShowLogin(true);
      return;
    }
    if (profileComplete !== true) {
      // Profile incomplete (or check still pending) — banner directs them to complete it.
      return;
    }
    setShowNewPost(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const validTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      const maxSize = 5 * 1024 * 1024;
      if (!validTypes.includes(file.type)) {
        setError('Invalid file type. Please upload PDF, JPEG, or DOCX files only.');
        return;
      }
      if (file.size > maxSize) {
        setError('File size exceeds 5 MB limit.');
        return;
      }
      setAttachedFile(file);
      setError('');
    }
  };

  const removeFile = () => setAttachedFile(null);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loggedInMember) {
      setShowLogin(true);
      return;
    }
    // Re-check profile completeness right before submitting (defense in depth)
    const { data: profile } = await supabase
      .from('members')
      .select('joined_date, college_type, college_name, designation, district, service_joining_date')
      .eq('id', loggedInMember.id)
      .maybeSingle();
    const stillMissing = !profile || !profile.joined_date || !profile.college_type || !profile.college_name || !profile.designation || !profile.district || !profile.service_joining_date;
    if (stillMissing) {
      setError('Please complete your member profile before posting a query.');
      setShowNewPost(false);
      checkProfileCompleteness(loggedInMember.id);
      return;
    }

    setLoading(true);
    setError('');
    setSuccess(false);

    try {
      let documentUrl: string | undefined;

      // Upload attached file first
      if (attachedFile) {
        const fileBase64 = await fileToBase64(attachedFile);
        const { data: uploadData, error: uploadError } = await supabase.functions.invoke('member-helpdesk', {
          body: {
            action: 'upload_document',
            token: loggedInMember.token,
            file_name: attachedFile.name,
            file_base64: fileBase64,
            content_type: attachedFile.type || 'application/octet-stream',
          },
        });
        if (uploadError || !uploadData?.success) {
          const msg = await extractFnError(uploadError, uploadData);
          throw new Error(msg || 'Failed to upload document');
        }
        documentUrl = uploadData.publicUrl;
      }

      const { data, error: fnError } = await supabase.functions.invoke('member-helpdesk', {
        body: {
          action: 'create_post',
          token: loggedInMember.token,
          topic: newPost.topic,
          title: newPost.title,
          content: newPost.content,
          document_url: documentUrl,
        },
      });

      if (fnError || !data?.success) {
        const msg = await extractFnError(fnError, data);
        throw new Error(msg || 'Failed to post query');
      }

      setSuccess(true);
      setNewPost({ topic: '', title: '', content: '' });
      setAttachedFile(null);

      setTimeout(() => {
        setShowNewPost(false);
        setSuccess(false);
        fetchPosts();
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to post query');
    } finally {
      setLoading(false);
    }
  };

  const handleReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPost || !newReply.trim()) return;
    if (!loggedInMember) {
      setShowLogin(true);
      return;
    }
    if (profileComplete !== true) {
      checkProfileCompleteness(loggedInMember.id);
      return;
    }

    const { data, error } = await supabase.functions.invoke('member-helpdesk', {
      body: {
        action: 'create_reply',
        token: loggedInMember.token,
        post_id: selectedPost.id,
        content: newReply,
      },
    });

    if (!error && data?.success) {
      setNewReply('');
      fetchReplies(selectedPost.id);
    }
  };

  const filteredPosts = posts.filter(post =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.topic.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-blue-100 text-blue-800';
      case 'answered': return 'bg-green-100 text-green-800';
      case 'closed': return 'bg-slate-100 text-slate-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-amber-50 py-12 px-4">
      {showLogin && (
        <MemberLogin
          onLogin={handleMemberLogin}
          onClose={() => setShowLogin(false)}
        />
      )}

      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-gradient-to-r from-amber-600 to-orange-600 px-8 py-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold text-white">Service Help Desk</h2>
                <p className="text-amber-50 mt-2">Get help with service-related queries</p>
              </div>
              <div className="flex items-center gap-3">
                {loggedInMember && onNavigate && (
                  <button
                    onClick={() => onNavigate('member-login')}
                    className="bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-white/30 transition-all flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back to Profile
                  </button>
                )}
                <button
                  onClick={handleNewQueryClick}
                  disabled={!!loggedInMember && profileComplete !== true}
                  className="bg-white text-amber-600 px-6 py-2 rounded-lg font-semibold hover:bg-amber-50 transition-all shadow-lg flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  title={loggedInMember && profileComplete !== true ? 'Complete your profile to continue' : ''}
                >
                  {!loggedInMember && <LogIn className="w-4 h-4" />}
                  New Query
                </button>
                {loggedInMember && (
                  <>
                    <div className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-lg text-white text-sm">
                      <User className="w-4 h-4 inline mr-1" />
                      {loggedInMember.full_name}
                    </div>
                    <button
                      onClick={handleLogout}
                      className="text-white/80 hover:text-white text-sm underline"
                    >
                      Logout
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>

          {loggedInMember && profileComplete !== true ? (
            <div className="p-10">
              <div className="max-w-2xl mx-auto bg-amber-50 border-2 border-amber-300 rounded-2xl p-8 text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-amber-100 flex items-center justify-center">
                  <User className="w-8 h-8 text-amber-700" />
                </div>
                <h3 className="text-2xl font-bold text-slate-800 mb-2">Complete your profile to continue</h3>
                <p className="text-slate-600 mb-4">
                  Before you can post a query or browse the Help Desk, please complete your member profile.
                  This helps us route your service questions to the right experts.
                </p>
                {missingFields.length > 0 && (
                  <div className="text-left bg-white border border-amber-200 rounded-lg p-4 mb-6">
                    <p className="text-sm font-semibold text-slate-700 mb-2">Missing information:</p>
                    <ul className="list-disc list-inside text-sm text-slate-600 space-y-1">
                      {missingFields.map((f) => <li key={f}>{f}</li>)}
                    </ul>
                  </div>
                )}
                {onNavigate && (
                  <button
                    onClick={() => onNavigate('member-login')}
                    className="bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold py-3 px-8 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all shadow-lg"
                  >
                    Go to My Profile
                  </button>
                )}
              </div>
            </div>
          ) : showNewPost ? (
            <div className="p-8">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-slate-800">Post a New Query</h3>
                <p className="text-slate-600 mt-1">
                  Posting as <span className="font-semibold text-amber-600">{loggedInMember?.full_name}</span>.
                  Your query will be reviewed by UVAS admin before it appears publicly.
                </p>
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
                  {error}
                </div>
              )}

              {success && (
                <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
                  Query submitted successfully! It will appear after admin approval.
                </div>
              )}

              <form onSubmit={handleCreatePost} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Topic / Category *</label>
                  <select
                    value={newPost.topic}
                    onChange={(e) => setNewPost({ ...newPost, topic: e.target.value })}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                  >
                    <option value="">Select a category</option>
                    <option value="Pay & Allowances">Pay &amp; Allowances</option>
                    <option value="Leave Rules">Leave Rules</option>
                    <option value="Promotion & Career Advancement">Promotion &amp; Career Advancement</option>
                    <option value="Pension / Retirement">Pension / Retirement</option>
                    <option value="Service Book">Service Book</option>
                    <option value="Transfer">Transfer</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Query Title *</label>
                  <input
                    type="text"
                    value={newPost.title}
                    onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    placeholder="A clear, specific question title"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Describe your issue *</label>
                  <textarea
                    value={newPost.content}
                    onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                    required
                    rows={8}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none transition-all"
                    placeholder="Provide full details of your service issue — college type, designation, years of service, and the specific problem you face."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Attach Document (optional)</label>
                  {attachedFile ? (
                    <div className="flex items-center justify-between bg-amber-50 border border-amber-200 rounded-lg p-4">
                      <div className="flex items-center space-x-3">
                        <Upload className="w-5 h-5 text-amber-600" />
                        <div>
                          <p className="text-sm font-medium text-slate-800">{attachedFile.name}</p>
                          <p className="text-xs text-slate-500">{(attachedFile.size / 1024).toFixed(2)} KB</p>
                        </div>
                      </div>
                      <button type="button" onClick={removeFile} className="text-red-600 hover:text-red-700">
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  ) : (
                    <div className="relative">
                      <input type="file" id="file-upload" accept=".pdf,.jpg,.jpeg,.docx" onChange={handleFileChange} className="hidden" />
                      <label htmlFor="file-upload" className="flex items-center justify-center w-full px-4 py-8 border-2 border-dashed border-slate-300 rounded-lg cursor-pointer hover:border-amber-500 hover:bg-amber-50 transition-all">
                        <div className="text-center">
                          <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                          <p className="text-sm text-slate-600 font-medium">Click to upload</p>
                          <p className="text-xs text-slate-500 mt-1">PDF, JPEG or DOCX — max 5 MB</p>
                        </div>
                      </label>
                    </div>
                  )}
                </div>

                <div className="flex space-x-4 pt-4 border-t border-slate-200">
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold py-4 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? 'Submitting...' : 'Submit Query'}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setShowNewPost(false); setError(''); setAttachedFile(null); }}
                    className="px-8 py-4 border-2 border-slate-300 rounded-lg text-slate-700 font-semibold hover:bg-slate-50 transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="grid lg:grid-cols-2 divide-x divide-slate-200">
              <div className="p-6">
                <div className="mb-6">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <input
                      type="text"
                      placeholder="Search queries..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="space-y-4 max-h-[600px] overflow-y-auto">
                  {filteredPosts.length === 0 && (
                    <div className="text-center py-12 text-slate-400">
                      <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No approved queries yet</p>
                    </div>
                  )}
                  {filteredPosts.map((post) => (
                    <div
                      key={post.id}
                      onClick={() => setSelectedPost(post)}
                      className={`p-4 border rounded-lg cursor-pointer transition-all hover:shadow-md ${
                        selectedPost?.id === post.id ? 'border-amber-500 bg-amber-50' : 'border-slate-200 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                         <h3 className="font-semibold text-slate-800 mb-1">{post.title}</h3>
                          <span className="text-xs text-amber-600 font-medium">{post.topic}</span>
                          {post.members && (
                            <div className="text-xs text-slate-500 mt-1">
                              <span className="font-medium text-slate-600">{post.members.full_name}</span>
                              {post.members.college_name && <span>, {post.members.college_name}</span>}
                            </div>
                          )}
                        </div>
                        <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(post.status)}`}>
                          {post.status}
                        </span>
                      </div>
                      <p className="text-sm text-slate-600 line-clamp-2 mb-3">{post.content}</p>
                      <div className="flex items-center text-xs text-slate-500 space-x-4">
                        {(post as any).document_url && (
                          <span className="flex items-center space-x-1 text-amber-600">
                            <FileText className="w-3 h-3" />
                            <span>Document</span>
                          </span>
                        )}
                        <span className="flex items-center space-x-1">
                          <Eye className="w-3 h-3" />
                          <span>{post.views} views</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Clock className="w-3 h-3" />
                          <span>{new Date(post.created_at).toLocaleDateString()}</span>
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-6">
                {selectedPost ? (
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <span className="text-xs text-amber-600 font-medium">{selectedPost.topic}</span>
                          <h3 className="text-2xl font-bold text-slate-800 mt-1">{selectedPost.title}</h3>
                          {selectedPost.members && (
                            <div className="text-sm text-slate-500 mt-1">
                              Posted by <span className="font-medium text-slate-700">{selectedPost.members.full_name}</span>
                              {selectedPost.members.college_name && <span>, {selectedPost.members.college_name}</span>}
                            </div>
                          )}
                        </div>
                        <span className={`text-xs px-3 py-1 rounded-full ${getStatusColor(selectedPost.status)}`}>
                          {selectedPost.status}
                        </span>
                      </div>
                      <p className="text-slate-700 leading-relaxed">{selectedPost.content}</p>
                      {(selectedPost as any).document_url && (
                        <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                          <a
                            href={(selectedPost as any).document_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 text-amber-700 hover:text-amber-900 font-medium text-sm"
                          >
                            <FileText className="w-4 h-4" />
                            Attached Document
                          </a>
                        </div>
                      )}
                      <div className="flex items-center text-sm text-slate-500 mt-4 space-x-4">
                        <span>{new Date(selectedPost.created_at).toLocaleString()}</span>
                        <span className="flex items-center space-x-1">
                          <Eye className="w-4 h-4" />
                          <span>{selectedPost.views} views</span>
                        </span>
                      </div>
                    </div>

                    <div className="border-t border-slate-200 pt-6">
                      <h4 className="font-semibold text-slate-800 mb-4 flex items-center">
                        <MessageSquare className="w-5 h-5 mr-2 text-amber-600" />
                        Replies ({replies.length})
                      </h4>

                      <div className="space-y-4 mb-6 max-h-[300px] overflow-y-auto">
                        {replies.map((reply) => (
                          <div key={reply.id} className={`p-4 rounded-lg ${reply.is_admin ? 'bg-amber-50 border border-amber-200' : 'bg-slate-50'}`}>
                            <div className="flex items-center justify-between mb-1">
                              {reply.is_admin ? (
                                <span className="text-xs font-semibold text-amber-600">ADMIN REPLY</span>
                              ) : (
                                <span className="text-xs font-semibold text-slate-600">
                                  {(reply as any).members?.full_name || 'Member'}
                                  {(reply as any).members?.college_name && <span className="font-normal text-slate-400">, {(reply as any).members.college_name}</span>}
                                </span>
                              )}
                              <p className="text-xs text-slate-500">{new Date(reply.created_at).toLocaleString()}</p>
                            </div>
                            <p className="text-slate-700 text-sm whitespace-pre-wrap">{reply.content}</p>
                          </div>
                        ))}
                      </div>

                      <form onSubmit={handleReply} className="space-y-3">
                        <textarea
                          value={newReply}
                          onChange={(e) => setNewReply(e.target.value)}
                          placeholder={loggedInMember ? "Write a reply..." : "Login to reply..."}
                          className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
                          rows={3}
                          onClick={() => { if (!loggedInMember) setShowLogin(true); }}
                          readOnly={!loggedInMember}
                        />
                        <div className="flex justify-end">
                          <button
                            type="submit"
                            disabled={!loggedInMember || !newReply.trim()}
                            className="bg-gradient-to-r from-amber-600 to-orange-600 text-white px-6 py-2 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all flex items-center space-x-2 disabled:opacity-50"
                          >
                            <Send className="w-4 h-4" />
                            <span>Send Reply</span>
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-slate-400">
                    <div className="text-center">
                      <MessageSquare className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p>Select a query to view details and replies</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
