import { useState, useEffect } from 'react';
import { CreditCard, User, Mail, Phone, MapPin, Building2, Briefcase, Lock, Calendar, QrCode, CheckCircle, Shield, AlertCircle } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { supabase, type SiteSetting } from '../../lib/supabase';

type FormMode = 'select' | 'new' | 'renew' | 'renew-verified';

interface MemberData {
  id: string;
  full_name: string;
  mobile: string;
  email: string;
  employee_id: string;
  college_name: string;
  designation: string;
  membership_category: string;
  status: string;
  renewal_date: string;
  joined_date: string;
}

export default function MembershipForm() {
  const [mode, setMode] = useState<FormMode>('select');
  const [formData, setFormData] = useState({
    full_name: '',
    date_of_birth: '',
    mobile: '',
    email: '',
    religion: '',
    password: '',
    confirm_password: '',
    house_address: '',
    designation: '',
    employee_id: '',
    college_type: '',
    district: '',
    university: '',
    college_name: '',
    college_address: '',
    membership_category: '',
    service_joining_date: '',
    utr_reference: '',
  });
  const [renewData, setRenewData] = useState({
    member_id_or_mobile: '',
    date_of_birth: '',
  });
  const [renewalBlocked, setRenewalBlocked] = useState(false);
  const [renewalBlockMessage, setRenewalBlockMessage] = useState('');
  const [verifiedMember, setVerifiedMember] = useState<MemberData | null>(null);
  const [renewalUTR, setRenewalUTR] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [upiId, setUpiId] = useState('syam.sankar8@oksbi');
  const [fees, setFees] = useState({
    new_govt: 1000,
    new_self: 1500,
    renew_govt: 1100,
    renew_self: 500,
  });

  useEffect(() => {
    const fetchSettings = async () => {
      const { data } = await supabase.from('site_settings').select('*');
      if (data) {
        const settings: Record<string, string> = {};
        data.forEach((s: SiteSetting) => {
          settings[s.setting_key] = s.setting_value;
        });
        if (settings.payment_upi) setUpiId(settings.payment_upi);
        setFees({
          new_govt: parseInt(settings.fee_new_govt) || 1000,
          new_self: parseInt(settings.fee_new_self) || 1500,
          renew_govt: parseInt(settings.fee_renew_govt) || 600,
          renew_self: parseInt(settings.fee_renew_self) || 800,
        });
      }
    };
    fetchSettings();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const calculateYearsOfExperience = (startDate: string): string => {
    if (!startDate) return '';
    const start = new Date(startDate);
    if (isNaN(start.getTime())) return '';
    const now = new Date();
    if (start > now) return '';
    let years = now.getFullYear() - start.getFullYear();
    const m = now.getMonth() - start.getMonth();
    if (m < 0 || (m === 0 && now.getDate() < start.getDate())) years--;
    if (years < 0) return '';
    const totalMonths = (now.getFullYear() - start.getFullYear()) * 12 + (now.getMonth() - start.getMonth()) - (now.getDate() < start.getDate() ? 1 : 0);
    const months = totalMonths - years * 12;
    if (years === 0 && months === 0) return 'Less than a month';
    const parts: string[] = [];
    if (years > 0) parts.push(`${years} year${years > 1 ? 's' : ''}`);
    if (months > 0) parts.push(`${months} month${months > 1 ? 's' : ''}`);
    return parts.join(' ');
  };

  const handleRenewChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRenewData({
      ...renewData,
      [e.target.name]: e.target.value,
    });
  };

  const handleVerifyMember = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke('member-renewal', {
        body: {
          action: 'verify',
          member_id_or_mobile: renewData.member_id_or_mobile,
          date_of_birth: renewData.date_of_birth,
        },
      });

      if (fnError || !data?.success) {
        setError(data?.error || 'No member found with the provided details. Please check your Member ID/Mobile and Date of Birth.');
        setLoading(false);
        return;
      }

      const member = data.member as MemberData;
      
      // Determine the reference date: renewal_date if exists, otherwise joined_date
      const referenceDate = member.renewal_date ? new Date(member.renewal_date) : (member.joined_date ? new Date(member.joined_date) : null);
      
      if (referenceDate) {
        const now = new Date();
        const oneYearAfter = new Date(referenceDate);
        oneYearAfter.setFullYear(oneYearAfter.getFullYear() + 1);
        
        if (now < oneYearAfter) {
          const remainingDays = Math.ceil((oneYearAfter.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          const validUntil = oneYearAfter.toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' });
          setRenewalBlocked(true);
          setRenewalBlockMessage(`Your membership is still active and valid until ${validUntil}. Renewal will be available after this date (${remainingDays} days remaining).`);
        } else {
          setRenewalBlocked(false);
          setRenewalBlockMessage('');
        }
      } else {
        setRenewalBlocked(false);
        setRenewalBlockMessage('');
      }
      
      setVerifiedMember(member);
      setMode('renew-verified');
    } catch (err: any) {
      setError(err.message || 'Failed to verify member details');
    } finally {
      setLoading(false);
    }
  };

  const getRenewalAmount = (category: string | null | undefined) => {
    return category === 'govt-aided' ? fees.renew_govt : fees.renew_self;
  };

  const getNewAmount = (category: string) => {
    return category === 'govt-aided' ? fees.new_govt : fees.new_self;
  };

  const handleRenewalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess(false);

    if (!verifiedMember) {
      setError('Member verification required');
      setLoading(false);
      return;
    }

    try {
      const { data, error: fnError } = await supabase.functions.invoke('member-renewal', {
        body: {
          action: 'renew',
          member_id: verifiedMember.id,
          renewal_utr: renewalUTR || null,
        },
      });

      if (fnError || !data?.success) {
        throw new Error(data?.error || 'Failed to process renewal');
      }

      setSuccess(true);
      setRenewalUTR('');
    } catch (err: any) {
      setError(err.message || 'Failed to process renewal');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess(false);

    if (formData.password !== formData.confirm_password) {
      setError('Passwords do not match');
      setLoading(false);
      return;
    }

    try {
      const { data, error: fnError } = await supabase.functions.invoke('member-register', {
        body: {
          full_name: formData.full_name,
          date_of_birth: formData.date_of_birth,
          mobile: formData.mobile,
          email: formData.email,
          religion: formData.religion,
          password: formData.password,
          house_address: formData.house_address,
          designation: formData.designation,
          employee_id: formData.employee_id,
          college_type: formData.college_type,
          district: formData.district,
          university: formData.university,
          college_name: formData.college_name,
          college_address: formData.college_address,
          membership_category: formData.membership_category,
          service_joining_date: formData.service_joining_date,
          utr_reference: formData.utr_reference,
        },
      });

      if (fnError || !data?.success) {
        throw new Error(data?.error || 'Failed to submit application');
      }

      setSuccess(true);
      setFormData({
        full_name: '',
        date_of_birth: '',
        mobile: '',
        email: '',
        religion: '',
        password: '',
        confirm_password: '',
        house_address: '',
        designation: '',
        employee_id: '',
        college_type: '',
        district: '',
        university: '',
        college_name: '',
        college_address: '',
        membership_category: '',
        service_joining_date: '',
        utr_reference: '',
      });

      setTimeout(() => {
        setMode('select');
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to submit application');
    } finally {
      setLoading(false);
    }
  };

  if (mode === 'select') {
    return (
      <div className="min-h-[60vh] flex items-center justify-center py-12 px-4">
        <div className="max-w-4xl w-full">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-800 mb-3">New Member & Renewal</h2>
            <p className="text-slate-600">Register as a new member or renew your existing membership</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <button
              onClick={() => setMode('new')}
              className="group bg-white p-8 rounded-2xl shadow-lg border-2 border-slate-200 hover:border-amber-500 hover:shadow-xl transition-all duration-300"
            >
              <div className="flex flex-col items-center space-y-4">
                <div className="w-20 h-20 bg-gradient-to-br from-amber-100 to-orange-100 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <User className="w-10 h-10 text-amber-600" />
                </div>
                <h3 className="text-2xl font-bold text-slate-800">New Member</h3>
                <p className="text-slate-600 text-center">Apply for new UVAS membership</p>
                <div className="mt-4 text-amber-600 font-semibold group-hover:translate-x-2 transition-transform">
                  Get Started →
                </div>
              </div>
            </button>

            <button
              onClick={() => setMode('renew')}
              className="group bg-white p-8 rounded-2xl shadow-lg border-2 border-slate-200 hover:border-amber-500 hover:shadow-xl transition-all duration-300"
            >
              <div className="flex flex-col items-center space-y-4">
                <div className="w-20 h-20 bg-gradient-to-br from-amber-100 to-orange-100 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <CreditCard className="w-10 h-10 text-amber-600" />
                </div>
                <h3 className="text-2xl font-bold text-slate-800">Renew Membership</h3>
                <p className="text-slate-600 text-center">Renew your existing membership</p>
                <div className="mt-4 text-amber-600 font-semibold group-hover:translate-x-2 transition-transform">
                  Renew Now →
                </div>
              </div>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (mode === 'renew') {
    return (
      <div className="min-h-[60vh] flex items-center justify-center py-12 px-4">
        <div className="max-w-2xl w-full">
          <button
            onClick={() => setMode('select')}
            className="mb-6 text-amber-600 hover:text-amber-700 font-medium flex items-center gap-2"
          >
            ← Back to Selection
          </button>

          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-amber-600 to-orange-600 px-8 py-6">
              <div className="flex items-center gap-3">
                <Shield className="w-8 h-8 text-white" />
                <div>
                  <h2 className="text-3xl font-bold text-white">Renew Your Membership</h2>
                  <p className="text-amber-50 mt-1">Enter your Member ID or registered mobile number to renew.</p>
                </div>
              </div>
            </div>

            <form onSubmit={handleVerifyMember} className="p-8 space-y-6">
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                  {error}
                </div>
              )}

              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-4 pb-2 border-b-2 border-amber-200">Verify Your Identity</h3>

                <div className="space-y-4">
                  <div>
                    <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                      <User className="w-4 h-4 mr-2 text-amber-600" />
                      Member ID / Mobile Number *
                    </label>
                    <input
                      type="text"
                      name="member_id_or_mobile"
                      value={renewData.member_id_or_mobile}
                      onChange={handleRenewChange}
                      required
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                      placeholder="e.g. UVAS2612345 or 98xxxxxxxx"
                    />
                    <p className="text-xs text-slate-500 mt-1">Enter your Employee ID or 10-digit mobile number</p>
                  </div>

                  <div>
                    <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                      <Calendar className="w-4 h-4 mr-2 text-amber-600" />
                      Date of Birth *
                    </label>
                    <input
                      type="date"
                      name="date_of_birth"
                      value={renewData.date_of_birth}
                      onChange={handleRenewChange}
                      required
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold text-lg py-4 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Verifying...' : 'Verify & Fetch Details'}
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  if (mode === 'renew-verified' && verifiedMember) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-amber-50 py-8 px-4">
        <div className="max-w-3xl mx-auto">
          <button
            onClick={() => {
              setMode('renew');
              setVerifiedMember(null);
              setError('');
            }}
            className="mb-6 text-amber-600 hover:text-amber-700 font-medium flex items-center gap-2"
          >
            ← Back to Verification
          </button>

          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-green-600 to-emerald-600 px-8 py-6">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-8 h-8 text-white" />
                <div>
                  <h2 className="text-3xl font-bold text-white">Identity Verified</h2>
                  <p className="text-green-50 mt-1">Complete payment to renew your membership</p>
                </div>
              </div>
            </div>

            <div className="p-8 space-y-8">
              {error && !success && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                  {error}
                </div>
              )}

              <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border-2 border-amber-200">
                <h3 className="text-lg font-bold text-slate-800 mb-4">Member Details</h3>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-slate-600">Full Name</p>
                    <p className="font-semibold text-slate-800">{verifiedMember.full_name}</p>
                  </div>
                  <div>
                    <p className="text-slate-600">Employee ID</p>
                    <p className="font-semibold text-slate-800">{verifiedMember.employee_id}</p>
                  </div>
                  <div>
                    <p className="text-slate-600">Mobile</p>
                    <p className="font-semibold text-slate-800">{verifiedMember.mobile}</p>
                  </div>
                  <div>
                    <p className="text-slate-600">Designation</p>
                    <p className="font-semibold text-slate-800">{verifiedMember.designation}</p>
                  </div>
                  <div>
                    <p className="text-slate-600">Joining Date</p>
                    <p className="font-semibold text-slate-800">
                      {verifiedMember.joined_date
                        ? new Date(verifiedMember.joined_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })
                        : '—'}
                    </p>
                  </div>
                  {verifiedMember.renewal_date && (
                    <div>
                      <p className="text-slate-600">Last Renewal Date</p>
                      <p className="font-semibold text-slate-800">
                        {new Date(verifiedMember.renewal_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })}
                      </p>
                    </div>
                  )}
                  <div className="md:col-span-2">
                    <p className="text-slate-600">College</p>
                    <p className="font-semibold text-slate-800">{verifiedMember.college_name}</p>
                  </div>
                </div>
              </div>

              {renewalBlocked ? (
                <div className="bg-orange-50 border-2 border-orange-300 rounded-xl p-6 text-center">
                  <AlertCircle className="w-12 h-12 text-orange-500 mx-auto mb-3" />
                  <h3 className="text-xl font-bold text-orange-800 mb-2">Renewal Not Available Yet</h3>
                  <p className="text-orange-700">{renewalBlockMessage}</p>
                  <button
                    onClick={() => {
                      setMode('select');
                      setVerifiedMember(null);
                      setRenewalBlocked(false);
                      setRenewalBlockMessage('');
                      setRenewData({ member_id_or_mobile: '', date_of_birth: '' });
                    }}
                    className="mt-6 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-8 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all"
                  >
                    Back to Home
                  </button>
                </div>
              ) : success ? (
                <div className="text-center py-12">
                  <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
                    <CheckCircle className="w-10 h-10 text-green-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-green-800 mb-3">Your Membership is Renewed!</h3>
                  <p className="text-slate-600 mb-2">Thank you, <span className="font-semibold">{verifiedMember.full_name}</span>.</p>
                  <p className="text-slate-500 text-sm mb-6">Your membership has been successfully renewed. The admin will verify your payment shortly.</p>
                  <button
                    onClick={() => {
                      setMode('select');
                      setVerifiedMember(null);
                      setRenewData({ member_id_or_mobile: '', date_of_birth: '' });
                      setSuccess(false);
                    }}
                    className="bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-8 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all"
                  >
                    Back to Home
                  </button>
                </div>
              ) : (
                <>
              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-4 pb-2 border-b-2 border-amber-200">Renewal Fee</h3>
                <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border-2 border-amber-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-600">Membership Category</p>
                      <p className="font-bold text-slate-800 capitalize">{verifiedMember.membership_category?.replace('-', ' / ')}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-3xl text-amber-600">
                        ₹{getRenewalAmount(verifiedMember.membership_category).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <form onSubmit={handleRenewalSubmit}>
                <div>
                  <h3 className="text-xl font-bold text-slate-800 mb-4 pb-2 border-b-2 border-amber-200">Payment via Google Pay / UPI</h3>

                  <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border-2 border-amber-200 mb-6">
                    <div className="flex items-center justify-between">
                      <div>
                    <p className="font-bold text-slate-800 text-lg mb-2">Pay to UVAS Kerala Wing</p>
                    <p className="text-amber-700 font-mono text-lg">{upiId}</p>
                    <p className="text-sm text-slate-600 mt-2">Scan QR code or use UPI ID to make payment</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-md">
                    <QRCodeSVG
                      value={`upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent('UVAS Membership')}&am=${getRenewalAmount(verifiedMember.membership_category)}&cu=INR&tn=${encodeURIComponent('UVAS Membership Renewal')}`}
                          size={96}
                          level="H"
                          bgColor="#ffffff"
                          fgColor="#1e293b"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                      UPI Transaction Reference (UTR)
                    </label>
                    <input
                      type="text"
                      value={renewalUTR}
                      onChange={(e) => setRenewalUTR(e.target.value)}
                      pattern={renewalUTR ? "[0-9]{12}" : undefined}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                      placeholder="12-digit UTR / Transaction ID (optional)"
                    />
                    <p className="text-xs text-slate-500 mt-1">You can enter UTR later after making the payment</p>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-200 mt-6">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold text-lg py-4 px-6 rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? 'Processing...' : 'Complete Renewal'}
                  </button>
                </div>
              </form>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-amber-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => setMode('select')}
          className="mb-6 text-amber-600 hover:text-amber-700 font-medium flex items-center gap-2"
        >
          ← Back to Selection
        </button>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-gradient-to-r from-amber-600 to-orange-600 px-8 py-6">
            <h2 className="text-3xl font-bold text-white">New Membership Application</h2>
            <p className="text-amber-50 mt-2">Fill in your details and complete payment via Google Pay / UPI to submit.</p>
          </div>

          <form onSubmit={handleSubmit} className="p-8 space-y-8">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            {success && (
              <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">
                Application submitted successfully! Redirecting...
              </div>
            )}

            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-4 pb-2 border-b-2 border-amber-200">Personal Information</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <User className="w-4 h-4 mr-2 text-amber-600" />
                    Full Name *
                  </label>
                  <input
                    type="text"
                    name="full_name"
                    value={formData.full_name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    placeholder="Dr. / Prof. Full Name"
                  />
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Calendar className="w-4 h-4 mr-2 text-amber-600" />
                    Date of Birth *
                  </label>
                  <input
                    type="date"
                    name="date_of_birth"
                    value={formData.date_of_birth}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                  />
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Phone className="w-4 h-4 mr-2 text-amber-600" />
                    Mobile Number *
                  </label>
                  <input
                    type="tel"
                    name="mobile"
                    value={formData.mobile}
                    onChange={handleChange}
                    required
                    pattern="[0-9]{10}"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    placeholder="10 digit mobile number"
                  />
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Mail className="w-4 h-4 mr-2 text-amber-600" />
                    Email Address
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    placeholder="name@college.edu"
                  />
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    Religion *
                  </label>
                  <select
                    name="religion"
                    value={formData.religion}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                  >
                    <option value="">- - Select Religion - -</option>
                    <option value="Hindu">Hindu</option>
                    <option value="Muslim">Muslim</option>
                    <option value="Christian">Christian</option>
                    <option value="Sikh">Sikh</option>
                    <option value="Buddhist">Buddhist</option>
                    <option value="Jain">Jain</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Lock className="w-4 h-4 mr-2 text-amber-600" />
                    Set Password *
                  </label>
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                    minLength={8}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    placeholder="Minimum 8 characters"
                  />
                  <p className="text-xs text-slate-500 mt-1">Used to log in and post Help Desk queries</p>
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Lock className="w-4 h-4 mr-2 text-amber-600" />
                    Confirm Password *
                  </label>
                  <input
                    type="password"
                    name="confirm_password"
                    value={formData.confirm_password}
                    onChange={handleChange}
                    required
                    minLength={8}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    placeholder="Re-enter your password"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <MapPin className="w-4 h-4 mr-2 text-amber-600" />
                    House / Residential Address *
                  </label>
                  <textarea
                    name="house_address"
                    value={formData.house_address}
                    onChange={handleChange}
                    required
                    rows={3}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all resize-none"
                    placeholder="House name / number, street, locality, pin code"
                  />
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-4 pb-2 border-b-2 border-amber-200">Professional Details</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Briefcase className="w-4 h-4 mr-2 text-amber-600" />
                    Designation *
                  </label>
                  <select
                    name="designation"
                    value={formData.designation}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                  >
                    <option value="">Select designation</option>
                    <option value="Professor">Professor</option>
                    <option value="Associate Professor">Associate Professor</option>
                    <option value="Assistant Professor">Assistant Professor</option>
                    <option value="Lecturer">Lecturer</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    Employee ID *
                  </label>
                  <input
                    type="text"
                    name="employee_id"
                    value={formData.employee_id}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    placeholder="College / University Employee ID"
                  />
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Calendar className="w-4 h-4 mr-2 text-amber-600" />
                    Date of Joining Service *
                  </label>
                  <input
                    type="date"
                    name="service_joining_date"
                    value={formData.service_joining_date}
                    onChange={handleChange}
                    required
                    max={new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                  />
                  {formData.service_joining_date && (
                    <p className="text-xs text-amber-700 mt-1 font-medium">
                      Years of Experience: <span className="font-bold">{calculateYearsOfExperience(formData.service_joining_date) || '—'}</span>
                    </p>
                  )}
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    Type of College *
                  </label>
                  <select
                    name="college_type"
                    value={formData.college_type}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                  >
                    <option value="">Select type</option>
                    <option value="Government">Government</option>
                    <option value="Aided">Aided</option>
                    <option value="Self-Financing">Self-Financing</option>
                  </select>
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    District *
                  </label>
                  <select
                    name="district"
                    value={formData.district}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                  >
                    <option value="">Select district</option>
                    <option value="Thiruvananthapuram">Thiruvananthapuram</option>
                    <option value="Kollam">Kollam</option>
                    <option value="Pathanamthitta">Pathanamthitta</option>
                    <option value="Alappuzha">Alappuzha</option>
                    <option value="Kottayam">Kottayam</option>
                    <option value="Idukki">Idukki</option>
                    <option value="Ernakulam">Ernakulam</option>
                    <option value="Thrissur">Thrissur</option>
                    <option value="Palakkad">Palakkad</option>
                    <option value="Malappuram">Malappuram</option>
                    <option value="Kozhikode">Kozhikode</option>
                    <option value="Wayanad">Wayanad</option>
                    <option value="Kannur">Kannur</option>
                    <option value="Kasaragod">Kasaragod</option>
                  </select>
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    University *
                  </label>
                  <select
                    name="university"
                    value={formData.university}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                  >
                    <option value="">Select your University</option>
                    <option value="Kerala University">Kerala University</option>
                    <option value="Mahatma Gandhi University">Mahatma Gandhi University</option>
                    <option value="Calicut University">Calicut University</option>
                    <option value="Kannur University">Kannur University</option>
                    <option value="APJ Abdul Kalam Technological University">APJ Abdul Kalam Technological University</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Building2 className="w-4 h-4 mr-2 text-amber-600" />
                    College Name *
                  </label>
                  <input
                    type="text"
                    name="college_name"
                    value={formData.college_name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    placeholder="Full name of your college / university"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    College Address *
                  </label>
                  <textarea
                    name="college_address"
                    value={formData.college_address}
                    onChange={handleChange}
                    required
                    rows={2}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all resize-none"
                    placeholder="College address with pin code"
                  />
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-4 pb-2 border-b-2 border-amber-200">Membership Category</h3>
              <p className="text-slate-600 mb-4">Select the appropriate membership category</p>

              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <label className={`border-2 rounded-xl p-6 cursor-pointer transition-all ${
                  formData.membership_category === 'govt-aided'
                    ? 'border-amber-500 bg-amber-50'
                    : 'border-slate-200 hover:border-amber-300'
                }`}>
                  <input
                    type="radio"
                    name="membership_category"
                    value="govt-aided"
                    checked={formData.membership_category === 'govt-aided'}
                    onChange={handleChange}
                    required
                    className="mr-3"
                  />
                  <span className="font-bold text-2xl text-amber-600">₹{fees.new_govt.toLocaleString()}</span>
                  <p className="text-slate-700 font-medium mt-2">Govt / Aided College</p>
                </label>

                <label className={`border-2 rounded-xl p-6 cursor-pointer transition-all ${
                  formData.membership_category === 'self-financing'
                    ? 'border-amber-500 bg-amber-50'
                    : 'border-slate-200 hover:border-amber-300'
                }`}>
                  <input
                    type="radio"
                    name="membership_category"
                    value="self-financing"
                    checked={formData.membership_category === 'self-financing'}
                    onChange={handleChange}
                    required
                    className="mr-3"
                  />
                  <span className="font-bold text-2xl text-amber-600">₹{fees.new_self.toLocaleString()}</span>
                  <p className="text-slate-700 font-medium mt-2">Self Financing College</p>
                </label>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-4 pb-2 border-b-2 border-amber-200">Payment via Google Pay / UPI <span className="text-sm font-normal text-slate-500">(Optional — can be done later)</span></h3>

              <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border-2 border-amber-200 mb-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-bold text-slate-800 text-lg mb-2">Pay to UVAS Kerala Wing</p>
                    <p className="text-amber-700 font-mono text-lg">{upiId}</p>
                    <p className="text-sm text-slate-600 mt-2">Scan QR code or use UPI ID to make payment</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-md">
                    <QRCodeSVG
                      value={`upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent('UVAS Membership')}&am=${getNewAmount(formData.membership_category)}&cu=INR&tn=${encodeURIComponent('UVAS Membership Fee')}`}
                      size={96}
                      level="H"
                      bgColor="#ffffff"
                      fgColor="#1e293b"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                  UPI Transaction Reference (UTR)
                </label>
                <input
                  type="text"
                  name="utr_reference"
                  value={formData.utr_reference}
                  onChange={handleChange}
                  pattern={formData.utr_reference ? "[0-9]{12}" : undefined}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                  placeholder="12-digit UTR / Transaction ID (optional — submit later)"
                />
                <p className="text-xs text-slate-500 mt-1">You can submit your application now and provide UTR later</p>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-200">
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold text-lg py-4 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Submitting...' : 'Submit Application'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
