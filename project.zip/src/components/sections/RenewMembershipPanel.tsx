import { useEffect, useState } from 'react';
import { CheckCircle, AlertCircle, RefreshCw, X, UserCog } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { supabase, type SiteSetting } from '../../lib/supabase';
import type { LoggedInMember } from '../MemberLogin';

interface MemberRenewInfo {
  id: string;
  full_name: string;
  email: string | null;
  mobile: string;
  date_of_birth: string | null;
  membership_category: string | null;
  joined_date: string | null;
  renewal_date: string | null;
  college_name: string | null;
  college_address: string | null;
  college_type: string | null;
  university: string | null;
  district: string | null;
  designation: string | null;
  employee_id: string | null;
  house_address: string | null;
  religion: string | null;
}

interface Props {
  member: LoggedInMember;
  onClose: () => void;
  onSuccess?: () => void;
}

// Mirrors the mandatory fields in MembershipForm (new-member registration).
// Note: membership_category is auto-derived from college_type, so it isn't asked separately.
const REQUIRED_FIELDS: { key: keyof MemberRenewInfo; label: string }[] = [
  { key: 'full_name', label: 'Full Name' },
  { key: 'date_of_birth', label: 'Date of Birth' },
  { key: 'mobile', label: 'Mobile Number' },
  { key: 'religion', label: 'Religion' },
  { key: 'house_address', label: 'House / Residential Address' },
  { key: 'designation', label: 'Designation' },
  { key: 'employee_id', label: 'Employee ID' },
  { key: 'college_type', label: 'Type of College (decides fee)' },
  { key: 'district', label: 'District' },
  { key: 'university', label: 'University' },
  { key: 'college_name', label: 'College Name' },
  { key: 'college_address', label: 'College Address' },
  { key: 'joined_date', label: 'Joining Date' },
];

export default function RenewMembershipPanel({ member, onClose, onSuccess }: Props) {
  const [info, setInfo] = useState<MemberRenewInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [renewalUTR, setRenewalUTR] = useState('');
  const [upiId, setUpiId] = useState('syam.sankar8@oksbi');
  const [fees, setFees] = useState({ renew_govt: 600, renew_self: 800 });

  useEffect(() => {
    void loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [member.id]);

  const loadAll = async () => {
    const [{ data: settingData }, { data: memberData }] = await Promise.all([
      supabase.from('site_settings').select('setting_key, setting_value'),
      supabase
        .from('members_public')
        .select('id, full_name, email, mobile, date_of_birth, membership_category, joined_date, renewal_date, college_name, college_address, college_type, university, district, designation, employee_id, house_address, religion')
        .eq('id', member.id)
        .maybeSingle(),
    ]);

    if (settingData) {
      const settings: Record<string, string> = {};
      (settingData as SiteSetting[]).forEach((s) => { settings[s.setting_key] = s.setting_value; });
      if (settings.payment_upi) setUpiId(settings.payment_upi);
      setFees({
        renew_govt: parseInt(settings.fee_renew_govt) || 600,
        renew_self: parseInt(settings.fee_renew_self) || 800,
      });
    }
    if (memberData) setInfo(memberData as MemberRenewInfo);
  };

  // Fee tier is derived from college_type: Government / Aided -> govt rate, Self-Financing -> self rate
  const isGovtAided = (collegeType: string | null | undefined) => {
    const t = (collegeType || '').toLowerCase();
    return t === 'government' || t === 'aided';
  };
  const getRenewalAmount = (collegeType: string | null | undefined) => {
    return isGovtAided(collegeType) ? fees.renew_govt : fees.renew_self;
  };
  const getCategoryLabel = (collegeType: string | null | undefined) => {
    if (!collegeType) return '—';
    return isGovtAided(collegeType) ? 'Govt / Aided College' : 'Self-Financing College';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!info) return;
    setLoading(true);
    setError('');
    setSuccess(false);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('member-renewal', {
        body: { action: 'renew', member_id: info.id, renewal_utr: renewalUTR || null },
      });
      if (fnError || !data?.success) throw new Error(data?.error || 'Failed to process renewal');
      setSuccess(true);
      setRenewalUTR('');
      onSuccess?.();
    } catch (err: any) {
      setError(err.message || 'Failed to process renewal');
    } finally {
      setLoading(false);
    }
  };

  if (!info) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-8 mb-8 text-center text-slate-500">
        Loading renewal details...
      </div>
    );
  }

  const amount = getRenewalAmount(info.college_type);
  const categoryLabel = getCategoryLabel(info.college_type);

  const missingFields = REQUIRED_FIELDS.filter(({ key }) => {
    const v = info[key];
    return v === null || v === undefined || (typeof v === 'string' && v.trim() === '');
  });

  const scrollToProfile = () => {
    onClose();
    setTimeout(() => {
      const el = document.querySelector('[data-member-profile]');
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-8">
      <div className="bg-gradient-to-r from-green-600 to-emerald-600 px-8 py-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <RefreshCw className="w-6 h-6 text-white" />
          <div>
            <h3 className="text-xl font-bold text-white">Renew Your Membership</h3>
            <p className="text-green-50 text-sm">Complete payment to extend your membership</p>
          </div>
        </div>
        <button onClick={onClose} className="text-white/80 hover:text-white">
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="p-8 space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-start gap-2">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {success ? (
          <div className="text-center py-8">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-4">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-green-800 mb-2">Renewal Submitted!</h3>
            <p className="text-slate-600">Thank you, <span className="font-semibold">{info.full_name}</span>. Admin will verify your payment shortly.</p>
            <button
              onClick={onClose}
              className="mt-6 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-8 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all"
            >
              Close
            </button>
          </div>
        ) : missingFields.length > 0 ? (
          <div className="bg-orange-50 border-2 border-orange-300 rounded-xl p-6">
            <div className="flex items-start gap-3 mb-4">
              <AlertCircle className="w-6 h-6 text-orange-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="text-lg font-bold text-orange-800 mb-1">Complete Your Profile First</h3>
                <p className="text-sm text-orange-700">
                  Before renewing, please fill in the missing mandatory fields below.
                  Your renewal fee is decided automatically by <strong>Type of College</strong> (Government / Aided → Govt rate, Self-Financing → Self rate).
                </p>
              </div>
            </div>
            <ul className="list-disc list-inside text-sm text-orange-800 mb-5 space-y-1 ml-2">
              {missingFields.map((f) => (
                <li key={f.key}><strong>{f.label}</strong></li>
              ))}
            </ul>
            <button
              onClick={scrollToProfile}
              className="w-full inline-flex items-center justify-center gap-2 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all shadow"
            >
              <UserCog className="w-5 h-5" />
              Go to Profile & Complete Details
            </button>
          </div>
        ) : (
          <>
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border-2 border-amber-200">
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div><p className="text-slate-600">Member</p><p className="font-semibold text-slate-800">{info.full_name}</p></div>
                <div><p className="text-slate-600">Mobile</p><p className="font-semibold text-slate-800">{info.mobile}</p></div>
                <div><p className="text-slate-600">Type of College</p><p className="font-semibold text-slate-800">{info.college_type || '—'}</p></div>
                <div><p className="text-slate-600">Last Renewal</p><p className="font-semibold text-slate-800">{info.renewal_date ? new Date(info.renewal_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' }) : '—'}</p></div>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-bold text-slate-800 mb-3 pb-2 border-b-2 border-amber-200">Renewal Fee</h4>
              <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border-2 border-amber-200 flex items-center justify-between">
                <div>
                  <p className="text-slate-600 text-sm">Amount Due</p>
                  <p className="font-bold text-slate-800">{categoryLabel}</p>
                </div>
                <p className="font-bold text-3xl text-amber-600">₹{amount.toLocaleString()}</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <h4 className="text-lg font-bold text-slate-800 mb-3 pb-2 border-b-2 border-amber-200">Pay via Google Pay / UPI</h4>
                <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border-2 border-amber-200 flex items-center justify-between gap-4">
                  <div>
                    <p className="font-bold text-slate-800 text-lg mb-2">Pay to UVAS Kerala Wing</p>
                    <p className="text-amber-700 font-mono text-base break-all">{upiId}</p>
                    <p className="text-sm text-slate-600 mt-2">Scan QR or use UPI ID</p>
                  </div>
                  <div className="bg-white p-3 rounded-lg shadow-md flex-shrink-0">
                    <QRCodeSVG
                      value={`upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent('UVAS Membership')}&am=${amount}&cu=INR&tn=${encodeURIComponent('UVAS Membership Renewal')}`}
                      size={110}
                      level="H"
                      bgColor="#ffffff"
                      fgColor="#1e293b"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">UPI Transaction Reference (UTR)</label>
                <input
                  type="text"
                  value={renewalUTR}
                  onChange={(e) => setRenewalUTR(e.target.value)}
                  pattern={renewalUTR ? '[0-9]{12}' : undefined}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  placeholder="12-digit UTR / Transaction ID (optional)"
                />
                <p className="text-xs text-slate-500 mt-1">You can submit UTR later after making the payment.</p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold text-lg py-4 px-6 rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Processing...' : 'Complete Renewal'}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
