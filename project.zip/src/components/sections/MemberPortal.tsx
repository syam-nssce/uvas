import { useState, useEffect, useRef } from 'react';
import { User, LogOut, MessageSquare, Clock, CheckCircle, AlertCircle, Send, Phone, Lock, Mail, Calendar, ArrowLeft, Upload, X, FileText, RefreshCw } from 'lucide-react';
import { supabase, type HelpdeskPost } from '../../lib/supabase';
import type { LoggedInMember } from '../MemberLogin';
import MemberProfile from './MemberProfile';
import RenewMembershipPanel from './RenewMembershipPanel';

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== 'string') { reject(new Error('Failed to read file')); return; }
      const [, base64] = reader.result.split(',');
      if (!base64) { reject(new Error('Failed to encode file')); return; }
      resolve(base64);
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

interface MemberPortalProps {
  onNavigate: (section: string) => void;
}

export default function MemberPortal({ onNavigate }: MemberPortalProps) {
  const [loggedInMember, setLoggedInMember] = useState<LoggedInMember | null>(null);
  const [myQueries, setMyQueries] = useState<HelpdeskPost[]>([]);
  const [showNewPost, setShowNewPost] = useState(false);
  const newPostRef = useRef<HTMLDivElement>(null);
  const renewRef = useRef<HTMLDivElement>(null);
  const [newPost, setNewPost] = useState({ topic: '', title: '', content: '' });
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [showRenew, setShowRenew] = useState(false);

  useEffect(() => {
    const saved = sessionStorage.getItem('loggedInMember');
    if (saved) {
      try {
        const member = JSON.parse(saved);
        setLoggedInMember(member);
      } catch {}
    }
  }, []);

  useEffect(() => {
    if (loggedInMember) fetchMyQueries();
  }, [loggedInMember]);

  const fetchMyQueries = async () => {
    if (!loggedInMember) return;
    const { data } = await supabase
      .from('helpdesk_posts')
      .select('*')
      .eq('member_id', loggedInMember.id)
      .order('created_at', { ascending: false });
    setMyQueries(data || []);
  };

  const handleLogin = (member: LoggedInMember) => {
    setLoggedInMember(member);
    sessionStorage.setItem('loggedInMember', JSON.stringify(member));
  };

  const handleLogout = () => {
    setLoggedInMember(null);
    sessionStorage.removeItem('loggedInMember');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const validTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (!validTypes.includes(file.type)) {
        setError('Invalid file type. Please upload PDF, JPEG, or DOCX files only.');
        return;
      }
      if (file.size > 5 * 1024 * 1024) { setError('File size exceeds 5 MB.'); return; }
      setAttachedFile(file);
      setError('');
    }
  };

  const removeFile = () => setAttachedFile(null);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loggedInMember) return;
    setLoading(true);
    setError('');
    setSuccess(false);

    try {
      let documentUrl: string | undefined;

      // Upload attached file first
      if (attachedFile) {
        const fileBase64 = await fileToBase64(attachedFile);
        const { data: uploadData, error: uploadError } = await supabase.functions.invoke('member-helpdesk', {
          body: {
            action: 'upload_document',
            token: loggedInMember.token,
            file_name: attachedFile.name,
            file_base64: fileBase64,
            content_type: attachedFile.type || 'application/octet-stream',
          },
        });
        if (uploadError || !uploadData?.success) {
          throw new Error(uploadData?.error || 'Failed to upload document');
        }
        documentUrl = uploadData.publicUrl;
      }

      const { data, error: fnError } = await supabase.functions.invoke('member-helpdesk', {
        body: {
          action: 'create_post',
          token: loggedInMember.token,
          topic: newPost.topic,
          title: newPost.title,
          content: newPost.content,
          document_url: documentUrl,
        },
      });

      if (fnError || !data?.success) throw new Error(data?.error || 'Failed to post query');

      setSuccess(true);
      setNewPost({ topic: '', title: '', content: '' });
      setAttachedFile(null);

      setTimeout(() => {
        setShowNewPost(false);
        setSuccess(false);
        fetchMyQueries();
      }, 1500);
    } catch (err: any) {
      setError(err.message || 'Failed to post query');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending': return <span className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3" />Pending Approval</span>;
      case 'open': return <span className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-blue-100 text-blue-800"><AlertCircle className="w-3 h-3" />Open</span>;
      case 'answered': return <span className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-green-100 text-green-800"><CheckCircle className="w-3 h-3" />Answered</span>;
      default: return <span className="text-xs px-2.5 py-1 rounded-full bg-slate-100 text-slate-800">{status}</span>;
    }
  };

  if (!loggedInMember) {
    return <InlineLogin onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-amber-50 py-8 px-4">
      <div className="max-w-5xl mx-auto">
        {/* Member Header */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-8">
          <div className="bg-gradient-to-r from-amber-600 to-orange-600 px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                  <User className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">{loggedInMember.full_name}</h2>
                  <p className="text-amber-100 text-sm">{loggedInMember.mobile} · {loggedInMember.email}</p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-lg hover:bg-white/30 transition-all text-sm font-medium"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <button
            onClick={() => { setShowNewPost(true); setTimeout(() => newPostRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100); }}
            className="bg-white p-6 rounded-xl shadow-md border-2 border-slate-200 hover:border-amber-500 hover:shadow-lg transition-all text-left group"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-amber-100 to-orange-100 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <Send className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-800">Post a Query</h3>
                <p className="text-sm text-slate-600">Submit a service-related query to UVAS</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => { setShowRenew(true); setTimeout(() => renewRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100); }}
            className="bg-white p-6 rounded-xl shadow-md border-2 border-slate-200 hover:border-green-500 hover:shadow-lg transition-all text-left group"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-green-100 to-emerald-100 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <RefreshCw className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-800">Renew Membership</h3>
                <p className="text-sm text-slate-600">Pay and extend your membership for another year</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => onNavigate('helpdesk')}
            className="bg-white p-6 rounded-xl shadow-md border-2 border-slate-200 hover:border-amber-500 hover:shadow-lg transition-all text-left group"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <MessageSquare className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-800">View Help Desk</h3>
                <p className="text-sm text-slate-600">Browse all approved queries and replies</p>
              </div>
            </div>
          </button>
        </div>

        {/* Renew Membership Panel */}
        {showRenew && (
          <div ref={renewRef}>
            <RenewMembershipPanel member={loggedInMember} onClose={() => setShowRenew(false)} />
          </div>
        )}

        {/* Member Profile */}
        <div className="mb-8" data-member-profile>
          <MemberProfile memberId={loggedInMember.id} />
        </div>

        {/* New Post Form */}
        {showNewPost && (
          <div ref={newPostRef} className="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <h3 className="text-xl font-bold text-slate-800 mb-2">Post a New Query</h3>
            <p className="text-slate-600 text-sm mb-6">Your query will be reviewed by admin before it appears on the Help Desk.</p>

            {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 text-sm">{error}</div>}
            {success && <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4 text-sm">Query submitted! It will appear after admin approval.</div>}

            <form onSubmit={handleCreatePost} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Topic / Category *</label>
                <select
                  value={newPost.topic}
                  onChange={(e) => setNewPost({ ...newPost, topic: e.target.value })}
                  required
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                >
                  <option value="">Select a category</option>
                  <option value="Pay & Allowances">Pay &amp; Allowances</option>
                  <option value="Leave Rules">Leave Rules</option>
                  <option value="Promotion & Career Advancement">Promotion &amp; Career Advancement</option>
                  <option value="Pension / Retirement">Pension / Retirement</option>
                  <option value="Service Book">Service Book</option>
                  <option value="Transfer">Transfer</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Query Title *</label>
                <input
                  type="text"
                  value={newPost.title}
                  onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                  required
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  placeholder="A clear, specific question"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Describe your issue *</label>
                <textarea
                  value={newPost.content}
                  onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                  required
                  rows={6}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
                  placeholder="Provide full details..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Attach Document (optional)</label>
                {attachedFile ? (
                  <div className="flex items-center justify-between bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <div className="flex items-center space-x-3">
                      <Upload className="w-5 h-5 text-amber-600" />
                      <div>
                        <p className="text-sm font-medium text-slate-800">{attachedFile.name}</p>
                        <p className="text-xs text-slate-500">{(attachedFile.size / 1024).toFixed(2)} KB</p>
                      </div>
                    </div>
                    <button type="button" onClick={removeFile} className="text-red-600 hover:text-red-700">
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ) : (
                  <div className="relative">
                    <input type="file" id="member-file-upload" accept=".pdf,.jpg,.jpeg,.docx" onChange={handleFileChange} className="hidden" />
                    <label htmlFor="member-file-upload" className="flex items-center justify-center w-full px-4 py-8 border-2 border-dashed border-slate-300 rounded-lg cursor-pointer hover:border-amber-500 hover:bg-amber-50 transition-all">
                      <div className="text-center">
                        <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                        <p className="text-sm text-slate-600 font-medium">Click to upload</p>
                        <p className="text-xs text-slate-500 mt-1">PDF, JPEG or DOCX — max 5 MB</p>
                      </div>
                    </label>
                  </div>
                )}
              </div>

              <div className="flex gap-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all shadow-lg disabled:opacity-50"
                >
                  {loading ? 'Submitting...' : 'Submit Query'}
                </button>
                <button
                  type="button"
                  onClick={() => { setShowNewPost(false); setError(''); }}
                  className="px-6 py-3 border-2 border-slate-300 rounded-lg text-slate-700 font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* My Queries */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="px-8 py-5 border-b border-slate-200">
            <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-amber-600" />
              My Queries
              <span className="bg-slate-100 text-slate-600 text-sm px-2.5 py-0.5 rounded-full">{myQueries.length}</span>
            </h3>
          </div>

          {myQueries.length === 0 ? (
            <div className="text-center py-16 text-slate-400">
              <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p className="font-medium">No queries yet</p>
              <p className="text-sm mt-1">Post your first query using the button above</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {myQueries.map((query) => (
                <div key={query.id} className="px-8 py-5 hover:bg-slate-50 transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <h4 className="font-semibold text-slate-800">{query.title}</h4>
                      <span className="text-xs text-amber-600 font-medium">{query.topic}</span>
                    </div>
                    {getStatusBadge(query.status)}
                  </div>
                  <p className="text-sm text-slate-600 line-clamp-2 mb-2">{query.content}</p>
                  <p className="text-xs text-slate-400">{new Date(query.created_at).toLocaleString()}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function InlineLogin({ onLogin }: { onLogin: (member: LoggedInMember) => void }) {
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotDob, setForgotDob] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotError, setForgotError] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState('');
  const [verifiedMemberId, setVerifiedMemberId] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke('member-login', {
        body: { mobile, password },
      });

      if (fnError || !data?.success) {
        setError(data?.error || 'Login failed.');
        setLoading(false);
        return;
      }

      onLogin({ ...data.member, token: data.token });
    } catch (err: any) {
      setError('Login failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyIdentity = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotLoading(true);
    setForgotError('');
    setForgotSuccess('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke('member-forgot-password', {
        body: { action: 'verify', email: forgotEmail.trim().toLowerCase(), date_of_birth: forgotDob },
      });

      if (fnError || !data?.success) {
        setForgotError(data?.error || 'Verification failed.');
        setForgotLoading(false);
        return;
      }

      setVerifiedMemberId(data.member_id);
    } catch (err: any) {
      setForgotError('Verification failed.');
    } finally {
      setForgotLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 4) { setForgotError('Password must be at least 4 characters.'); return; }
    if (newPassword !== confirmPassword) { setForgotError('Passwords do not match.'); return; }
    setForgotLoading(true);
    setForgotError('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke('member-forgot-password', {
        body: { action: 'reset', member_id: verifiedMemberId, new_password: newPassword },
      });

      if (fnError || !data?.success) {
        setForgotError(data?.error || 'Password reset failed.');
        setForgotLoading(false);
        return;
      }

      setForgotSuccess('Password reset successfully! You can now login with your new password.');
      setTimeout(() => {
        setShowForgotPassword(false);
        setVerifiedMemberId(null);
        setForgotEmail('');
        setForgotDob('');
        setNewPassword('');
        setConfirmPassword('');
        setForgotSuccess('');
      }, 2500);
    } catch (err: any) {
      setForgotError('Password reset failed.');
    } finally {
      setForgotLoading(false);
    }
  };

  if (showForgotPassword) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center py-12 px-4">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-amber-100 to-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-10 h-10 text-amber-600" />
            </div>
            <h2 className="text-3xl font-bold text-slate-800 mb-2">Reset Password</h2>
            <p className="text-slate-600">
              {verifiedMemberId ? 'Set your new password' : 'Verify your identity using email and date of birth'}
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            {forgotError && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm mb-4">{forgotError}</div>}
            {forgotSuccess && <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm mb-4">{forgotSuccess}</div>}

            {!verifiedMemberId ? (
              <form onSubmit={handleVerifyIdentity} className="space-y-5">
                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Mail className="w-4 h-4 mr-2 text-amber-600" />
                    Registered Email
                  </label>
                  <input
                    type="email"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    placeholder="Email used during registration"
                  />
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Calendar className="w-4 h-4 mr-2 text-amber-600" />
                    Date of Birth
                  </label>
                  <input
                    type="date"
                    value={forgotDob}
                    onChange={(e) => setForgotDob(e.target.value)}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  />
                </div>

                <button
                  type="submit"
                  disabled={forgotLoading}
                  className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all shadow-lg disabled:opacity-50"
                >
                  {forgotLoading ? 'Verifying...' : 'Verify Identity'}
                </button>
              </form>
            ) : (
              <form onSubmit={handleResetPassword} className="space-y-5">
                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Lock className="w-4 h-4 mr-2 text-amber-600" />
                    New Password
                  </label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    required
                    minLength={4}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    placeholder="Enter new password"
                  />
                </div>

                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Lock className="w-4 h-4 mr-2 text-amber-600" />
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    minLength={4}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    placeholder="Confirm new password"
                  />
                </div>

                <button
                  type="submit"
                  disabled={forgotLoading}
                  className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all shadow-lg disabled:opacity-50"
                >
                  {forgotLoading ? 'Resetting...' : 'Reset Password'}
                </button>
              </form>
            )}

            <button
              onClick={() => { setShowForgotPassword(false); setVerifiedMemberId(null); setForgotError(''); setForgotSuccess(''); }}
              className="w-full mt-4 flex items-center justify-center gap-2 text-amber-600 hover:text-amber-700 font-medium text-sm transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Login
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[60vh] flex items-center justify-center py-12 px-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-amber-100 to-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <User className="w-10 h-10 text-amber-600" />
          </div>
          <h2 className="text-3xl font-bold text-slate-800 mb-2">Member Login</h2>
          <p className="text-slate-600">Login with your registered mobile number and password</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <form onSubmit={handleLogin} className="space-y-5">
            {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>}

            <div>
              <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                <Phone className="w-4 h-4 mr-2 text-amber-600" />
                Mobile Number
              </label>
              <input
                type="tel"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                required
                maxLength={10}
                pattern="[0-9]{10}"
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="10-digit mobile number"
              />
            </div>

            <div>
              <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                <Lock className="w-4 h-4 mr-2 text-amber-600" />
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="Password set during registration"
              />
            </div>

            <div className="text-right">
              <button
                type="button"
                onClick={() => setShowForgotPassword(true)}
                className="text-sm text-amber-600 hover:text-amber-700 font-medium hover:underline transition-colors"
              >
                Forgot Password?
              </button>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all shadow-lg disabled:opacity-50"
            >
              {loading ? 'Logging in...' : 'Login'}
            </button>

            <p className="text-xs text-slate-500 text-center">
              Use the mobile number and password you provided during membership registration.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
