import { useState, useEffect } from 'react';
import { Image as ImageIcon, Plus, CreditCard as Edit2, Trash2, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface GalleryImage {
  id: string;
  title: string;
  description: string | null;
  image_url: string;
  category: string | null;
  event_date: string | null;
  display_order: number;
  published: boolean;
  created_at: string;
}

interface GalleryProps {
  isAdmin?: boolean;
}

export default function Gallery({ isAdmin = false }: GalleryProps) {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingImage, setEditingImage] = useState<GalleryImage | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    image_url: '',
    category: '',
    event_date: '',
    published: false,
  });

  useEffect(() => {
    fetchImages();
  }, [isAdmin]);

  async function fetchImages() {
    try {
      let query = supabase
        .from('gallery')
        .select('*')
        .order('display_order', { ascending: true })
        .order('created_at', { ascending: false });

      if (!isAdmin) {
        query = query.eq('published', true);
      }

      const { data, error } = await query;

      if (error) throw error;
      const rows = data || [];
      setImages(isAdmin ? rows : rows.filter((image) => Boolean(image.image_url?.trim())));
    } catch (error) {
      console.error('Error fetching gallery images:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    try {
      if (editingImage) {
        const { error } = await supabase
          .from('gallery')
          .update({
            title: formData.title,
            description: formData.description || null,
            image_url: formData.image_url,
            category: formData.category || null,
            event_date: formData.event_date || null,
            published: formData.published,
          })
          .eq('id', editingImage.id);

        if (error) throw error;
      } else {
        const { error } = await supabase.from('gallery').insert([
          {
            title: formData.title,
            description: formData.description || null,
            image_url: formData.image_url,
            category: formData.category || null,
            event_date: formData.event_date || null,
            published: formData.published,
          },
        ]);

        if (error) throw error;
      }

      setFormData({
        title: '',
        description: '',
        image_url: '',
        category: '',
        event_date: '',
        published: false,
      });
      setEditingImage(null);
      setShowForm(false);
      fetchImages();
    } catch (error) {
      console.error('Error saving image:', error);
      alert('Failed to save image');
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this image?')) return;

    try {
      const { error } = await supabase.from('gallery').delete().eq('id', id);

      if (error) throw error;
      fetchImages();
    } catch (error) {
      console.error('Error deleting image:', error);
      alert('Failed to delete image');
    }
  }

  function openEditForm(image: GalleryImage) {
    setEditingImage(image);
    setFormData({
      title: image.title,
      description: image.description || '',
      image_url: image.image_url,
      category: image.category || '',
      event_date: image.event_date || '',
      published: image.published,
    });
    setShowForm(true);
  }

  function closeForm() {
    setShowForm(false);
    setEditingImage(null);
    setFormData({
      title: '',
      description: '',
      image_url: '',
      category: '',
      event_date: '',
      published: false,
    });
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-amber-600"></div>
          <p className="mt-2 text-slate-600">Loading gallery...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-gradient-to-br from-amber-600 to-orange-600 p-2 rounded-lg text-white">
                <ImageIcon className="w-8 h-8" />
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold text-slate-800">Gallery</h2>
            </div>
            <div className="h-1 w-24 bg-gradient-to-r from-amber-600 to-orange-600 rounded-full"></div>
          </div>
          {isAdmin && (
            <button
              onClick={() => setShowForm(true)}
              className="flex items-center gap-2 bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors"
            >
              <Plus className="w-5 h-5" />
              Add Image
            </button>
          )}
        </div>
      </div>

      {images.length === 0 ? (
        <div className="text-center py-12 bg-slate-50 rounded-xl border border-slate-200">
          <ImageIcon className="w-16 h-16 text-slate-400 mx-auto mb-4" />
          <p className="text-slate-600">No images in the gallery yet.</p>
          {isAdmin && (
            <button
              onClick={() => setShowForm(true)}
              className="mt-4 text-amber-600 hover:text-amber-700 font-medium"
            >
              Add your first image
            </button>
          )}
        </div>
      ) : (
        <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-4">
          {images.map((image) => (
            <div
              key={image.id}
              className="group relative aspect-square bg-slate-100 rounded-lg overflow-hidden border border-slate-200 hover:shadow-lg transition-all duration-200 cursor-pointer"
              onClick={() => {
                setSelectedImage(image);
                setShowModal(true);
              }}
            >
              {image.image_url ? (
                <img
                  src={image.image_url}
                  alt={image.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="flex h-full items-center justify-center bg-slate-100 text-slate-400">
                  <ImageIcon className="w-10 h-10" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                  <p className="font-semibold text-sm line-clamp-2">{image.title}</p>
                  {image.category && (
                    <p className="text-xs text-white/80 mt-1">{image.category}</p>
                  )}
                </div>
              </div>
              {isAdmin && (
                <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      openEditForm(image);
                    }}
                    className="p-2 bg-white rounded-lg shadow-lg hover:bg-slate-100"
                  >
                    <Edit2 className="w-4 h-4 text-slate-700" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(image.id);
                    }}
                    className="p-2 bg-white rounded-lg shadow-lg hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </button>
                </div>
              )}
              {!image.published && isAdmin && (
                <div className="absolute top-2 left-2 bg-yellow-500 text-white px-2 py-1 rounded text-xs font-semibold">
                  Unpublished
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {showModal && selectedImage && (
        <div
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
          onClick={() => setShowModal(false)}
        >
          <div
            className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 bg-white border-b border-slate-200 p-4 flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-800">{selectedImage.title}</h3>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6">
              <img
                src={selectedImage.image_url}
                alt={selectedImage.title}
                className="w-full h-auto rounded-lg mb-4"
              />
              {selectedImage.description && (
                <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                  <h4 className="font-semibold text-slate-800 mb-2">Description</h4>
                  <p className="text-slate-700 whitespace-pre-wrap">{selectedImage.description}</p>
                </div>
              )}
              {selectedImage.category && (
                <p className="mt-4 text-sm text-slate-600">
                  <span className="font-semibold">Category:</span> {selectedImage.category}
                </p>
              )}
              {selectedImage.event_date && (
                <p className="mt-2 text-sm text-slate-600">
                  <span className="font-semibold">Date:</span>{' '}
                  {new Date(selectedImage.event_date).toLocaleDateString()}
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {showForm && isAdmin && (
        <div
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          onClick={closeForm}
        >
          <div
            className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 bg-white border-b border-slate-200 p-4 flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-800">
                {editingImage ? 'Edit Image' : 'Add New Image'}
              </h3>
              <button
                onClick={closeForm}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Title *
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={4}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  placeholder="Add a description for this image..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Image URL *
                </label>
                <input
                  type="url"
                  required
                  value={formData.image_url}
                  onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  placeholder="https://example.com/image.jpg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Category
                </label>
                <input
                  type="text"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  placeholder="e.g., Annual Conference, Workshop"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Event Date
                </label>
                <input
                  type="date"
                  value={formData.event_date}
                  onChange={(e) => setFormData({ ...formData, event_date: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                />
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="published"
                  checked={formData.published}
                  onChange={(e) => setFormData({ ...formData, published: e.target.checked })}
                  className="w-4 h-4 text-amber-600 border-slate-300 rounded focus:ring-amber-500"
                />
                <label htmlFor="published" className="ml-2 text-sm text-slate-700">
                  Publish (make visible to everyone)
                </label>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-amber-600 text-white py-2 px-4 rounded-lg hover:bg-amber-700 transition-colors font-medium"
                >
                  {editingImage ? 'Update Image' : 'Add Image'}
                </button>
                <button
                  type="button"
                  onClick={closeForm}
                  className="px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors font-medium"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
