import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Event {
  id: string;
  title: string;
  content: string;
  image_url: string | null;
  event_date: string | null;
  posted_date: string | null;
}

interface EventSliderProps {
  onNavigate: (section: string) => void;
}

export default function EventSlider({ onNavigate }: EventSliderProps) {
  const [events, setEvents] = useState<Event[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    fetchEvents();
  }, []);

  useEffect(() => {
    if (!isAutoPlaying || events.length === 0) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % events.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, events.length]);

  const fetchEvents = async () => {
    const { data, error } = await supabase
      .from('news_events')
      .select('id, title, content, image_url, event_date, posted_date')
      .eq('published', true)
      .eq('type', 'event')
      .order('event_date', { ascending: false, nullsFirst: false })
      .limit(6);

    if (error) {
      console.error('Error fetching events:', error);
      return;
    }

    if (data) {
      setEvents(data);
    }
  };

  const handlePrevious = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev - 1 + events.length) % events.length);
  };

  const handleNext = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev + 1) % events.length);
  };

  const handleEventClick = () => {
    onNavigate('news');
  };

  if (events.length === 0) {
    return (
      <div className="bg-gradient-to-br from-slate-100 to-amber-50 rounded-xl p-12 text-center">
        <Calendar className="w-16 h-16 text-slate-400 mx-auto mb-4" />
        <p className="text-slate-600">No events available at the moment</p>
      </div>
    );
  }

  const currentEvent = events[currentIndex];

  return (
    <div className="relative bg-white rounded-xl shadow-lg overflow-hidden border border-slate-200">
      <div className="relative h-96 overflow-hidden">
        {currentEvent.image_url ? (
          <img
            src={currentEvent.image_url}
            alt={currentEvent.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-amber-500 via-orange-500 to-amber-600 flex items-center justify-center">
            <Calendar className="w-24 h-24 text-white/30" />
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>

        <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-5 h-5" />
            <span className="text-sm font-medium">
              {currentEvent.event_date
                ? new Date(currentEvent.event_date).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })
                : 'News & Updates'}
            </span>
          </div>
          <h3 className="text-2xl font-bold mb-2 leading-tight">{currentEvent.title}</h3>
          <p className="text-white/90 text-sm leading-relaxed line-clamp-2">
            {currentEvent.content}
          </p>
          <button
            onClick={handleEventClick}
            className="mt-4 inline-block bg-white/20 backdrop-blur-sm hover:bg-white/30 px-6 py-2 rounded-lg font-semibold text-sm transition-all duration-200 border border-white/30"
          >
            View All Events
          </button>
        </div>
      </div>

      <button
        onClick={handlePrevious}
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-slate-800 p-3 rounded-full shadow-lg transition-all duration-200 hover:scale-110"
        aria-label="Previous event"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      <button
        onClick={handleNext}
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-slate-800 p-3 rounded-full shadow-lg transition-all duration-200 hover:scale-110"
        aria-label="Next event"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
        {events.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setIsAutoPlaying(false);
              setCurrentIndex(index);
            }}
            className={`h-2 rounded-full transition-all duration-300 ${
              index === currentIndex
                ? 'w-8 bg-white'
                : 'w-2 bg-white/50 hover:bg-white/75'
            }`}
            aria-label={`Go to event ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
