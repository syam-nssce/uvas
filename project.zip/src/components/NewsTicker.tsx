import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

interface TickerItem {
  id: string;
  message: string;
  display_order: number;
}

export default function NewsTicker() {
  const [tickerItems, setTickerItems] = useState<TickerItem[]>([]);

  useEffect(() => {
    loadTickerItems();
  }, []);

  const loadTickerItems = async () => {
    const { data, error } = await supabase
      .from('news_ticker')
      .select('id, message, display_order')
      .eq('is_active', true)
      .order('display_order');

    if (!error && data) {
      setTickerItems(data);
    }
  };

  if (tickerItems.length === 0) {
    return null;
  }

  return (
    <div className="bg-primary text-primary-foreground py-2.5 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
        <div className="bg-white/15 px-3 py-1 rounded text-xs font-semibold mr-4 whitespace-nowrap uppercase tracking-widest">
          News
        </div>
        <div className="ticker-wrapper flex-1 overflow-hidden">
          <div className="ticker-content flex gap-8 animate-ticker text-sm font-light tracking-wide">
            {tickerItems.map((item) => (
              <span key={item.id} className="whitespace-nowrap">
                {item.message}
              </span>
            ))}
            {tickerItems.map((item) => (
              <span key={`${item.id}-duplicate`} className="whitespace-nowrap">
                {item.message}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
