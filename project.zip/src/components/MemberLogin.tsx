import { useState } from 'react';
import { Phone, Lock, X, LogIn, Mail, Calendar, ArrowLeft, AtSign } from 'lucide-react';
import { supabase } from '../integrations/supabase/client';

interface LoggedInMember {
  id: string;
  full_name: string;
  mobile: string;
  email: string;
  membership_category: string | null;
  token: string;
}

interface MemberLoginProps {
  onLogin: (member: LoggedInMember) => void;
  onClose: () => void;
}

export default function MemberLogin({ onLogin, onClose }: MemberLoginProps) {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotDob, setForgotDob] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotError, setForgotError] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState('');
  const [verifiedMemberId, setVerifiedMemberId] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke('member-login', {
        body: { identifier: identifier.trim(), password },
      });

      if (fnError || !data?.success) {
        setError(data?.error || 'Login failed. Please try again.');
        setLoading(false);
        return;
      }

      onLogin({ ...data.member, token: data.token });
    } catch (err: any) {
      setError('Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyIdentity = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotLoading(true);
    setForgotError('');
    setForgotSuccess('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke('member-forgot-password', {
        body: { action: 'verify', email: forgotEmail.trim().toLowerCase(), date_of_birth: forgotDob },
      });

      if (fnError || !data?.success) {
        setForgotError(data?.error || 'Verification failed.');
        setForgotLoading(false);
        return;
      }

      setVerifiedMemberId(data.member_id);
    } catch (err: any) {
      setForgotError('Verification failed.');
    } finally {
      setForgotLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 4) { setForgotError('Password must be at least 4 characters.'); return; }
    if (newPassword !== confirmPassword) { setForgotError('Passwords do not match.'); return; }
    setForgotLoading(true);
    setForgotError('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke('member-forgot-password', {
        body: { action: 'reset', member_id: verifiedMemberId, new_password: newPassword },
      });

      if (fnError || !data?.success) {
        setForgotError(data?.error || 'Password reset failed.');
        setForgotLoading(false);
        return;
      }

      setForgotSuccess('Password reset successfully! You can now login.');
      setTimeout(() => {
        setShowForgotPassword(false);
        setVerifiedMemberId(null);
        setForgotEmail('');
        setForgotDob('');
        setNewPassword('');
        setConfirmPassword('');
        setForgotSuccess('');
      }, 2500);
    } catch (err: any) {
      setForgotError('Password reset failed.');
    } finally {
      setForgotLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
        <div className="bg-gradient-to-r from-amber-600 to-orange-600 px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <LogIn className="w-6 h-6 text-white" />
            <div>
              <h2 className="text-xl font-bold text-white">
                {showForgotPassword ? 'Reset Password' : 'Member Login'}
              </h2>
              <p className="text-amber-100 text-sm">
                {showForgotPassword
                  ? (verifiedMemberId ? 'Set your new password' : 'Verify using email & date of birth')
                  : 'Login to post your query'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        {showForgotPassword ? (
          <div className="p-6 space-y-5">
            {forgotError && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{forgotError}</div>}
            {forgotSuccess && <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">{forgotSuccess}</div>}

            {!verifiedMemberId ? (
              <form onSubmit={handleVerifyIdentity} className="space-y-5">
                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Mail className="w-4 h-4 mr-2 text-amber-600" />
                    Registered Email
                  </label>
                  <input type="email" value={forgotEmail} onChange={(e) => setForgotEmail(e.target.value)} required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    placeholder="Email used during registration" />
                </div>
                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Calendar className="w-4 h-4 mr-2 text-amber-600" />
                    Date of Birth
                  </label>
                  <input type="date" value={forgotDob} onChange={(e) => setForgotDob(e.target.value)} required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent" />
                </div>
                <button type="submit" disabled={forgotLoading}
                  className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all shadow-lg disabled:opacity-50">
                  {forgotLoading ? 'Verifying...' : 'Verify Identity'}
                </button>
              </form>
            ) : (
              <form onSubmit={handleResetPassword} className="space-y-5">
                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Lock className="w-4 h-4 mr-2 text-amber-600" />
                    New Password
                  </label>
                  <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength={4}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    placeholder="Enter new password" />
                </div>
                <div>
                  <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                    <Lock className="w-4 h-4 mr-2 text-amber-600" />
                    Confirm Password
                  </label>
                  <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required minLength={4}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    placeholder="Confirm new password" />
                </div>
                <button type="submit" disabled={forgotLoading}
                  className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all shadow-lg disabled:opacity-50">
                  {forgotLoading ? 'Resetting...' : 'Reset Password'}
                </button>
              </form>
            )}

            <button onClick={() => { setShowForgotPassword(false); setVerifiedMemberId(null); setForgotError(''); setForgotSuccess(''); }}
              className="w-full flex items-center justify-center gap-2 text-amber-600 hover:text-amber-700 font-medium text-sm transition-colors">
              <ArrowLeft className="w-4 h-4" /> Back to Login
            </button>
          </div>
        ) : (
          <form onSubmit={handleLogin} className="p-6 space-y-5">
            {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>}

            <div>
              <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                <AtSign className="w-4 h-4 mr-2 text-amber-600" />
                Mobile Number or Email
              </label>
              <input type="text" value={identifier} onChange={(e) => setIdentifier(e.target.value)} required
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                placeholder="10-digit mobile or registered email" autoComplete="username" />
            </div>

            <div>
              <label className="flex items-center text-sm font-medium text-slate-700 mb-2">
                <Lock className="w-4 h-4 mr-2 text-amber-600" />
                Password
              </label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                placeholder="Password set during registration" />
            </div>

            <div className="text-right">
              <button type="button" onClick={() => setShowForgotPassword(true)}
                className="text-sm text-amber-600 hover:text-amber-700 font-medium hover:underline transition-colors">
                Forgot Password?
              </button>
            </div>

            <button type="submit" disabled={loading}
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold py-3 px-6 rounded-lg hover:from-amber-700 hover:to-orange-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed">
              {loading ? 'Logging in...' : 'Login'}
            </button>

            <p className="text-xs text-slate-500 text-center">
              Use the mobile number or email and password from your membership registration.
            </p>
          </form>
        )}
      </div>
    </div>
  );
}

export type { LoggedInMember };
