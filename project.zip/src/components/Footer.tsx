import { useState, useEffect } from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';
import { supabase, type SiteSetting } from '../lib/supabase';

interface FooterProps {
  onNavigate?: (section: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const [contactInfo, setContactInfo] = useState({
    email: 'contact@uvas-kerala.org',
    phone: '+91 XXX XXX XXXX',
    address: 'Kerala, India',
  });

  useEffect(() => {
    fetchContactInfo();
  }, []);

  const fetchContactInfo = async () => {
    const { data } = await supabase.from('site_settings').select('*');
    if (data) {
      const settings: Record<string, string> = {};
      data.forEach((s: SiteSetting) => {
        settings[s.setting_key] = s.setting_value;
      });

      setContactInfo({
        email: settings.contact_email || 'contact@uvas-kerala.org',
        phone: settings.contact_phone || '+91 XXX XXX XXXX',
        address: settings.contact_address || 'Kerala, India',
      });
    }
  };

  return (
    <footer className="bg-[hsl(220,25%,12%)] text-white mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-10 mb-10">
          <div>
            <h3 className="font-display font-bold text-xl tracking-tight mb-2">UVAS</h3>
            <p className="text-white/50 text-sm leading-relaxed font-light">
              Unnatha Vidyabhyasa Adhyapaka Sangham
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-5 text-[hsl(40,60%,72%)] text-sm uppercase tracking-widest">Contact Us</h4>
            <div className="space-y-4 text-sm">
              <div className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-[hsl(40,60%,72%)] shrink-0" />
                <span className="text-white/60">{contactInfo.email}</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-[hsl(40,60%,72%)] shrink-0" />
                <span className="text-white/60">{contactInfo.phone}</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="w-4 h-4 text-[hsl(40,60%,72%)] shrink-0" />
                <span className="text-white/60">{contactInfo.address}</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-5 text-[hsl(40,60%,72%)] text-sm uppercase tracking-widest">Quick Links</h4>
            <ul className="space-y-2.5 text-sm">
              {[
                { id: 'home', label: 'Home' },
                { id: 'about', label: 'About Us' },
                { id: 'membership', label: 'Join / Renew Membership' },
                { id: 'helpdesk', label: 'Service Help Desk' },
                { id: 'orders', label: 'Orders & Circulars' },
                { id: 'news', label: 'News & Events' },
                { id: 'gallery', label: 'Gallery' },
                { id: 'prajnabharati', label: 'Prajnabharati Journal' },
              ].map(link => (
                <li key={link.id}>
                  <button
                    onClick={() => onNavigate?.(link.id)}
                    className="text-white/50 hover:text-[hsl(40,60%,72%)] transition-colors duration-200 text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-3 md:space-y-0">
            <p className="text-xs text-white/30 tracking-wide">
              Reg. E.R. 299/98 · Affiliated to ABRSM, New Delhi
            </p>
            <p className="text-xs text-white/30 tracking-wide">
              © {new Date().getFullYear()} UVAS. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
