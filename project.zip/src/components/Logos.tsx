export const UVASLogo = () => (
  <img src="/uvas.jpg" alt="UVAS Logo" className="h-28 w-auto object-contain" />
);

export const ABRSMLogo = () => (
  <img src="/abrsm.png" alt="ABRSM Logo" className="h-28 w-auto object-contain" />
);
