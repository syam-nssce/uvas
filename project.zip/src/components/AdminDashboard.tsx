import { useState, useEffect } from 'react';
import { adminCrud } from '../lib/adminCrud';
import { LogOut, Menu, X, Home } from 'lucide-react';
import NewsEventsAdmin from './admin/NewsEventsAdmin';
import OrdersCircularsAdmin from './admin/OrdersCircularsAdmin';
import GalleryAdmin from './admin/GalleryAdmin';
import CommitteeAdmin from './admin/CommitteeAdmin';
import HomeContentAdmin from './admin/HomeContentAdmin';
import MembersAdmin from './admin/MembersAdmin';
import HelpdeskAdmin from './admin/HelpdeskAdmin';
import SettingsAdmin from './admin/SettingsAdmin';

type AdminTab = 'news' | 'orders' | 'gallery' | 'committee' | 'homepage' | 'members' | 'helpdesk' | 'settings';

export default function AdminDashboard({ onLogout, adminCredentials }: { onLogout: () => void; adminCredentials?: { username: string; password: string } | null }) {
  const [activeTab, setActiveTab] = useState<AdminTab>('news');
  const [stats, setStats] = useState({
    totalMembers: 0,
    pendingMembers: 0,
    openQueries: 0,
    documents: 0,
  });
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleLogout = () => {
    onLogout();
  };

  const handleGoHome = () => {
    window.location.href = '/';
  };

  useEffect(() => {
    if (!adminCredentials) return;
    fetchStats();
  }, [activeTab, adminCredentials]);

  const fetchStats = async () => {
    if (!adminCredentials) return;
    try {
      const result = await adminCrud({
        table: 'members',
        action: 'stats',
        data: {
          tables: [
            { table: 'members', key: 'totalMembers' },
            { table: 'members', key: 'pendingMembers', filter: { status: 'pending' } },
            { table: 'helpdesk_posts', key: 'openQueries', filter: { status: 'open' } },
            { table: 'orders_circulars', key: 'documents' },
          ],
        },
        credentials: adminCredentials,
      });
      if (result?.stats) {
        setStats({
          totalMembers: result.stats.totalMembers || 0,
          pendingMembers: result.stats.pendingMembers || 0,
          openQueries: result.stats.openQueries || 0,
          documents: result.stats.documents || 0,
        });
      }
    } catch (err) {
      console.error('Failed to fetch stats:', err);
    }
  };

  const tabs = [
    { id: 'news' as AdminTab, label: 'News & Events', icon: '📰' },
    { id: 'orders' as AdminTab, label: 'Orders & Circulars', icon: '📄' },
    { id: 'gallery' as AdminTab, label: 'Gallery', icon: '🖼️' },
    { id: 'committee' as AdminTab, label: 'Committee', icon: '👥' },
    { id: 'homepage' as AdminTab, label: 'Home Content', icon: '🏠' },
    { id: 'members' as AdminTab, label: 'Members', icon: '🪪' },
    { id: 'helpdesk' as AdminTab, label: 'Help Desk', icon: '💬' },
    { id: 'settings' as AdminTab, label: 'Settings', icon: '⚙️' },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'news':
        return <NewsEventsAdmin adminCredentials={adminCredentials ?? undefined} />;
      case 'orders':
        return <OrdersCircularsAdmin adminCredentials={adminCredentials ?? undefined} />;
      case 'gallery':
        return <GalleryAdmin adminCredentials={adminCredentials ?? undefined} />;
      case 'committee':
        return <CommitteeAdmin adminCredentials={adminCredentials ?? undefined} />;
      case 'homepage':
        return <HomeContentAdmin adminCredentials={adminCredentials ?? undefined} />;
      case 'members':
        return <MembersAdmin adminCredentials={adminCredentials ?? undefined} />;
      case 'helpdesk':
        return <HelpdeskAdmin adminCredentials={adminCredentials ?? undefined} />;
      case 'settings':
        return <SettingsAdmin adminCredentials={adminCredentials ?? undefined} />;
      default:
        return <NewsEventsAdmin adminCredentials={adminCredentials ?? undefined} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-amber-50">
      <div className="bg-gradient-to-r from-amber-700 to-orange-700 text-white px-6 py-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <div>
              <h1 className="text-2xl font-bold">UVAS Admin Dashboard</h1>
              <p className="text-amber-100 text-sm">Content Management System</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleGoHome}
              className="flex items-center space-x-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-all"
              title="Go to Home Page"
            >
              <Home className="w-5 h-5" />
              <span>Home</span>
            </button>
            <button
              onClick={handleLogout}
              className="flex items-center space-x-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-all"
            >
              <LogOut className="w-5 h-5" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="flex gap-6">
          <div
            className={`${
              sidebarOpen ? 'block' : 'hidden'
            } lg:block w-64 flex-shrink-0 bg-gradient-to-b from-amber-900 to-orange-900 rounded-2xl shadow-xl overflow-hidden sticky top-6 self-start`}
            style={{ maxHeight: 'calc(100vh - 8rem)' }}
          >
            <div className="bg-amber-800/50 px-4 py-3 border-b border-white/10">
              <div className="text-xs font-bold text-amber-200 uppercase tracking-wider">CMS Menu</div>
            </div>

            <nav className="py-2 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 20rem)' }}>
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    if (window.innerWidth < 1024) setSidebarOpen(false);
                  }}
                  className={`w-full px-4 py-3 flex items-center space-x-3 transition-all ${
                    activeTab === tab.id
                      ? 'bg-white text-amber-900 font-semibold shadow-lg'
                      : 'text-white hover:bg-white/10'
                  }`}
                >
                  <span className="text-lg">{tab.icon}</span>
                  <span className="text-sm">{tab.label}</span>
                </button>
              ))}
            </nav>

            <div className="border-t border-white/15 p-4">
              <div className="text-xs font-bold text-amber-200 uppercase tracking-wide mb-3">Quick Stats</div>
              <div className="text-sm text-white space-y-2">
                <div className="flex justify-between">
                  <span>Total Members</span>
                  <strong className="text-amber-300">{stats.totalMembers}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Pending</span>
                  <strong className="text-yellow-300">{stats.pendingMembers}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Open Queries</span>
                  <strong className="text-red-300">{stats.openQueries}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Documents</span>
                  <strong className="text-white">{stats.documents}</strong>
                </div>
              </div>
            </div>
          </div>

          <div className="flex-1 min-w-0">{renderContent()}</div>
        </div>
      </div>
    </div>
  );
}
