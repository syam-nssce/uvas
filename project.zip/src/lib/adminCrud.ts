import { supabase } from '@/integrations/supabase/client';

interface AdminCrudParams {
  table: string;
  action: 'list' | 'insert' | 'update' | 'delete' | 'upsert' | 'stats';
  data?: any;
  id?: string;
  filters?: Record<string, any>;
  select_columns?: string;
  order_by?: { column: string; ascending?: boolean };
  upsert_conflict?: string;
  credentials: { username: string; password: string };
}

export async function adminCrud(params: AdminCrudParams) {
  const { credentials, ...rest } = params;
  const { data, error } = await supabase.functions.invoke('admin-crud', {
    body: {
      ...rest,
      username: credentials.username,
      password: credentials.password,
    },
  });
  if (error) throw new Error(error.message || 'Request failed');
  if (!data?.success) throw new Error(data?.error || 'Operation failed');
  return data;
}
