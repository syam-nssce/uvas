// Re-export the auto-generated Supabase client
export { supabase } from '@/integrations/supabase/client';

// Re-export types from the generated types for convenience
export type Member = {
  id: string;
  user_id: string | null;
  full_name: string;
  email: string;
  phone: string | null;
  address: string | null;
  institution: string | null;
  designation: string | null;
  membership_type: string;
  status: string;
  joined_date: string;
  renewal_date: string | null;
  retirement_date: string | null;
  payment_status: string;
  payment_id: string | null;
  created_at: string;
  updated_at: string;
};

export type HelpdeskPost = {
  id: string;
  member_id: string;
  topic: string;
  title: string;
  content: string;
  status: string;
  views: number;
  created_at: string;
  updated_at: string;
  members?: {
    full_name: string;
    college_name: string | null;
  };
};

export type HelpdeskReply = {
  id: string;
  post_id: string;
  member_id: string;
  content: string;
  is_admin: boolean;
  approved: boolean;
  created_at: string;
};

export type NewsEvent = {
  id: string;
  type: string;
  title: string;
  content: string;
  image_url: string | null;
  document_url: string | null;
  event_date: string | null;
  posted_date: string | null;
  published: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
};

export type OrderCircular = {
  id: string;
  type: string;
  reference_number: string;
  title: string;
  content: string;
  category: string | null;
  tags: string[];
  document_url: string | null;
  issue_date: string;
  published: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
};

export type PrajnabharatiJournal = {
  id: string;
  volume: number;
  issue: number;
  title: string;
  description: string | null;
  cover_image_url: string | null;
  pdf_url: string | null;
  publication_date: string;
  published: boolean;
  created_at: string;
};

export type GalleryItem = {
  id: string;
  title: string;
  description: string | null;
  image_url: string;
  category: string | null;
  event_date: string | null;
  display_order: number;
  published: boolean;
  uploaded_by: string | null;
  created_at: string;
  updated_at: string;
};

export type CommitteeMember = {
  id: string;
  full_name: string;
  designation: string;
  committee_type: string;
  district: string | null;
  mobile: string | null;
  email: string | null;
  photo_url: string | null;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

export type NewsTicker = {
  id: string;
  message: string;
  is_active: boolean;
  display_order: number;
  created_at: string;
};

export type SiteSetting = {
  id: string;
  setting_key: string;
  setting_value: string;
  updated_at: string;
};
