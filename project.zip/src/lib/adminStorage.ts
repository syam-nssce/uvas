import { supabase } from '@/integrations/supabase/client';

type AdminCredentials = {
  username: string;
  password: string;
};

type AdminUploadBucket = 'gallery-images' | 'committee-photos' | 'documents';

interface UploadAdminFileParams {
  bucket: AdminUploadBucket;
  credentials: AdminCredentials;
  file: File;
  folder?: string;
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => {
      if (typeof reader.result !== 'string') {
        reject(new Error('Failed to read file'));
        return;
      }

      const [, base64] = reader.result.split(',');
      if (!base64) {
        reject(new Error('Failed to encode file'));
        return;
      }

      resolve(base64);
    };

    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

function sanitizeFileName(fileName: string) {
  const lastDotIndex = fileName.lastIndexOf('.');
  const baseName = lastDotIndex >= 0 ? fileName.slice(0, lastDotIndex) : fileName;
  const extension = lastDotIndex >= 0 ? fileName.slice(lastDotIndex).toLowerCase() : '';
  const safeBaseName = baseName
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'file';

  return `${Date.now()}-${safeBaseName}${extension}`;
}

export async function uploadAdminFile({
  bucket,
  credentials,
  file,
  folder,
}: UploadAdminFileParams) {
  const fileBase64 = await fileToBase64(file);
  const { data, error } = await supabase.functions.invoke('admin-storage-upload', {
    body: {
      username: credentials.username,
      password: credentials.password,
      bucket,
      folder,
      file_name: sanitizeFileName(file.name),
      file_base64: fileBase64,
      content_type: file.type || 'application/octet-stream',
    },
  });

  if (error) {
    throw new Error(error.message || 'Upload failed');
  }

  if (!data?.success || !data?.publicUrl) {
    throw new Error(data?.error || 'Upload failed');
  }

  return data.publicUrl as string;
}