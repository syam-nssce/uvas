import { useState, useRef, useEffect } from 'react';
import Header from '../components/Header';
import Hero from '../components/Hero';
import MainContent from '../components/MainContent';
import Footer from '../components/Footer';
import AdminLogin from '../components/AdminLogin';
import AdminDashboard from '../components/AdminDashboard';
import { supabase } from '../lib/supabase';

export default function Index() {
  const [activeSection, setActiveSection] = useState('home');
  const [isAdminView, setIsAdminView] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminCredentials, setAdminCredentials] = useState<{ username: string; password: string } | null>(null);
  const [bannerText, setBannerText] = useState('✦ ഉന്നത വിദ്യാഭ്യാസ അദ്ധ്യാപക സംഘം ✦');
  const mainContentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchBanner = async () => {
      const { data } = await supabase
        .from('site_settings')
        .select('setting_value')
        .eq('setting_key', 'home_banner_text')
        .maybeSingle();
      if (data?.setting_value) {
        setBannerText(data.setting_value);
      }
    };
    fetchBanner();
  }, []);

  const handleNavigate = (section: string) => {
    if (section === 'admin') {
      setIsAdminView(true);
      return;
    }
    setActiveSection(section);
    setTimeout(() => {
      mainContentRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const handleAdminLogin = (credentials: { username: string; password: string }) => {
    setAdminCredentials(credentials);
    setIsAdminLoggedIn(true);
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    setIsAdminView(false);
    setAdminCredentials(null);
    setActiveSection('home');
  };

  if (isAdminView) {
    if (!isAdminLoggedIn) {
      return <AdminLogin onLogin={handleAdminLogin} onBack={() => setIsAdminView(false)} />;
    }
    return <AdminDashboard onLogout={handleAdminLogout} adminCredentials={adminCredentials} />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Header activeSection={activeSection} setActiveSection={handleNavigate} />
      <Hero onNavigate={handleNavigate} />
      <div className="bg-card border-b border-border py-4">
        <p className="text-center text-foreground text-base sm:text-lg font-display font-semibold tracking-[0.2em] uppercase animate-fade-in">
          {bannerText}
        </p>
      </div>
      <div ref={mainContentRef}>
        <MainContent activeSection={activeSection} onNavigate={handleNavigate} />
      </div>
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
